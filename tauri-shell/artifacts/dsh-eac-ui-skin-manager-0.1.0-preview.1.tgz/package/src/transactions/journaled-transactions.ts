// Production-facing transaction adapter: `SlotTransactionCoordinator` (in-process commit/rollback)
// wired to the durable journal and the persistent binding state (task 6.2.5).
//
// The coordinator alone decides *what* the active binding is; it does not survive the process and it
// does not write state. This adapter closes both gaps without moving policy out of the coordinator:
//
//   * every stage acknowledgement (`prepare`, `preload`, `activate`, `health`, `commit`) advances a
//     durable record, so a process that dies at any point leaves evidence of how far it got — and
//     "the record says `activate`" means "activate finished", which is the distinction recovery
//     needs to tell an abandoned attempt from a committed one;
//   * the committed generation is written through `BindingStore.commit` as the coordinator's
//     `persist` step, so "committed" means "durable" rather than "in memory until the next publish";
//   * the old generation is disposed of strictly *after* the new one is committed — the ordering is
//     the coordinator's, and the adapter does not get a second chance to reorder it.
//
// Failure semantics match the coordinator exactly and are not relaxed here: a failure at any stage
// rolls back the staged contexts, leaves the previous binding active, closes the record as a failed
// attempt, and rethrows. A failure of the state write fails the transaction, so the previous
// binding stays active and no record is left claiming otherwise.
import type {SlotBinding} from "../contracts/models.ts";
import {BindingStore, type BindingGeneration} from "../bindings/binding-store.ts";
import {TransactionJournal, type JournalRecord, type TransactionStage} from "../recovery/transaction-journal.ts";
import {SlotTransactionCoordinator, type SlotTransactionContext, type SlotTransactionResult} from "./slot-transaction-coordinator.ts";

/** Stages the coordinator runs, in order, that the adapter records. */
export const JOURNALED_STAGES = ["prepare", "preload", "activate", "health", "commit"] as const satisfies readonly TransactionStage[];

export interface JournaledTransactionRequest {
  slot: string;
  binding: SlotBinding;
  contexts: SlotTransactionContext[];
  /** Previous binding to dispose of after the commit; the coordinator disposes it post-commit. */
  previous?: {binding: SlotBinding; dispose?: () => void | Promise<void>};
}

export interface JournaledTransactionResult extends SlotTransactionResult {
  correlationId: string;
  /** Stages that reported success, in order, as the durable record saw them. */
  stages: TransactionStage[];
}

export class JournaledSlotTransactions {
  readonly coordinator: SlotTransactionCoordinator;
  readonly journal: TransactionJournal;
  readonly bindings: BindingStore;

  constructor(options: {coordinator: SlotTransactionCoordinator; journal: TransactionJournal; bindings: BindingStore}) {
    this.coordinator = options.coordinator;
    this.journal = options.journal;
    this.bindings = options.bindings;
  }

  /**
   * Run one slot transaction: acknowledge each stage durably, commit the binding state, then let the
   * coordinator dispose of the old generation.
   *
   * The generation the transaction publishes is the binding's own generation, so the durable record
   * and the binding state agree by construction; the coordinator independently refuses a generation
   * that is not newer than the active one.
   */
  async switch(request: JournaledTransactionRequest): Promise<JournaledTransactionResult> {
    const correlationId = `${request.slot}-${request.binding.generation}-${process.pid}-${Date.now()}`;
    let record: JournalRecord = await this.journal.begin({
      slot: request.slot, generation: request.binding.generation, correlationId
    });
    const stages: TransactionStage[] = [];
    const advance = async (stage: TransactionStage): Promise<void> => {
      // Idempotent per stage: the coordinator's persist step is reached only after every context
      // acknowledged `commit`, so the stage may already have been recorded by a context hook.
      if (record.stage === stage) return;
      record = await this.journal.advance(record, stage);
      stages.push(stage);
    };
    try {
      const result = await this.coordinator.switch({
        slot: request.slot,
        binding: request.binding,
        contexts: request.contexts.map((context) => journalingContext(context, advance)),
        ...(request.previous ? {previous: request.previous} : {}),
        persist: async (binding) => {
          // Reaching this step means every context acknowledged `commit`, whether or not any of
          // them declared a commit hook; record that before the state write is attempted.
          await advance("commit");
          // The whole slot set as the coordinator sees it, written atomically, before the
          // coordinator publishes the new active binding in memory. A failure here fails the
          // transaction: the previous binding stays active.
          const previousState = (await this.bindings.committed()).value;
          const generation: BindingGeneration = {
            generation: binding.generation,
            bindings: {...previousState?.bindings, [binding.slot]: {...binding, state: "active"}}
          };
          await this.bindings.commit(generation);
          await advance("persist");
        }
      });
      // Fully committed and reconciled: the durable record has served its purpose.
      await this.journal.close(record);
      return {...result, correlationId, stages};
    } catch (error) {
      // An abandoned attempt is closed as `failed` at the last stage that reported progress. It is
      // never left open, so a later start cannot mistake it for a committed-but-unrecorded split.
      await this.journal.fail(record, record.stage === "begin" ? "begin" : record.stage, error).catch(() => undefined);
      throw error;
    }
  }

  /** Bindings the manager should continue from after a restart, dropping any staged state. */
  async recover(): Promise<BindingGeneration> {
    return this.bindings.recover();
  }
}

/**
 * Wrap one context so each stage acknowledgement advances the journal after the hook reports
 * success. Every hook keeps its own stage name: a record at `activate` therefore means "activate
 * finished", never "activate started".
 */
export function journalingContext(
  context: SlotTransactionContext,
  onStage: (stage: TransactionStage) => void | Promise<void>
): SlotTransactionContext {
  const wrapped: SlotTransactionContext = {...context};
  for (const stage of JOURNALED_STAGES) {
    const hook = context[stage];
    if (hook === undefined) continue;
    wrapped[stage] = async (binding?: SlotBinding) => {
      await hook(binding);
      await onStage(stage);
    };
  }
  return wrapped;
}
