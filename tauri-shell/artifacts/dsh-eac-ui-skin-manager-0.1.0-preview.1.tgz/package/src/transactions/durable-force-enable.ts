// Durable 30-second force-enable confirmation (`skin-force-enable@1`, task 6.2.5).
//
// Pipeline position: this is the *only* path by which a contribution that failed compatibility can
// still be activated, and it is the last place where a policy mistake becomes a security problem.
// It therefore enforces three things the in-memory controller alone cannot:
//
//   1. **Eligibility is decided by error category, not by the caller.** Only `COMPATIBILITY_*`
//      failures may enter the flow. `MANIFEST_*` / `JSON` / `PATH_*` / `ASSET_*` / `INTEGRITY_*` /
//      `CONTAINER_*` / `ENTRY_*` / `ARCHIVE_*` / `TRUST_*` are refused before any state is touched,
//      so a malformed package, a traversal attempt or a digest mismatch can never be kept by
//      clicking through a dialog. ADR 0010 §6 and the 6.2.0 decision D4 freeze this; the allowlist
//      is a constant, not a parameter a UI can widen.
//   2. **`system.default` is non-forceable.** The default artifact is the last package recovery
//      path; there is no compatibility exception that justifies bypassing its own identity gate.
//   3. **The confirmation window survives the process.** The pending record is written before
//      activation and removed only when the user keeps it. Timeout, an explicit disconnect, an
//      orderly exit and a crash all end with the previous binding restored, and a restart always
//      restores rather than resumes: `pending` is never promoted to active.
//
// What this module deliberately does NOT do: it never evaluates compatibility itself, it never
// chooses a rollback target, and it never writes the binding state for a *kept* generation — the
// caller's `commit` hook does that, so the ordinary transaction path stays the only writer of
// committed state.
import {readdir, unlink} from "node:fs/promises";
import {join} from "node:path";
import {AtomicJsonStore} from "../persistence/atomic-json-store.ts";

/** Categories that may enter the confirmation flow. Everything else is refused outright. */
export const FORCE_ENABLE_ALLOWED_CATEGORIES = ["COMPATIBILITY"] as const;

/** Categories that must never be bypassable, listed so the refusal is explicit and testable. */
export const FORCE_ENABLE_DENIED_CATEGORIES = [
  "MANIFEST",
  "JSON",
  "PATH",
  "ASSET",
  "INTEGRITY",
  "CONTAINER",
  "ENTRY",
  "ARCHIVE",
  "TRUST",
  "SOURCE",
  "INSTALL",
  "PERSISTENCE",
  "DEPENDENCY"
] as const;

export const FORCE_ENABLE_CONFIRMATION_MS = 30_000 as const;
export const FORCE_ENABLE_PENDING_SCHEMA = "dsh-eac-skin-force-enable-pending@1" as const;
export const FORCE_ENABLE_RECORD_SUFFIX = ".force-enable.json" as const;
/** The non-forceable default package identity (interface table: "Non-forceable"). */
export const NON_FORCEABLE_PACKAGE_ID = "system.default" as const;

export type ForceEnableErrorCode =
  | "FORCE_ENABLE_INELIGIBLE"
  | "FORCE_ENABLE_DEFAULT_PACKAGE"
  | "FORCE_ENABLE_PENDING"
  | "FORCE_ENABLE_NOT_PENDING";

export class ForceEnableError extends Error {
  readonly code: ForceEnableErrorCode;
  constructor(code: ForceEnableErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "ForceEnableError";
    this.code = code;
  }
}

/** Category of a stable error code, e.g. `COMPATIBILITY_SLOT_KIND` -> `COMPATIBILITY`. */
export function errorCategory(errorCode: string): string {
  const separator = errorCode.indexOf("_");
  return separator > 0 ? errorCode.slice(0, separator) : errorCode;
}

/** True when a failure may enter the 30-second confirmation flow. Fails closed on unknown codes. */
export function isForceEnableEligible(errorCode: string): boolean {
  const category = errorCategory(errorCode);
  return (FORCE_ENABLE_ALLOWED_CATEGORIES as readonly string[]).includes(category);
}

export interface DurableForceEnableRequest {
  slot: string;
  /** Package coordinate being force-enabled, for the record and the UI. */
  target: string;
  /** Coordinate the slot returns to when the confirmation is not kept. */
  previous: string;
  /** Stable error code that made the contribution ineligible for a normal activation. */
  errorCode: string;
  activate: () => void | Promise<void>;
  restore: () => void | Promise<void>;
  commit: () => void | Promise<void>;
}

export interface DurablePendingRecord {
  schema: typeof FORCE_ENABLE_PENDING_SCHEMA;
  correlationId: string;
  slot: string;
  target: string;
  previous: string;
  errorCode: string;
  startedAt: string;
  expiresAt: number;
}

export interface ForceEnableHandle {
  readonly record: DurablePendingRecord;
  /** Resolves `kept` when the user confirmed in time, `restored` otherwise. */
  readonly done: Promise<"kept" | "restored">;
  /** Restore the previous binding now (explicit disconnect / orderly shutdown). */
  abandon(): Promise<void>;
  /** Why the window ended, when it ended by restoring. */
  readonly endedBy: string | undefined;
}

interface LivePending {
  readonly record: DurablePendingRecord;
  readonly request: DurableForceEnableRequest;
  readonly done: Promise<"kept" | "restored">;
  readonly resolve: (outcome: "kept" | "restored") => void;
  timer: ReturnType<typeof setTimeout>;
  settled: boolean;
  endedBy?: string;
}

export interface DurableForceEnableOptions {
  /** Directory holding the pending records. */
  directory: string;
  now?: () => number;
  confirmationMs?: number;
  /** Test seam: replaces the real timer so expiry can be driven deterministically. */
  schedule?: (callback: () => void, delayMs: number) => ReturnType<typeof setTimeout>;
  cancel?: (timer: ReturnType<typeof setTimeout>) => void;
}

/**
 * Force-enable controller with a durable pending record.
 *
 * One confirmation per slot. `keep` commits through the caller's hook and only then drops the
 * record; every other outcome restores first and drops the record second, so an interruption
 * between the two leaves a record that the next start restores again (idempotent by construction).
 */
export class DurableForceEnableController {
  readonly directory: string;
  readonly now: () => number;
  readonly confirmationMs: number;
  #live = new Map<string, LivePending>();
  #schedule: (callback: () => void, delayMs: number) => ReturnType<typeof setTimeout>;
  #cancel: (timer: ReturnType<typeof setTimeout>) => void;

  constructor(options: DurableForceEnableOptions) {
    const confirmationMs = options.confirmationMs ?? FORCE_ENABLE_CONFIRMATION_MS;
    if (!Number.isFinite(confirmationMs) || confirmationMs <= 0) throw new RangeError("confirmationMs must be positive");
    this.directory = options.directory;
    this.now = options.now ?? Date.now;
    this.confirmationMs = confirmationMs;
    this.#schedule = options.schedule ?? ((callback, delayMs) => setTimeout(callback, delayMs));
    this.#cancel = options.cancel ?? ((timer) => clearTimeout(timer));
  }

  /** Slots currently on probation, for the settings UI. */
  pendingSlots(): string[] {
    return [...this.#live.keys()].sort();
  }

  /** The pending record for one slot, if a window is open in this process. */
  pending(slot: string): DurablePendingRecord | undefined {
    const live = this.#live.get(slot);
    return live && { ...live.record };
  }

  /**
   * Begin a confirmation window.
   *
   * Refuses before touching any state when the failure category is not eligible, when the target is
   * the non-forceable default package, or when a confirmation for this slot is already running.
   */
  async begin(request: DurableForceEnableRequest): Promise<ForceEnableHandle> {
    if (!isForceEnableEligible(request.errorCode)) {
      throw new ForceEnableError(
        "FORCE_ENABLE_INELIGIBLE",
        `${request.errorCode} (${errorCategory(request.errorCode)}) is never bypassable; only ${FORCE_ENABLE_ALLOWED_CATEGORIES.join(", ")} failures may enter the ${this.confirmationMs / 1000}-second confirmation`
      );
    }
    if (request.target === NON_FORCEABLE_PACKAGE_ID) {
      throw new ForceEnableError("FORCE_ENABLE_DEFAULT_PACKAGE", `${NON_FORCEABLE_PACKAGE_ID} is the last package recovery path and is non-forceable`);
    }
    if (this.#live.has(request.slot)) {
      throw new ForceEnableError("FORCE_ENABLE_PENDING", `${request.slot} already has a confirmation in progress`);
    }

    const record: DurablePendingRecord = {
      schema: FORCE_ENABLE_PENDING_SCHEMA,
      correlationId: `force-enable-${request.slot}-${this.now()}-${process.pid}`,
      slot: request.slot,
      target: request.target,
      previous: request.previous,
      errorCode: request.errorCode,
      startedAt: new Date(this.now()).toISOString(),
      expiresAt: this.now() + this.confirmationMs
    };
    // Durable *before* activation: a crash during activation must still leave a record the next
    // start restores from.
    await new AtomicJsonStore<DurablePendingRecord>(this.#path(request.slot)).write(record);

    let resolve!: (outcome: "kept" | "restored") => void;
    const done = new Promise<"kept" | "restored">((finish) => { resolve = finish; });
    const live: LivePending = {
      record,
      request,
      done,
      resolve,
      timer: this.#schedule(() => { void this.expire(request.slot); }, this.confirmationMs),
      settled: false
    };
    this.#live.set(request.slot, live);

    const handle: ForceEnableHandle = {
      record,
      done,
      abandon: async () => { await this.#restore(live, "abandoned by the user"); },
      get endedBy() { return live.endedBy; }
    };

    try {
      await request.activate();
    } catch (error) {
      // The candidate could not even be activated: restore immediately rather than leaving the slot
      // on probation for 30 seconds.
      await this.#restore(live, `activation failed: ${error instanceof Error ? error.message : String(error)}`);
    }
    return handle;
  }

  /** The user kept the candidate: commit through the caller's hook, then drop the record. */
  async keep(slot: string): Promise<"kept" | "restored"> {
    const live = this.#live.get(slot);
    if (!live) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", slot);
    try {
      await live.request.commit();
    } catch (error) {
      await this.#restore(live, `commit failed: ${error instanceof Error ? error.message : String(error)}`);
      return "restored";
    }
    this.#settle(live, "kept");
    await unlink(this.#path(slot)).catch(() => undefined);
    return "kept";
  }

  /** Expire one slot if its window has closed. */
  async expire(slot: string): Promise<void> {
    const live = this.#live.get(slot);
    if (!live || live.settled) return;
    if (this.now() < live.record.expiresAt) return;
    await this.#restore(live, "confirmation window expired");
  }

  /**
   * Every durable record left by a *previous* run. Called on start, before the manager serves
   * anything: a pending record is always restored, never resumed, so a package that was on
   * probation when the process died cannot become active by surviving a restart.
   */
  async recover(): Promise<{restored: DurablePendingRecord[]; unreadable: string[]}> {
    const restored: DurablePendingRecord[] = [];
    const unreadable: string[] = [];
    for (const name of await this.#recordFiles()) {
      const path = join(this.directory, name);
      const result = await new AtomicJsonStore<DurablePendingRecord | undefined>(path).read(undefined);
      const record = result.value;
      if (result.diagnostic || !record || record.schema !== FORCE_ENABLE_PENDING_SCHEMA || typeof record.slot !== "string" || record.slot.length === 0) {
        unreadable.push(path);
        continue;
      }
      restored.push(record);
    }
    return {restored, unreadable};
  }

  /** Drop a durable record once its restore has been performed. */
  async acknowledge(slot: string): Promise<void> {
    await unlink(this.#path(slot)).catch(() => undefined);
  }

  #path(slot: string): string {
    if (!/^[A-Za-z0-9._-]+$/.test(slot)) throw new RangeError(`slot name contains characters outside [A-Za-z0-9._-]: ${JSON.stringify(slot)}`);
    return join(this.directory, `${slot}${FORCE_ENABLE_RECORD_SUFFIX}`);
  }

  async #recordFiles(): Promise<string[]> {
    try {
      return (await readdir(this.directory)).filter((name) => name.endsWith(FORCE_ENABLE_RECORD_SUFFIX)).sort();
    } catch {
      return [];
    }
  }

  async #restore(live: LivePending, reason: string): Promise<void> {
    if (live.settled) return;
    this.#settle(live, "restored", reason);
    try {
      await live.request.restore();
    } finally {
      await unlink(this.#path(live.record.slot)).catch(() => undefined);
    }
  }

  #settle(live: LivePending, outcome: "kept" | "restored", reason?: string): void {
    if (live.settled) return;
    live.settled = true;
    if (reason !== undefined) live.endedBy = reason;
    this.#cancel(live.timer);
    this.#live.delete(live.record.slot);
    live.resolve(outcome);
  }
}
