// Durable 30-second force-enable confirmation (`skin-force-enable@1`, task 6.2.5).
//
// Pipeline position: this is the *only* path by which a contribution that failed compatibility can
// still be activated, and it is the last place where a policy mistake becomes a security problem.
// It therefore enforces three things the in-memory controller alone cannot:
//
//   1. **Eligibility is decided by error category, not by the caller.** Only `COMPATIBILITY_*`
//      failures may enter the flow. `MANIFEST_*` / `JSON` / `PATH_*` / `ASSET_*` / `INTEGRITY_*` /
//      `CONTAINER_*` / `ENTRY_*` / `ARCHIVE_*` / `TRUST_*` are refused before any state is touched,
//      so a malformed package, a traversal attempt or a digest mismatch can never be kept by
//      clicking through a dialog. ADR 0010 §6 and the 6.2.0 decision D4 freeze this; the allowlist
//      is a constant, not a parameter a UI can widen.
//   2. **`system.default` is non-forceable.** The default artifact is the last package recovery
//      path; there is no compatibility exception that justifies bypassing its own identity gate.
//   3. **The confirmation window survives the process.** The pending record is written before
//      activation and removed only when the outcome is durably settled. Timeout, an explicit
//      disconnect, an orderly exit and a crash all end with the previous binding restored, and a
//      restart always restores rather than resumes: `pending` is never promoted to active.
//
// What this module deliberately does NOT do: it never evaluates compatibility itself, it never
// chooses a rollback target, and it never writes the binding state for a *kept* generation — the
// caller's `commit` hook does that, so the ordinary transaction path stays the only writer of
// committed state.
//
// ── Failure semantics, stated precisely (reworked after the 6.2.5 audit) ────────────────────────
//
// The first version reported `restored` and deleted the durable record even when `restore()` threw,
// which is the one report that must never be wrong: the caller would believe the previous binding
// was back, the record that a restart needs would be gone, and nothing would be left to retry from.
// The rules now are:
//
//   * a slot is **claimed atomically before the first `await`**, so two overlapping `begin` calls
//     for one slot cannot both write a record and both activate — the second is refused with
//     `FORCE_ENABLE_PENDING` even though neither has reached the filesystem yet;
//   * `begin` / `keep` / `abandon` / `expire` are **serialized per slot**, so a `keep` that races
//     the 30-second timer cannot commit a candidate whose window has already closed, and cannot
//     interleave with a restore;
//   * `keep` **checks `expiresAt`**; a keep that arrives after the window closed restores instead of
//     committing, and says so (`endedBy: "confirmation window expired before keep"`);
//   * the record is deleted **only after** the outcome is durably settled: after `restore()` returned
//     and the record could be removed, or after `commit()` returned and the record was marked
//     `kept` and removed. Any failure on that path keeps the record, leaves the slot retryable and
//     resolves `done` to `restore-failed` — never to `restored`;
//   * a restore that succeeded but whose record could not be removed reports `restore-failed` with
//     `restored: true, recordRemoved: false`, so "the binding is back but the record lingers" is
//     distinguishable from "the binding is not back";
//   * the timer callback cannot raise an unhandled rejection: its failure is folded into the same
//     outcome the caller is already awaiting.
import {readdir, unlink} from "node:fs/promises";
import {join} from "node:path";
import {AtomicJsonStore} from "../persistence/atomic-json-store.ts";

/** Categories that may enter the confirmation flow. Everything else is refused outright. */
export const FORCE_ENABLE_ALLOWED_CATEGORIES = ["COMPATIBILITY"] as const;

/** Categories that must never be bypassable, listed so the refusal is explicit and testable. */
export const FORCE_ENABLE_DENIED_CATEGORIES = [
  "MANIFEST",
  "JSON",
  "PATH",
  "ASSET",
  "INTEGRITY",
  "CONTAINER",
  "ENTRY",
  "ARCHIVE",
  "TRUST",
  "SOURCE",
  "INSTALL",
  "PERSISTENCE",
  "DEPENDENCY"
] as const;

export const FORCE_ENABLE_CONFIRMATION_MS = 30_000 as const;
export const FORCE_ENABLE_PENDING_SCHEMA = "dsh-eac-skin-force-enable-pending@1" as const;
export const FORCE_ENABLE_RECORD_SUFFIX = ".force-enable.json" as const;
/** The non-forceable default package identity (interface table: "Non-forceable"). */
export const NON_FORCEABLE_PACKAGE_ID = "system.default" as const;

export type ForceEnableErrorCode =
  | "FORCE_ENABLE_INELIGIBLE"
  | "FORCE_ENABLE_DEFAULT_PACKAGE"
  | "FORCE_ENABLE_PENDING"
  | "FORCE_ENABLE_NOT_PENDING"
  | "FORCE_ENABLE_RESTORE_FAILED"
  | "FORCE_ENABLE_RECORD_UNREADABLE";

export class ForceEnableError extends Error {
  readonly code: ForceEnableErrorCode;
  constructor(code: ForceEnableErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "ForceEnableError";
    this.code = code;
  }
}

/**
 * How a confirmation window ended.
 *
 * `restore-failed` means the window is over but the slot is not clean: either `restore()` threw, or
 * the binding was restored and the durable record could not be removed. In both cases the record is
 * still on disk, `retryRestore()` may be called, and a restart will restore again — which is exactly
 * why the caller must not be told `restored`.
 */
export type ForceEnableOutcome = "kept" | "restored" | "restore-failed";

/** Category of a stable error code, e.g. `COMPATIBILITY_SLOT_KIND` -> `COMPATIBILITY`. */
export function errorCategory(errorCode: string): string {
  const separator = errorCode.indexOf("_");
  return separator > 0 ? errorCode.slice(0, separator) : errorCode;
}

/** True when a failure may enter the 30-second confirmation flow. Fails closed on unknown codes. */
export function isForceEnableEligible(errorCode: string): boolean {
  const category = errorCategory(errorCode);
  return (FORCE_ENABLE_ALLOWED_CATEGORIES as readonly string[]).includes(category);
}

export interface DurableForceEnableRequest {
  slot: string;
  /** Package coordinate being force-enabled, for the record and the UI. */
  target: string;
  /** Coordinate the slot returns to when the confirmation is not kept. */
  previous: string;
  /** Stable error code that made the contribution ineligible for a normal activation. */
  errorCode: string;
  activate: () => void | Promise<void>;
  restore: () => void | Promise<void>;
  commit: () => void | Promise<void>;
}

/** Durable state of a record. A record written by an older build has no `state` and means `pending`. */
export type ForceEnableRecordState = "pending" | "kept";

export interface DurablePendingRecord {
  schema: typeof FORCE_ENABLE_PENDING_SCHEMA;
  correlationId: string;
  slot: string;
  target: string;
  previous: string;
  errorCode: string;
  startedAt: string;
  expiresAt: number;
  /**
   * `kept` is written before the record is removed, so a crash between the commit and the removal
   * leaves a record a restart must *not* restore from. Missing means `pending` (fail closed: an
   * unmarked record is treated as an open window).
   */
  state?: ForceEnableRecordState;
}

export interface ForceEnableHandle {
  readonly record: DurablePendingRecord;
  /**
   * Resolves when the window is over: `kept` (committed), `restored` (previous binding is back and
   * the record is gone) or `restore-failed` (the slot is not clean — see `restored`/`recordRemoved`).
   */
  readonly done: Promise<ForceEnableOutcome>;
  /** Restore the previous binding now (explicit disconnect / orderly shutdown). */
  abandon(): Promise<ForceEnableOutcome>;
  /** Retry a restore that failed, including removing a record that could not be removed. */
  retryRestore(): Promise<ForceEnableOutcome>;
  /** Why the window ended, when it ended by restoring. */
  readonly endedBy: string | undefined;
  /** True once `restore()` returned successfully, whatever happened to the record afterwards. */
  readonly restored: boolean;
  /** True once the durable record is known to be gone. */
  readonly recordRemoved: boolean;
  /** The last restore failure, when the outcome is `restore-failed`. */
  readonly restoreError: string | undefined;
}

interface LivePending {
  record: DurablePendingRecord;
  readonly request: DurableForceEnableRequest;
  readonly done: Promise<ForceEnableOutcome>;
  readonly resolve: (outcome: ForceEnableOutcome) => void;
  timer?: ReturnType<typeof setTimeout>;
  settled: boolean;
  /** Set when the window closed (expiry or an explicit end) and no further keep is allowed. */
  closed: boolean;
  /** Terminal outcome, recorded even on paths that resolve without settling (a failed restore). */
  outcome?: ForceEnableOutcome;
  endedBy?: string;
  restoreError?: string;
  restored: boolean;
  recordRemoved: boolean;
}

export interface DurableForceEnableOptions {
  /** Directory holding the pending records. */
  directory: string;
  now?: () => number;
  confirmationMs?: number;
  /** Test seam: replaces the real timer so expiry can be driven deterministically. */
  schedule?: (callback: () => void, delayMs: number) => ReturnType<typeof setTimeout>;
  cancel?: (timer: ReturnType<typeof setTimeout>) => void;
}

export interface ForceEnableRecoveryResult {
  /** Records that must be restored: their windows were open when the process died. */
  restored: DurablePendingRecord[];
  /**
   * Records a restart must *not* restore: they were already kept (the marker was written), or the
   * caller's `isTargetCommitted` proved the commit landed before the record was removed. Cleanup
   * candidates only.
   */
  kept: DurablePendingRecord[];
  /** Record files that exist but could not be read or are not records. */
  unreadable: string[];
  /**
   * Set when the record directory itself could not be listed for a reason other than "it does not
   * exist". `restored` being empty is then *not* evidence that no window was open.
   */
  directoryError?: string;
}

/**
 * Force-enable controller with a durable pending record.
 *
 * One confirmation per slot, serialized. `keep` commits through the caller's hook and only then
 * marks and drops the record; every other outcome restores first and drops the record second, so an
 * interruption between the two leaves a record that the next start restores again (idempotent by
 * construction). A restore that fails is never reported as a success.
 */
export class DurableForceEnableController {
  readonly directory: string;
  readonly now: () => number;
  readonly confirmationMs: number;
  #live = new Map<string, LivePending>();
  /** Per-slot tail of the in-flight operation chain; keeps keep/expire/abandon/begin from racing. */
  #slotLocks = new Map<string, Promise<unknown>>();
  #schedule: (callback: () => void, delayMs: number) => ReturnType<typeof setTimeout>;
  #cancel: (timer: ReturnType<typeof setTimeout>) => void;

  constructor(options: DurableForceEnableOptions) {
    const confirmationMs = options.confirmationMs ?? FORCE_ENABLE_CONFIRMATION_MS;
    if (!Number.isFinite(confirmationMs) || confirmationMs <= 0) throw new RangeError("confirmationMs must be positive");
    this.directory = options.directory;
    this.now = options.now ?? Date.now;
    this.confirmationMs = confirmationMs;
    this.#schedule = options.schedule ?? ((callback, delayMs) => setTimeout(callback, delayMs));
    this.#cancel = options.cancel ?? ((timer) => clearTimeout(timer));
  }

  /** Slots currently on probation, for the settings UI. */
  pendingSlots(): string[] {
    return [...this.#live.keys()].sort();
  }

  /** The pending record for one slot, if a window is open in this process. */
  pending(slot: string): DurablePendingRecord | undefined {
    const live = this.#live.get(slot);
    return live && {...live.record};
  }

  /**
   * Begin a confirmation window.
   *
   * Refuses before touching any state when the failure category is not eligible, when the target is
   * the non-forceable default package, or when a confirmation for this slot is already running. The
   * slot is claimed **before** the first `await`, so two concurrent calls cannot both get past the
   * "already pending" check and both write a record.
   */
  async begin(request: DurableForceEnableRequest): Promise<ForceEnableHandle> {
    if (!isForceEnableEligible(request.errorCode)) {
      throw new ForceEnableError(
        "FORCE_ENABLE_INELIGIBLE",
        `${request.errorCode} (${errorCategory(request.errorCode)}) is never bypassable; only ${FORCE_ENABLE_ALLOWED_CATEGORIES.join(", ")} failures may enter the ${this.confirmationMs / 1000}-second confirmation`
      );
    }
    if (request.target === NON_FORCEABLE_PACKAGE_ID) {
      throw new ForceEnableError("FORCE_ENABLE_DEFAULT_PACKAGE", `${NON_FORCEABLE_PACKAGE_ID} is the last package recovery path and is non-forceable`);
    }
    // ── Atomic claim, synchronously, before anything is awaited ─────────────────────────────────
    if (this.#live.has(request.slot)) {
      throw new ForceEnableError("FORCE_ENABLE_PENDING", `${request.slot} already has a confirmation in progress`);
    }
    const record: DurablePendingRecord = {
      schema: FORCE_ENABLE_PENDING_SCHEMA,
      correlationId: `force-enable-${request.slot}-${this.now()}-${process.pid}`,
      slot: request.slot,
      target: request.target,
      previous: request.previous,
      errorCode: request.errorCode,
      startedAt: new Date(this.now()).toISOString(),
      expiresAt: this.now() + this.confirmationMs,
      state: "pending"
    };
    let resolve!: (outcome: ForceEnableOutcome) => void;
    const done = new Promise<ForceEnableOutcome>((finish) => { resolve = finish; });
    const live: LivePending = {
      record, request, done, resolve, settled: false, closed: false, restored: false, recordRemoved: false
    };
    this.#live.set(request.slot, live);

    return this.#withSlotLock(request.slot, async () => {
      try {
        // Durable *before* activation: a crash during activation must still leave a record the next
        // start restores from.
        await new AtomicJsonStore<DurablePendingRecord>(this.#path(request.slot)).write(record);
      } catch (error) {
        // The window never opened: release the claim and report the real reason. Nothing was
        // activated, so there is nothing to restore.
        this.#live.delete(request.slot);
        live.settled = true;
        live.outcome = "restore-failed";
        live.recordRemoved = true;
        live.restoreError = `the pending record could not be written: ${error instanceof Error ? error.message : String(error)}`;
        live.resolve("restore-failed");
        throw error;
      }
      live.timer = this.#schedule(() => {
        // A rejected callback would otherwise be an unhandled rejection; `expire` folds its own
        // failures into the outcome the caller is already awaiting, and this catch is the belt.
        void this.expire(request.slot).catch(() => undefined);
      }, this.confirmationMs);

      const handle: ForceEnableHandle = {
        record,
        done,
        abandon: async () => this.abandon(request.slot),
        retryRestore: async () => this.retryRestore(request.slot),
        get endedBy() { return live.endedBy; },
        get restored() { return live.restored; },
        get recordRemoved() { return live.recordRemoved; },
        get restoreError() { return live.restoreError; }
      };

      try {
        await live.request.activate();
      } catch (error) {
        // The candidate could not even be activated: restore immediately rather than leaving the
        // slot on probation for 30 seconds.
        await this.#restoreLocked(live, `activation failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      return handle;
    });
  }

  /**
   * The user kept the candidate: commit through the caller's hook, then drop the record.
   *
   * Refuses to commit a candidate whose window has already closed, and refuses while a restore is in
   * flight — the decision is only available inside an open window.
   */
  async keep(slot: string): Promise<ForceEnableOutcome> {
    const live = this.#live.get(slot);
    if (!live) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", slot);
    return this.#withSlotLock(slot, async () => {
      const current = this.#live.get(slot);
      if (current !== live) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", slot);
      if (live.settled) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", `${slot} was already settled`);
      if (live.closed) throw new ForceEnableError("FORCE_ENABLE_RESTORE_FAILED", `${slot} is not clean: ${live.endedBy ?? "the window is closed"}`);
      if (this.now() >= live.record.expiresAt) {
        // The window is over. A keep that arrives late must not commit — the user's confirmation is
        // only valid inside the 30 seconds they were given.
        await this.#restoreLocked(live, "confirmation window expired before keep");
        return live.outcome ?? "restore-failed";
      }
      try {
        await live.request.commit();
      } catch (error) {
        await this.#restoreLocked(live, `commit failed: ${error instanceof Error ? error.message : String(error)}`);
        return live.outcome ?? "restore-failed";
      }
      // The commit is durable, so the decision is `kept`. What remains is bookkeeping, and it is
      // reported rather than hidden: mark the record before removing it (a crash between the two
      // leaves a record that says `kept`, so a restart reports it for cleanup instead of restoring
      // the generation the user just confirmed), then remove it. A failure here does not change the
      // outcome — the commit landed — but it does leave `recordRemoved: false` and a `cleanupRecord`
      // retry, because a record left as `pending` would make the next start restore a kept candidate.
      live.closed = true;
      this.#cancelTimer(live);
      let marking: string | undefined;
      try {
        await new AtomicJsonStore<DurablePendingRecord>(this.#path(slot)).write({...live.record, state: "kept"});
      } catch (error) {
        marking = error instanceof Error ? error.message : String(error);
      }
      const removal = await this.#removeRecord(slot);
      if (removal !== undefined) {
        live.endedBy = `kept, but the durable record could not be removed${marking !== undefined ? ` (and could not be marked as kept: ${marking})` : ""}: ${removal}`;
        live.restoreError = live.endedBy;
      } else {
        live.recordRemoved = true;
        if (marking !== undefined) live.endedBy = `kept; the record was removed without being marked as kept first: ${marking}`;
      }
      this.#settle(live, "kept");
      return "kept";
    });
  }

  /**
   * Remove a record left behind by a `kept` outcome, without restoring anything.
   *
   * The complement of `retryRestore`: after a keep the binding is the new one, so the only thing a
   * retry may do is delete the leftover record. A record that is still there after a keep is the one
   * shape recovery must not mistake for an open window, which is why this exists.
   */
  async cleanupRecord(slot: string): Promise<boolean> {
    const removal = await this.#removeRecord(slot);
    const live = this.#live.get(slot);
    if (removal === undefined) {
      if (live) {
        live.recordRemoved = true;
        if (live.settled && live.outcome === "kept") live.endedBy = "kept; the leftover record was removed by cleanupRecord";
      }
      return true;
    }
    if (live) {
      live.recordRemoved = false;
      live.restoreError = removal;
      live.endedBy = removal;
    }
    return false;
  }

  /** Expire one slot if its window has closed. Never rejects: the outcome carries the failure. */
  async expire(slot: string): Promise<ForceEnableOutcome | undefined> {
    const live = this.#live.get(slot);
    if (!live) return undefined;
    return this.#withSlotLock(slot, async () => {
      const current = this.#live.get(slot);
      if (current !== live || live.settled) return undefined;
      if (this.now() < live.record.expiresAt) return undefined;
      await this.#restoreLocked(live, "confirmation window expired");
      return live.outcome ?? "restore-failed";
    });
  }

  /** Restore the previous binding now (explicit disconnect / orderly shutdown). */
  async abandon(slot: string): Promise<ForceEnableOutcome> {
    const live = this.#live.get(slot);
    if (!live) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", slot);
    return this.#withSlotLock(slot, async () => {
      const current = this.#live.get(slot);
      if (current !== live) return live.outcome ?? "restore-failed";
      if (live.settled) return live.outcome ?? (live.restored ? "restored" : "restore-failed");
      await this.#restoreLocked(live, "abandoned by the user");
      return live.outcome ?? "restore-failed";
    });
  }

  /**
   * Retry a restore (or the removal of a record) that failed.
   *
   * The record was deliberately kept on the failing path, so this is the entry point that makes the
   * failure recoverable in-process instead of only on the next start.
   */
  async retryRestore(slot: string): Promise<ForceEnableOutcome> {
    const live = this.#live.get(slot);
    if (!live) throw new ForceEnableError("FORCE_ENABLE_NOT_PENDING", slot);
    if (live.settled) return live.outcome ?? (live.restored ? "restored" : "restore-failed");
    return this.#withSlotLock(slot, async () => {
      if (live.settled) return live.outcome ?? (live.restored ? "restored" : "restore-failed");
      await this.#restoreLocked(live, live.endedBy ?? "restore retried");
      return live.outcome ?? "restore-failed";
    });
  }

  /**
   * Every durable record left by a *previous* run. Called on start, before the manager serves
   * anything: a pending record is always restored, never resumed, so a package that was on
   * probation when the process died cannot become active by surviving a restart.
   *
   * `isTargetCommitted` closes the one window in which a `kept` outcome has not yet written its
   * marker: if the caller can show that the record's target is what the committed state already
   * names, the commit landed and the record is a leftover, not an open window. Without the
   * predicate the decision fails closed (the record is restored).
   */
  async recover(options: {isTargetCommitted?: (record: DurablePendingRecord) => boolean} = {}): Promise<ForceEnableRecoveryResult> {
    const listed = await this.#recordFiles();
    const restored: DurablePendingRecord[] = [];
    const kept: DurablePendingRecord[] = [];
    const unreadable: string[] = [];
    // A record file that is there but cannot be read is reported. It is *not* treated as absent, and
    // it is not restored either: nothing is known about which slot it belongs to.
    const result: ForceEnableRecoveryResult = {...(listed.error !== undefined ? {directoryError: listed.error} : {}), restored, kept, unreadable};
    if (listed.error !== undefined) return result;
    for (const name of listed.files) {
      const path = join(this.directory, name);
      const read = await new AtomicJsonStore<DurablePendingRecord | undefined>(path).read(undefined);
      const record = read.value;
      if (read.diagnostic || !record || record.schema !== FORCE_ENABLE_PENDING_SCHEMA || typeof record.slot !== "string" || record.slot.length === 0) {
        unreadable.push(path);
        continue;
      }
      if (record.state === "kept") kept.push(record);
      else if (options.isTargetCommitted?.(record) === true) kept.push(record);
      else restored.push(record);
    }
    return result;
  }

  /**
   * Drop a durable record once its restore has been performed.
   *
   * Throws `FORCE_ENABLE_RESTORE_FAILED` when the file is there and cannot be removed: reporting
   * success would leave a record a restart restores again while the caller believes the slot is
   * clean.
   */
  async acknowledge(slot: string): Promise<void> {
    const removal = await this.#removeRecord(slot);
    if (removal !== undefined) throw new ForceEnableError("FORCE_ENABLE_RESTORE_FAILED", removal);
  }

  #path(slot: string): string {
    if (!/^[A-Za-z0-9._-]+$/.test(slot)) throw new RangeError(`slot name contains characters outside [A-Za-z0-9._-]: ${JSON.stringify(slot)}`);
    return join(this.directory, `${slot}${FORCE_ENABLE_RECORD_SUFFIX}`);
  }

  /**
   * Record files in the directory.
   *
   * A directory that does not exist yet is the normal first-run case and is *not* an error. Any
   * other listing failure (permissions, a path that is a file rather than a directory) is returned
   * to the caller instead of being flattened into "no records": `recover()` must not report
   * "nothing was pending" because it could not look.
   */
  async #recordFiles(): Promise<{files: string[]; error?: string}> {
    try {
      return {files: (await readdir(this.directory)).filter((name) => name.endsWith(FORCE_ENABLE_RECORD_SUFFIX)).sort()};
    } catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      if (code === "ENOENT") return {files: []};
      return {files: [], error: `could not list ${this.directory}: ${error instanceof Error ? error.message : String(error)}`};
    }
  }

  /** Remove the record file. Returns `undefined` on success, a message on a real failure. */
  async #removeRecord(slot: string): Promise<string | undefined> {
    const path = this.#path(slot);
    try { await unlink(path); return undefined; }
    catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      if (code === "ENOENT") return undefined;
      return `could not remove ${path}: ${error instanceof Error ? error.message : String(error)}`;
    }
  }

  /**
   * Restore the previous binding, then remove the record, and settle **only** when both are done.
   *
   * Called with the slot lock held. On any failure the record stays, the entry stays live (so
   * `retryRestore` works) and the outcome is `restore-failed`; `restored` / `recordRemoved` /
   * `restoreError` say exactly how far it got.
   *
   * The ordering is the whole point of the rework: the old version settled `restored` *before*
   * calling `restore()` and removed the record in a `finally`, so a throwing `restore()` was
   * reported as a successful restore and destroyed the only evidence a restart could have used.
   */
  async #restoreLocked(live: LivePending, reason: string): Promise<void> {
    if (live.settled) return;
    live.closed = true;
    this.#cancelTimer(live);
    live.endedBy = reason;
    if (!live.restored) {
      try {
        await live.request.restore();
        live.restored = true;
        delete live.restoreError;
      } catch (error) {
        live.restoreError = `${reason}: restore failed: ${error instanceof Error ? error.message : String(error)}`;
        live.endedBy = live.restoreError;
        // Deliberately NOT settled: the record stays so the next start (or `retryRestore`) tries
        // again, and `done` reports `restore-failed` rather than a success that did not happen.
        live.outcome = "restore-failed";
        live.resolve("restore-failed");
        return;
      }
    }
    const removal = await this.#removeRecord(live.record.slot);
    if (removal !== undefined) {
      live.recordRemoved = false;
      live.restoreError = `${reason}: the binding was restored, but ${removal}`;
      live.endedBy = live.restoreError;
      live.outcome = "restore-failed";
      live.resolve("restore-failed");
      return;
    }
    live.recordRemoved = true;
    this.#settle(live, "restored");
  }

  #settle(live: LivePending, outcome: ForceEnableOutcome): void {
    if (live.settled) return;
    live.settled = true;
    live.closed = true;
    live.outcome = outcome;
    this.#cancelTimer(live);
    this.#live.delete(live.record.slot);
    live.resolve(outcome);
  }

  #cancelTimer(live: LivePending): void {
    if (live.timer === undefined) return;
    try { this.#cancel(live.timer); }
    catch { /* a cancelled timer is not a failure the caller needs to see */ }
    delete live.timer;
  }

  /** Serialize every operation for one slot; a failure never blocks the next operation. */
  async #withSlotLock<T>(slot: string, operation: () => Promise<T>): Promise<T> {
    const prior = this.#slotLocks.get(slot) ?? Promise.resolve();
    const run = prior.then(operation, operation);
    const tail = run.then(() => undefined, () => undefined);
    this.#slotLocks.set(slot, tail);
    try {
      return await run;
    } finally {
      if (this.#slotLocks.get(slot) === tail) this.#slotLocks.delete(slot);
    }
  }
}
