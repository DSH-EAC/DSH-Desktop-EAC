// Durable transaction journal (task 6.2.5).
//
// Pipeline position: this module makes an in-flight slot transaction *visible across a process
// boundary*. `SlotTransactionCoordinator` decides commit/rollback inside one process and
// `publishActiveSnapshot` moves the live pointer with one atomic rename, but neither of them
// leaves a trace if the process is killed between the two. A record written here before the
// commit point and removed after it is the only durable evidence that distinguishes
//
//   * "the transaction never reached its commit point" (the live snapshot still names the older
//     generation and the committed binding state must not move), from
//   * "the commit point was reached but the binding state write did not finish" (the live snapshot
//     names the new generation and must stay; the split is reconciled on the next start), from
//   * "a clean run" (no record at all).
//
// What this module deliberately does NOT do: it never decides a rollback, it never writes binding
// state, and it never deletes a resolved generation. It records which stage reported progress and
// which stage failed, and it fails closed — an unreadable or corrupt record is reported as such
// instead of being treated as "no transaction was running".
import {lstat, readdir, unlink} from "node:fs/promises";
import {join} from "node:path";
import {AtomicJsonStore} from "../persistence/atomic-json-store.ts";

export const JOURNAL_SCHEMA = "dsh-eac-skin-transaction-journal@1" as const;

/** Stages of `lifecycle-v1` plus the state-write step, in the order they must report progress. */
export const TRANSACTION_STAGES = ["prepare", "preload", "activate", "health", "commit", "persist"] as const;
export type TransactionStage = (typeof TRANSACTION_STAGES)[number];

export type JournalState = "open" | "failed";
export type JournalFailure = {stage: TransactionStage | "begin"; message: string};

export interface JournalRecord {
  schema: typeof JOURNAL_SCHEMA;
  correlationId: string;
  slot: string;
  /** Generation the transaction was trying to publish. */
  generation: number;
  /** Last stage that reported success; `begin` until the first stage acks. */
  stage: TransactionStage | "begin";
  state: JournalState;
  startedAt: string;
  updatedAt: string;
  failure?: JournalFailure;
}

export interface JournalReadResult {
  /** Records that were left open by an interrupted run, oldest first. */
  open: JournalRecord[];
  /** Records a completed run closed out with a failure; kept as diagnosis, never replayed. */
  failed: JournalRecord[];
  /** Files that could not be read at all. Never silently ignored. */
  unreadable: string[];
  /**
   * Set when the journal directory could not be listed for a reason other than "it does not exist".
   * `open` being empty is then *not* evidence that no transaction was running.
   */
  directoryError?: string;
}

const FILE_SUFFIX = ".journal.json";
const CORRELATION = /^[A-Za-z0-9._-]+$/;

function safeCorrelationId(value: string): string {
  if (!CORRELATION.test(value)) throw new RangeError(`correlation id contains characters outside [A-Za-z0-9._-]: ${JSON.stringify(value)}`);
  return value;
}

export class JournalError extends Error {
  readonly code: "JOURNAL_CLOSE_FAILED";
  constructor(code: "JOURNAL_CLOSE_FAILED", message: string) {
    super(`${code}: ${message}`);
    this.name = "JournalError";
    this.code = code;
  }
}

/**
 * One file per transaction under `<directory>`. A file is the unit of atomicity: `AtomicJsonStore`
 * writes it with a temporary file plus a rename, so a torn record is impossible and a record that
 * exists is always complete.
 */
export class TransactionJournal {
  readonly directory: string;

  constructor(directory: string) {
    this.directory = directory;
  }

  /** Record that `slot` is about to publish `generation`. Written before the first stage runs. */
  async begin(input: {slot: string; generation: number; correlationId?: string; now?: string}): Promise<JournalRecord> {
    if (input.slot.length === 0) throw new RangeError("journal slot must be a non-empty string");
    if (!Number.isSafeInteger(input.generation) || input.generation < 1) throw new RangeError(`journal generation must be a positive integer, got ${JSON.stringify(input.generation)}`);
    const correlationId = safeCorrelationId(input.correlationId ?? `${input.slot}-${input.generation}-${process.pid}-${Date.now()}`);
    const timestamp = input.now ?? new Date().toISOString();
    const record: JournalRecord = {
      schema: JOURNAL_SCHEMA,
      correlationId,
      slot: input.slot,
      generation: input.generation,
      stage: "begin",
      state: "open",
      startedAt: timestamp,
      updatedAt: timestamp
    };
    await new AtomicJsonStore<JournalRecord>(this.#path(correlationId)).write(record);
    return record;
  }

  /** Record that `stage` completed. Returns the updated record; the caller keeps passing it on. */
  async advance(record: JournalRecord, stage: TransactionStage, now?: string): Promise<JournalRecord> {
    const next: JournalRecord = {...record, stage, updatedAt: now ?? new Date().toISOString()};
    delete next.failure;
    await new AtomicJsonStore<JournalRecord>(this.#path(record.correlationId)).write(next);
    return next;
  }

  /** Record the stage that failed. The record is kept with `state: "failed"` as diagnosis. */
  async fail(record: JournalRecord, stage: TransactionStage | "begin", cause: unknown, now?: string): Promise<JournalRecord> {
    const next: JournalRecord = {
      ...record,
      stage: stage === "begin" ? record.stage : stage,
      state: "failed",
      updatedAt: now ?? new Date().toISOString(),
      failure: {stage, message: cause instanceof Error ? cause.message : String(cause)}
    };
    await new AtomicJsonStore<JournalRecord>(this.#path(record.correlationId)).write(next);
    return next;
  }

  /**
   * Close a completed transaction: no record is left, so the next start sees a clean run.
   *
   * A record that cannot be removed is reported. It is not a failed transaction — the work was
   * committed — but it is also not a clean run: the leftover record is what a later start reads to
   * decide whether a commit point was reached, so pretending it is gone would be the same class of
   * mistake the force-enable controller had.
   */
  async close(record: JournalRecord): Promise<void> {
    const path = this.#path(record.correlationId);
    try { await unlink(path); }
    catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      if (code === "ENOENT") return;
      throw new JournalError("JOURNAL_CLOSE_FAILED", `could not remove ${path}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Every record on disk. A file that cannot be read is reported in `unreadable` instead of being
   * skipped: "the journal is unreadable" is not the same state as "no transaction was running".
   */
  async read(): Promise<JournalReadResult> {
    let entries: string[];
    try {
      entries = await readdir(this.directory);
    } catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      // A journal directory that does not exist yet is the normal first-run case. Anything else
      // (permissions, a file where the directory should be) must be reported: an empty `open` list
      // would otherwise be read as "no transaction was running", which is exactly the state this
      // module exists to distinguish from "I could not look".
      if (code === "ENOENT" || code === "ENOTDIR") return {open: [], failed: [], unreadable: []};
      return {open: [], failed: [], unreadable: [], directoryError: `could not list ${this.directory}: ${error instanceof Error ? error.message : String(error)}`};
    }
    const open: JournalRecord[] = [];
    const failed: JournalRecord[] = [];
    const unreadable: string[] = [];
    for (const name of entries.filter((entry) => entry.endsWith(FILE_SUFFIX)).sort()) {
      const path = join(this.directory, name);
      const described = await lstat(path).then(
        (info) => (info.isSymbolicLink() ? "link" : info.isFile() ? "file" : "other"),
        () => "absent"
      );
      if (described !== "file") {
        unreadable.push(path);
        continue;
      }
      const result = await new AtomicJsonStore<JournalRecord | undefined>(path).read(undefined);
      if (result.diagnostic || result.value === undefined || !isJournalRecord(result.value)) {
        unreadable.push(path);
        continue;
      }
      if (result.value.state === "open") open.push(result.value);
      else failed.push(result.value);
    }
    open.sort((left, right) => (left.startedAt === right.startedAt ? left.correlationId.localeCompare(right.correlationId) : left.startedAt.localeCompare(right.startedAt)));
    return {open, failed, unreadable};
  }

  #path(correlationId: string): string {
    return join(this.directory, `${correlationId}${FILE_SUFFIX}`);
  }
}

/** Shape check for a record read back from disk: a corrupt file must never be replayed. */
export function isJournalRecord(value: unknown): value is JournalRecord {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const record = value as Partial<JournalRecord>;
  if (record.schema !== JOURNAL_SCHEMA) return false;
  if (typeof record.correlationId !== "string" || record.correlationId.length === 0) return false;
  if (typeof record.slot !== "string" || record.slot.length === 0) return false;
  if (!Number.isSafeInteger(record.generation) || (record.generation as number) < 1) return false;
  if (record.stage !== "begin" && !TRANSACTION_STAGES.includes(record.stage as TransactionStage)) return false;
  if (record.state !== "open" && record.state !== "failed") return false;
  if (typeof record.startedAt !== "string" || typeof record.updatedAt !== "string") return false;
  if (record.failure !== undefined) {
    const failure = record.failure as Partial<JournalFailure>;
    if (typeof failure !== "object" || failure === null) return false;
    if (failure.stage !== "begin" && !TRANSACTION_STAGES.includes(failure.stage as TransactionStage)) return false;
    if (typeof failure.message !== "string") return false;
  }
  return true;
}
