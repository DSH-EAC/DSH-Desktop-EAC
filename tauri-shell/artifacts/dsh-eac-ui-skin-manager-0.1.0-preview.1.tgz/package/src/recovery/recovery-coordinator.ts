// Crash and restart recovery for slot transactions (task 6.2.5).
//
// Pipeline position: this module runs *before* anything else on a manager start. It reads the
// durable transaction journal, the committed binding state and the live snapshot, and decides what
// the previous run left behind. Its job is to make three states distinguishable and to keep the
// invariant that a transaction which never reached its commit point cannot become active:
//
//   1. interrupted before the commit point  -> the live snapshot still names the older generation;
//      the binding state must NOT be advanced to the interrupted generation, the abandoned record
//      is closed, and the interrupted generation (if a tree was staged for it) is *reported*, never
//      silently promoted.
//   2. committed but state not written      -> the live snapshot already names the new generation;
//      the host is serving it, so the tree and the snapshot stay. The split is reported as
//      `RECOVERY_SNAPSHOT_AHEAD_OF_STATE` for the operator to reconcile; this module never rewrites
//      binding state to "fix" it, because that would hide a state-write failure.
//   3. clean                                -> no record, nothing to do.
//
// Rollback order is the one frozen in ADR 0010 §6: previous slot generation -> two retained
// previous-known-good generations -> the bundled, digest-verified default artifact -> the embedded
// fallback. `resolveRollbackChain()` returns that order with per-step availability, and it never
// returns a step whose generation is not strictly older than the committed one, so a stale
// candidate cannot be selected as a rollback target.
//
// Fail-closed rules this module enforces rather than trusts:
//   * a `pending` binding state is never promoted — it is dropped, and the committed (or the
//     previous-known-good) state is what recovery returns;
//   * a corrupt journal or an unreadable binding state is surfaced as `journal_unreadable` /
//     `state_unreadable` with `clean: false`, never as "nothing happened";
//   * a generation whose resolved tree is gone from disk is reported as unavailable, so the chain
//     skips it instead of handing the host a generation it cannot serve.
import {readdir} from "node:fs/promises";
import type {HostProfile, SlotBinding} from "../contracts/models.ts";
import type {BindingGeneration, BindingStore} from "../bindings/binding-store.ts";
import {TransactionJournal, type JournalRecord} from "./transaction-journal.ts";

export type RecoveryOutcome =
  | "clean"
  | "abandoned-before-commit"
  | "committed-state-not-written"
  | "journal-unreadable"
  | "state-unreadable";

export type RecoveryAction =
  | {kind: "none"}
  | {kind: "drop-pending"}
  | {kind: "close-abandoned-record"; correlationId: string; slot: string; generation: number; stage: string}
  | {kind: "reconcile-split"; correlationId: string; slot: string; generation: number}
  | {kind: "report-unreadable"; path: string};

export type RollbackStepKind = "previous-slot-generation" | "previous-known-good" | "default-artifact" | "embedded-fallback";

export interface RollbackStep {
  kind: RollbackStepKind;
  /** Generation to serve, when the step names one. */
  generation?: number;
  /** Package coordinate the step resolves to, when it names one. */
  coordinate?: {id: string; version: string; digest: string};
  /** False when the resolved tree / artifact is not present on this machine. */
  available: boolean;
  /** Why the step is unavailable; present only when `available` is false. */
  reason?: string;
}

export interface RecoveryReport {
  clean: boolean;
  outcome: RecoveryOutcome;
  /** Binding state to use after recovery. `undefined` means "no committed generation yet". */
  bindings?: BindingGeneration;
  /** Ordered rollback chain, best first, ending in the embedded fallback. */
  chain: RollbackStep[];
  actions: RecoveryAction[];
  /** Open records that were closed because they never reached their commit point. */
  abandoned: JournalRecord[];
  /** Open records whose generation is live but whose state write did not land. */
  splits: JournalRecord[];
  diagnostics: string[];
}

export interface RecoverRequest {
  journal: TransactionJournal;
  bindings: BindingStore;
  /** Directory holding `snapshot.json` and `gen-<n>/`. */
  resolvedRoot: string;
  profile: HostProfile;
  /** Generation named by the live snapshot, or `undefined` when there is no readable snapshot. */
  liveGeneration?: number;
  /** Set by the caller when the snapshot file exists but could not be read. */
  snapshotUnreadable?: boolean;
}

/** `gen-<n>` directories present under a resolved root, newest first. */
export async function resolvedGenerations(resolvedRoot: string): Promise<number[]> {
  let entries: string[];
  try {
    entries = await readdir(resolvedRoot);
  } catch {
    return [];
  }
  return entries
    .filter((name) => name.startsWith("gen-"))
    .map((name) => Number.parseInt(name.slice(4), 10))
    .filter((value) => Number.isSafeInteger(value) && value >= 0)
    .sort((left, right) => right - left);
}

/**
 * The rollback chain, best first. `available` is decided from what is on this machine: a generation
 * needs its `gen-<n>` tree, and the default artifact step needs the host profile's fallback
 * coordinate to be the one the build lock pins (that pinning happens in EAC; here the step is
 * reported as available only when the profile still declares a complete fallback coordinate).
 */
export function resolveRollbackChain(input: {
  committedGeneration: number;
  previousGenerations: number[];
  availableGenerations: number[];
  profile: HostProfile;
}): RollbackStep[] {
  const onDisk = new Set(input.availableGenerations);
  const chain: RollbackStep[] = [];
  const seen = new Set<number>();
  // At most two previous-known-good generations are retained, so the chain never offers a third.
  const retained = input.previousGenerations
    .filter((generation) => Number.isSafeInteger(generation) && generation > 0 && generation < input.committedGeneration)
    .sort((left, right) => right - left)
    .filter((generation) => (seen.has(generation) ? false : (seen.add(generation), true)))
    .slice(0, 2);

  for (const generation of retained) {
    chain.push({
      kind: chain.length === 0 ? "previous-slot-generation" : "previous-known-good",
      generation,
      available: onDisk.has(generation),
      ...(onDisk.has(generation) ? {} : {reason: `gen-${generation} is not present under the resolved root`})
    });
  }

  const fallback = input.profile.fallbackSkin;
  const fallbackComplete =
    typeof fallback?.id === "string" && fallback.id.length > 0 &&
    typeof fallback?.version === "string" && fallback.version.length > 0 &&
    typeof fallback?.digest === "string" && /^sha256:[a-f0-9]{64}$/.test(fallback.digest);
  chain.push({
    kind: "default-artifact",
    ...(fallbackComplete ? {coordinate: {id: fallback.id, version: fallback.version, digest: fallback.digest}} : {}),
    available: fallbackComplete,
    ...(fallbackComplete ? {} : {reason: "the host profile declares no complete fallbackSkin coordinate"})
  });

  // The embedded fallback is always present: it is compiled into the host binary and is the last
  // step of the chain by construction. It is never a selectable skin, only a recovery surface.
  chain.push({kind: "embedded-fallback", available: true});
  return chain;
}

/** Bindings the chain would serve if every available step were tried in order. */
export function firstAvailableStep(chain: RollbackStep[]): RollbackStep | undefined {
  return chain.find((step) => step.available);
}

/**
 * Decide what the previous run left behind and produce the state the manager should continue from.
 *
 * Pure with respect to the live generation: it closes abandoned journal records and drops pending
 * state, and it never writes a binding generation, never deletes a resolved tree and never touches
 * the snapshot.
 */
export async function recoverSlotTransactions(request: RecoverRequest): Promise<RecoveryReport> {
  const diagnostics: string[] = [];
  const actions: RecoveryAction[] = [];
  const abandoned: JournalRecord[] = [];
  const splits: JournalRecord[] = [];

  const journalRead = await request.journal.read();
  for (const path of journalRead.unreadable) {
    actions.push({kind: "report-unreadable", path});
    diagnostics.push(`transaction journal record is unreadable and was not replayed: ${path}`);
  }

  const committed = await request.bindings.committed();
  if (committed.diagnostic) diagnostics.push(`committed binding state is corrupt: ${committed.diagnostic}`);
  // A staged (pending) generation is detected by the file's presence, not by a read failure: a
  // missing file is the normal case and must not be reported as an unreadable one.
  const hadPending = await request.bindings.hasPending();

  // A pending state is never active. Recovery drops it; the committed generation (or, when the
  // committed state is missing, the previous-known-good one) is what continues.
  const recovered = await request.bindings.recover();

  const committedGeneration = recovered.generation;
  const previous = (await request.bindings.previousGenerations()).map((entry) => entry.generation);
  const available = await resolvedGenerations(request.resolvedRoot);
  const chain = resolveRollbackChain({
    committedGeneration,
    previousGenerations: previous,
    availableGenerations: available,
    profile: request.profile
  });

  const live = request.liveGeneration;

  for (const record of journalRead.open) {
    const recordIsLive = live !== undefined && record.generation === live;
    if (recordIsLive) {
      // The snapshot names this generation, so the commit point was reached. If the committed
      // binding state has not caught up, the split is real and is reported, not hidden: rewriting
      // the state here would erase the evidence that a state write failed.
      if (committedGeneration < record.generation) {
        splits.push(record);
        actions.push({kind: "reconcile-split", correlationId: record.correlationId, slot: record.slot, generation: record.generation});
        diagnostics.push(
          `generation ${record.generation} of slot ${record.slot} is live but the committed binding state records generation ${committedGeneration}: the snapshot is authoritative for what the host serves and the tree was kept`
        );
        continue;
      }
      // Committed state already caught up: the record is a leftover from a clean-ish run.
      await request.journal.close(record);
      diagnostics.push(`closed leftover journal record ${record.correlationId}: state and snapshot both record generation ${record.generation}`);
      continue;
    }
    // Not live: either the transaction never reached the commit point, or the snapshot was
    // replaced by a newer publish that is not this record. Both mean "do not advance state".
    abandoned.push(record);
    actions.push({kind: "close-abandoned-record", correlationId: record.correlationId, slot: record.slot, generation: record.generation, stage: record.stage});
    diagnostics.push(
      `slot ${record.slot} transaction ${record.correlationId} stopped at stage ${record.stage} before its commit point (live generation ${live ?? "none"}): it is not promoted, the committed generation ${committedGeneration} continues`
    );
    await request.journal.close(record);
  }

  // Actions are ordered by severity so a caller that reads only the first entry sees the most
  // important thing: a live/state split or an unreadable artefact outranks routine housekeeping
  // such as dropping a pending state, which is therefore appended last.
  if (hadPending) actions.push({kind: "drop-pending"});

  let outcome: RecoveryOutcome = "clean";
  // Precedence by severity: an unreadable *host document* outranks an unreadable journal record,
  // which outranks a live/state split, which outranks an abandoned attempt.
  if (request.snapshotUnreadable) outcome = "state-unreadable";
  else if (journalRead.unreadable.length > 0) outcome = "journal-unreadable";
  else if (splits.length > 0) outcome = "committed-state-not-written";
  else if (abandoned.length > 0) outcome = "abandoned-before-commit";

  return {
    clean: outcome === "clean",
    outcome,
    ...(committedGeneration > 0 ? {bindings: recovered} : {}),
    chain,
    actions,
    abandoned,
    splits,
    diagnostics
  };
}

/** Bindings of one generation, keyed by slot, for the fallback decision. */
export function bindingsOf(generation: BindingGeneration | undefined): Record<string, SlotBinding> {
  return generation?.bindings ?? {};
}
