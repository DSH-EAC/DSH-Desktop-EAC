import {validateSkinManifest} from "../contracts/validation.ts";
import {AtomicJsonStore} from "../persistence/atomic-json-store.ts";
import {lockPathFor, withFileLock} from "../persistence/file-lock.ts";
import {mkdir} from "node:fs/promises";
import {dirname} from "node:path";
import type {SkinManifest} from "../contracts/models.ts";

export const CATALOG_INDEX_SCHEMA = "dsh-eac-skin-catalog@1" as const;

export interface InstalledPackage {
  manifest: SkinManifest;
  versionPath: string;
  digest: string;
  source: "local" | "embedded" | "remote";
  signature?: {algorithm: string; value: string; signer?: string};
  refCount?: number;
  official?: boolean;
  /** SHA-256 of the complete installed archive, recomputed from the bytes that were read. */
  archiveSha256?: string;
  /** Container layout the package was accepted from. */
  container?: "canonical" | "dshpack-ui-skin-container";
  /** Manifest member path inside the installed payload. */
  manifestPath?: string;
  installedAt?: string;
}

export interface CatalogIndex {
  schema: typeof CATALOG_INDEX_SCHEMA;
  packages: InstalledPackage[];
}

export interface CatalogLoadDiagnostic {
  code: "PERSISTENCE_CORRUPT" | "PERSISTENCE_INDEX_INVALID" | "PERSISTENCE_ENTRY_INVALID";
  message: string;
  path?: string;
}

export type CatalogPersistErrorCode = "PERSISTENCE_WRITE_FAILED";

export class CatalogPersistError extends Error {
  readonly code: CatalogPersistErrorCode;
  readonly cause?: unknown;
  constructor(code: CatalogPersistErrorCode, message: string, cause?: unknown) {
    super(`${code}: ${message}`);
    this.name = "CatalogPersistError";
    this.code = code;
    if (cause !== undefined) this.cause = cause;
  }
}

const key = (id: string, version: string): string => `${id}@${version}`;

/**
 * In-memory install index with an optional atomic JSON backing file.
 *
 * Without an index path the catalog behaves exactly as before (process-local only). With one,
 * `persist()` writes the whole index atomically and `PackageCatalog.open()` restores it, so an
 * accepted third-party package is still listed after a manager restart.
 *
 * Loading is fail-closed: a corrupt index file, a wrong schema tag, or an entry whose manifest
 * no longer validates is dropped rather than trusted, and the reason is recorded as a diagnostic.
 */
export class PackageCatalog {
  #packages = new Map<string, InstalledPackage>();
  #diagnostics: CatalogLoadDiagnostic[] = [];
  #dirty = false;
  readonly indexPath?: string;

  constructor(indexPath?: string) {
    if (indexPath !== undefined) this.indexPath = indexPath;
  }

  /** Load a catalog from an atomic JSON index. Missing file -> empty catalog. */
  static async open(indexPath: string): Promise<PackageCatalog> {
    const catalog = new PackageCatalog(indexPath);
    const store = new AtomicJsonStore<CatalogIndex>(indexPath);
    const result = await store.read({schema: CATALOG_INDEX_SCHEMA, packages: []});
    if (result.diagnostic) {
      catalog.#diagnostics.push({
        code: "PERSISTENCE_CORRUPT",
        message: result.diagnostic,
        ...(result.backupPath ? {path: result.backupPath} : {})
      });
      return catalog;
    }
    const index = result.value;
    if (!index || typeof index !== "object" || index.schema !== CATALOG_INDEX_SCHEMA || !Array.isArray(index.packages)) {
      catalog.#diagnostics.push({code: "PERSISTENCE_INDEX_INVALID", message: `unexpected index schema ${String((index as CatalogIndex | undefined)?.schema)}`, path: indexPath});
      return catalog;
    }
    for (const entry of index.packages) {
      if (typeof entry !== "object" || entry === null || typeof entry.versionPath !== "string" || typeof entry.digest !== "string") {
        catalog.#diagnostics.push({code: "PERSISTENCE_ENTRY_INVALID", message: "entry is not an InstalledPackage", path: indexPath});
        continue;
      }
      const validation = validateSkinManifest(entry.manifest);
      if (!validation.ok) {
        catalog.#diagnostics.push({code: "PERSISTENCE_ENTRY_INVALID", message: `${entry.manifest?.metadata?.id ?? "<unknown>"}: ${validation.issues.map((item) => item.code).join(",")}`, path: indexPath});
        continue;
      }
      const restored: InstalledPackage = {
        ...entry,
        manifest: validation.value!,
        official: entry.official === true && entry.source === "embedded"
      };
      catalog.#packages.set(key(restored.manifest.metadata.id, restored.manifest.metadata.version), restored);
    }
    return catalog;
  }

  get diagnostics(): CatalogLoadDiagnostic[] { return this.#diagnostics.map((item) => ({...item})); }
  get dirty(): boolean { return this.#dirty; }

  install(input: Omit<InstalledPackage, "refCount" | "official"> & {refCount?: number; official?: boolean}): InstalledPackage {
    const coordinate = key(input.manifest.metadata.id, input.manifest.metadata.version);
    const previous = this.#packages.get(coordinate);
    const item: InstalledPackage = {
      ...input,
      refCount: (previous?.refCount ?? input.refCount ?? 0) + 1,
      official: input.official === true && input.source === "embedded"
    };
    this.#packages.set(coordinate, item);
    this.#dirty = true;
    return {...item};
  }
  get(id: string, version: string): InstalledPackage | undefined { const item = this.#packages.get(key(id, version)); return item && {...item}; }
  list(): InstalledPackage[] { return [...this.#packages.values()].map((item) => ({...item})); }
  uninstall(id: string, version: string): number {
    const coordinate = key(id, version);
    const item = this.#packages.get(coordinate);
    if (!item) return 0;
    const count = Math.max(0, (item.refCount ?? 0) - 1);
    if (count === 0 && item.source !== "embedded") this.#packages.delete(coordinate);
    else this.#packages.set(coordinate, {...item, refCount: count});
    this.#dirty = true;
    return count;
  }

  /** Drop an entry outright (install rollback), regardless of reference count. */
  remove(id: string, version: string): boolean {
    const removed = this.#packages.delete(key(id, version));
    if (removed) this.#dirty = true;
    return removed;
  }

  /**
   * Put an entry back exactly as it was (install rollback). `undefined` deletes it.
   *
   * Used by the installer so a failed attempt restores the *previous* committed entry instead of
   * erasing a package that was already installed at the same coordinate.
   */
  restore(id: string, version: string, entry: InstalledPackage | undefined): void {
    const coordinate = key(id, version);
    if (entry === undefined) {
      if (this.#packages.delete(coordinate)) this.#dirty = true;
      return;
    }
    this.#packages.set(coordinate, {...entry});
    this.#dirty = true;
  }

  /**
   * Atomically write the index. Throws `CatalogPersistError(PERSISTENCE_WRITE_FAILED)` on failure.
   *
   * The whole read-modify-write of `catalog.json` runs under a cross-process lock (6.2.5): the index
   * holds every installed package, so two managers persisting at the same time used to leave the
   * loser's packages out of the file even though their trees were on disk. With the lock the second
   * writer's snapshot is taken after the first one's write, so no entry is dropped. Callers that do
   * not need to wait can pass a shorter `timeoutMs`; a timeout is reported as
   * `PERSISTENCE_WRITE_FAILED` like any other persist failure, never as a silent success.
   */
  async persist(options: {timeoutMs?: number} = {}): Promise<void> {
    if (this.indexPath === undefined) return;
    const indexPath = this.indexPath;
    try {
      // The lock directory lives beside the index, so the index's directory must exist first. That is
      // not a decision about the install root: the catalog was already given this path by its caller.
      await mkdir(dirname(indexPath), {recursive: true});
      await withFileLock(lockPathFor(indexPath), async () => {
        // Re-read inside the lock and merge, rather than writing this instance's snapshot blindly:
        // another manager may have installed something since this process started, and its entry
        // must survive this write. The merge is per coordinate, with this instance's value winning
        // for coordinates it knows about (it is the one that just changed them).
        const disk = await PackageCatalog.open(indexPath);
        const merged = new Map<string, InstalledPackage>();
        for (const entry of disk.list()) merged.set(key(entry.manifest.metadata.id, entry.manifest.metadata.version), entry);
        for (const entry of this.list()) merged.set(key(entry.manifest.metadata.id, entry.manifest.metadata.version), entry);
        const index: CatalogIndex = {schema: CATALOG_INDEX_SCHEMA, packages: [...merged.values()]};
        await new AtomicJsonStore<CatalogIndex>(indexPath).write(index);
      }, {label: `catalog index ${indexPath}`, ...(options.timeoutMs !== undefined ? {timeoutMs: options.timeoutMs} : {})});
      this.#dirty = false;
    } catch (error) {
      throw new CatalogPersistError("PERSISTENCE_WRITE_FAILED", error instanceof Error ? error.message : String(error), error);
    }
  }

  /**
   * Re-read the index from disk, replacing this instance's entries.
   *
   * A caller that is about to install or publish while another manager may have written the index
   * first calls this after taking its own lock, so the write it is about to do is based on the
   * current file rather than on a snapshot from when the process started. Load diagnostics are
   * returned instead of being pushed onto `this.#diagnostics` again.
   */
  async reload(): Promise<CatalogLoadDiagnostic[]> {
    if (this.indexPath === undefined) return [];
    const reopened = await PackageCatalog.open(this.indexPath);
    this.#packages = reopened.#packages;
    this.#dirty = false;
    return reopened.diagnostics;
  }
}
