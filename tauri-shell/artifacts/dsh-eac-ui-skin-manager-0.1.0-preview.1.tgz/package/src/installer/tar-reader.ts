// Dependency-free, read-only USTAR/GNU-tar container reader for the manager package installer.
//
// Why not `tar`/`node:zlib` or a third-party library: the manager must stay dependency-free
// (see package.json) and must never hand an untrusted archive to an external extractor whose
// path/link policy is not ours. This reader only ever returns bytes that were already in
// memory; nothing is written to disk here.
//
// Security properties enforced at parse time (fail closed):
//   R1  every header checksum is recomputed and compared;
//   R2  only regular files and directories are accepted; symlink, hardlink, device, FIFO,
//       GNU long-name/long-link and PAX extension entries are rejected outright;
//   R3  a header field that overflows its octal width is rejected (no silent truncation);
//   R4  the reader stops at the first zero block; the terminator must be followed by
//       zero padding only (no hidden trailing payload);
//   R5  declared member size must equal the real stored byte count.
import {createHash} from "node:crypto";

export const TAR_BLOCK = 512;

/** Stable, category-prefixed codes so callers can map them onto docs/error-codes.md. */
export type ContainerErrorCode =
  | "PATH_UNSAFE"
  | "PATH_ABSOLUTE"
  | "PATH_TRAVERSAL"
  | "PATH_BACKSLASH"
  | "PATH_EMPTY_SEGMENT"
  | "PATH_DUPLICATE_NORMALIZED"
  | "PATH_NESTED_UNDER_FILE"
  | "CONTAINER_TRUNCATED"
  | "CONTAINER_CHECKSUM"
  | "CONTAINER_TRAILING_DATA"
  | "CONTAINER_EMPTY"
  | "CONTAINER_FIELD_OVERFLOW"
  | "CONTAINER_HEADER_INVALID"
  | "LINK_ENTRY_REJECTED"
  | "ENTRY_TYPE_REJECTED"
  | "ENTRY_TOO_MANY"
  | "ENTRY_TOO_LARGE"
  | "ARCHIVE_TOO_LARGE"
  | "ARCHIVE_DIGEST_MISMATCH";

export class ContainerError extends Error {
  readonly code: ContainerErrorCode;
  readonly detail?: string;
  constructor(code: ContainerErrorCode, message: string, detail?: string) {
    super(`${code}: ${message}`);
    this.name = "ContainerError";
    this.code = code;
    if (detail !== undefined) this.detail = detail;
  }
}

export interface TarMember {
  /** Normalized relative path, forward slashes, no trailing slash. */
  path: string;
  /** Directory entries carry no bytes. */
  directory: boolean;
  bytes: Uint8Array;
  mode: number;
}

export interface TarReadResult {
  members: TarMember[];
  /** SHA-256 of the complete archive bytes, computed over exactly what was read. */
  archiveSha256: string;
  totalBytes: number;
}

export interface TarLimits {
  maxEntries: number;
  maxEntryBytes: number;
  /** Ceiling on the sum of declared payload bytes. */
  maxTotalBytes: number;
  /** Ceiling on the raw archive size (headers, padding and payload). */
  maxArchiveBytes: number;
}

export const DEFAULT_TAR_LIMITS: TarLimits = {
  maxEntries: 512,
  maxEntryBytes: 32 * 1024 * 1024,
  maxTotalBytes: 64 * 1024 * 1024,
  maxArchiveBytes: 80 * 1024 * 1024
};

/**
 * Reject a path that is not a canonical relative POSIX path.
 * Mirrors `safePath()` in contracts/validation.ts but is duplicated here on purpose:
 * the container reader must not depend on manifest validation having run.
 */
export function canonicalRelativePath(raw: string): string {
  if (raw.length === 0) throw new ContainerError("PATH_UNSAFE", "empty member path");
  if (raw.includes("\0")) throw new ContainerError("PATH_UNSAFE", "member path contains NUL");
  if (raw.includes("\\")) throw new ContainerError("PATH_BACKSLASH", raw);
  if (raw.startsWith("/")) throw new ContainerError("PATH_ABSOLUTE", raw);
  if (/^[A-Za-z]:/.test(raw)) throw new ContainerError("PATH_ABSOLUTE", raw);
  if (/^\/\//.test(raw)) throw new ContainerError("PATH_ABSOLUTE", raw);
  const parts = raw.split("/");
  for (const part of parts) {
    if (part === "") throw new ContainerError("PATH_EMPTY_SEGMENT", raw);
    if (part === "." || part === "..") throw new ContainerError("PATH_TRAVERSAL", raw);
  }
  return parts.join("/");
}

/** Unicode normalization used only for duplicate detection, never for the on-disk name. */
export function normalizedKey(path: string): string {
  return path.normalize("NFC").toLowerCase();
}

function readString(block: Uint8Array, offset: number, length: number): string {
  let end = offset;
  const limit = offset + length;
  while (end < limit && block[end] !== 0) end += 1;
  return Buffer.from(block.subarray(offset, end)).toString("utf8");
}

function parseOctal(block: Uint8Array, offset: number, length: number, field: string): number {
  let end = offset + length;
  // GNU base-256 encoding is not accepted: it is only produced by tools that are not our producers.
  if ((block[offset]! & 0x80) !== 0) throw new ContainerError("CONTAINER_FIELD_OVERFLOW", `${field} uses base-256 encoding`);
  while (end > offset && (block[end - 1] === 0 || block[end - 1] === 0x20)) end -= 1;
  const text = Buffer.from(block.subarray(offset, end)).toString("ascii");
  if (text.length === 0) return 0;
  if (!/^[0-7]+$/.test(text)) throw new ContainerError("CONTAINER_HEADER_INVALID", `${field} is not octal: ${JSON.stringify(text)}`);
  const value = Number.parseInt(text, 8);
  if (!Number.isSafeInteger(value)) throw new ContainerError("CONTAINER_FIELD_OVERFLOW", `${field} exceeds safe integer range`);
  return value;
}

function verifyChecksum(block: Uint8Array, offset: number): void {
  const stored = parseOctal(block, 148, 8, "checksum");
  let sum = 0;
  for (let index = 0; index < TAR_BLOCK; index += 1) sum += index >= 148 && index < 156 ? 0x20 : block[index]!;
  if (sum !== stored) {
    throw new ContainerError("CONTAINER_CHECKSUM", `header checksum mismatch at byte ${offset} (stored ${stored}, computed ${sum})`);
  }
}

/**
 * Parse a tar archive held entirely in memory.
 *
 * @param data complete archive bytes.
 * @param limits entry-count and size ceilings; the caller owns the policy values.
 * @param expectedArchiveSha256 when provided, the whole-archive digest is verified first.
 */
export function readTar(data: Uint8Array, limits: TarLimits = DEFAULT_TAR_LIMITS, expectedArchiveSha256?: string): TarReadResult {
  if (data.byteLength === 0) throw new ContainerError("CONTAINER_EMPTY", "archive is empty");
  if (data.byteLength > limits.maxArchiveBytes) throw new ContainerError("ARCHIVE_TOO_LARGE", `${data.byteLength} raw bytes > ${limits.maxArchiveBytes}`);
  const archiveSha256 = createHash("sha256").update(data).digest("hex");
  if (expectedArchiveSha256 !== undefined && expectedArchiveSha256 !== archiveSha256) {
    throw new ContainerError("ARCHIVE_DIGEST_MISMATCH", `expected ${expectedArchiveSha256}, computed ${archiveSha256}`);
  }

  const members: TarMember[] = [];
  const seen = new Map<string, string>();
  const filePaths: string[] = [];
  let offset = 0;
  let totalBytes = 0;
  let terminated = false;

  while (offset + TAR_BLOCK <= data.byteLength) {
    const header = data.subarray(offset, offset + TAR_BLOCK);
    if (header.every((byte) => byte === 0)) {
      terminated = true;
      offset += TAR_BLOCK;
      break;
    }
    verifyChecksum(header, offset);

    const typeFlag = String.fromCharCode(header[156]!);
    const size = parseOctal(header, 124, 12, "size");
    const mode = parseOctal(header, 100, 8, "mode");
    const name = readString(header, 0, 100);
    const prefix = readString(header, 345, 155);
    const magic = Buffer.from(header.subarray(257, 262)).toString("ascii");
    if (magic !== "ustar") throw new ContainerError("CONTAINER_HEADER_INVALID", `unsupported header magic ${JSON.stringify(magic)} at byte ${offset}`);

    // R2: reject everything that is not a plain file or directory before looking at the name.
    if (typeFlag === "1" || typeFlag === "2") throw new ContainerError("LINK_ENTRY_REJECTED", `hardlink/symlink member at byte ${offset}`);
    if (typeFlag === "3" || typeFlag === "4" || typeFlag === "6") throw new ContainerError("ENTRY_TYPE_REJECTED", `device/FIFO member at byte ${offset}`);
    if (typeFlag === "L" || typeFlag === "K") throw new ContainerError("ENTRY_TYPE_REJECTED", `GNU long-name/long-link member at byte ${offset}`);
    if (typeFlag === "x" || typeFlag === "g") throw new ContainerError("ENTRY_TYPE_REJECTED", `PAX extended header at byte ${offset}`);
    if (typeFlag !== "0" && typeFlag !== "\0" && typeFlag !== "5" && typeFlag !== "7") {
      throw new ContainerError("ENTRY_TYPE_REJECTED", `unsupported tar type flag ${JSON.stringify(typeFlag)} at byte ${offset}`);
    }

    const directory = typeFlag === "5";
    const rawName = prefix.length > 0 ? `${prefix}/${name}` : name;
    const raw = directory ? rawName.replace(/\/+$/, "") : rawName;
    const path = canonicalRelativePath(raw);
    if (directory && size !== 0) throw new ContainerError("CONTAINER_HEADER_INVALID", `directory member ${path} declares ${size} bytes`);

    // Duplicate detection happens on the normalized form, and a path may not be both a file
    // and an ancestor directory of another member.
    const key = normalizedKey(path);
    const prior = seen.get(key);
    if (prior !== undefined) throw new ContainerError("PATH_DUPLICATE_NORMALIZED", `${path} duplicates ${prior}`);
    for (const existing of filePaths) {
      if (key.startsWith(`${existing}/`) || existing.startsWith(`${key}/`)) {
        throw new ContainerError("PATH_NESTED_UNDER_FILE", `${path} conflicts with ${existing}`);
      }
    }
    seen.set(key, path);

    const padded = Math.ceil(size / TAR_BLOCK) * TAR_BLOCK;
    const dataStart = offset + TAR_BLOCK;
    if (dataStart + size > data.byteLength) throw new ContainerError("CONTAINER_TRUNCATED", `${path} declares ${size} bytes past end of archive`);

    if (!directory) {
      if (size > limits.maxEntryBytes) throw new ContainerError("ENTRY_TOO_LARGE", `${path} is ${size} bytes (limit ${limits.maxEntryBytes})`);
      totalBytes += size;
      if (totalBytes > limits.maxTotalBytes) throw new ContainerError("ARCHIVE_TOO_LARGE", `declared payload ${totalBytes} > ${limits.maxTotalBytes}`);
      filePaths.push(key);
    }
    if (members.length >= limits.maxEntries) throw new ContainerError("ENTRY_TOO_MANY", `${members.length + 1} entries (limit ${limits.maxEntries})`);

    members.push({path, directory, bytes: directory ? new Uint8Array(0) : data.subarray(dataStart, dataStart + size), mode});
    offset = dataStart + padded;
  }

  if (!terminated) throw new ContainerError("CONTAINER_TRUNCATED", "archive has no end-of-archive zero block");
  // R4: nothing but zero padding may follow the terminator.
  for (let index = offset; index < data.byteLength; index += 1) {
    if (data[index] !== 0) throw new ContainerError("CONTAINER_TRAILING_DATA", `non-zero byte at ${index} after end-of-archive marker`);
  }
  if (members.length === 0) throw new ContainerError("CONTAINER_EMPTY", "archive contains no members");

  return {members, archiveSha256, totalBytes};
}

export function sha256Hex(data: Uint8Array): string {
  return createHash("sha256").update(data).digest("hex");
}
