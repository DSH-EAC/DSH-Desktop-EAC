// Manager-side secure import and atomic installation.
//
// Pipeline position: `inspect -> resolve -> verify -> prepare -> ...` (lifecycle-v1). This module
// owns `inspect`/`verify` plus the filesystem half of `prepare`: it never touches an active
// binding, it never enables a package, and it publishes into the catalog only after every byte
// has been written and verified.
//
// Properties that matter for review:
//   * the source archive is actually read (bytes, not just a digest string), through a *bounded*
//     read: the file entry points never call `readFile` on a caller-supplied path, so an oversized
//     source is refused before it is pulled into memory;
//   * nothing is written before the container, manifest, digest, inventory and compatibility
//     gates have all passed;
//   * no write ever traverses a symlink or NTFS junction: every directory from the install root
//     down to the publish target is proven to be a real directory inside the approved boundary,
//     before and after each `mkdir`/`rename`;
//   * the approved boundary is derived once and re-validated before every install, so an install
//     root that was swapped for a junction, moved aside or re-created between two calls is refused
//     instead of redirecting the write;
//   * an already-published coordinate is re-verified against the *complete* expected tree before it
//     is reported as an idempotent hit: canonical manifest bytes, every declared asset (bytes,
//     type and declared permission bits), every attribution file, and the absence of anything
//     extra. A truncated manifest, a repointed contribution, an injected file or a file-level
//     symlink cannot pass as installed;
//   * writes land in a private staging directory and are published with a single atomic rename;
//   * any failure removes the staging directory, rolls the published tree back and restores the
//     *previous* catalog entry, so a failed attempt never erases a package that was already
//     committed at the same coordinate;
//   * a package can never self-declare `official`;
//   * the installed entry is content-addressed by the whole-archive digest, so a re-import of the
//     same bytes is idempotent and a different payload at the same coordinate is a conflict.
import {createHash} from "node:crypto";
import {lstat, readdir, rename, rm} from "node:fs/promises";
import {dirname, join} from "node:path";
import type {SkinManifest} from "../contracts/models.ts";
import type {HostProfile} from "../contracts/models.ts";
import {validateSkinManifest} from "../contracts/validation.ts";
import {PackageCatalog, CatalogPersistError, type InstalledPackage} from "../catalog/package-catalog.ts";
import {DEFAULT_TAR_LIMITS, normalizedKey, type TarLimits} from "./tar-reader.ts";
import {inspectPackage, type InspectedPackage, type InspectionErrorCode} from "./package-inspector.ts";
import {lockPathFor, withFileLock} from "../persistence/file-lock.ts";
import {
  PathGuardError,
  applyFileMode,
  assertBoundaryStable,
  assertNoLinkChain,
  ensureDirectoryChain,
  expectedFileMode,
  isInsideRoot,
  modeMatches,
  prepareRoot,
  readFileBounded,
  resolveRootBoundary,
  type PathGuardErrorCode,
  type RootBoundary
} from "./install-paths.ts";

export type InstallErrorCode =
  | InspectionErrorCode
  | PathGuardErrorCode
  | "INTEGRITY_DIGEST_INVALID"
  | "MANIFEST_COORDINATE_MISMATCH"
  | "INSTALL_CONFLICT"
  | "INSTALL_STATE_DAMAGED"
  | "INSTALL_WRITE_FAILED"
  | "INSTALL_PUBLISH_FAILED"
  | "PERSISTENCE_WRITE_FAILED";

export class InstallError extends Error {
  readonly code: InstallErrorCode;
  readonly cause?: unknown;
  constructor(code: InstallErrorCode, message: string, cause?: unknown) {
    super(`${code}: ${message}`);
    this.name = "InstallError";
    this.code = code;
    if (cause !== undefined) this.cause = cause;
  }
}

export interface ImportResult {
  installed: InstalledPackage;
  /** Never true here: the installer cannot grant official status. */
  official: false;
  /** Absolute directory the package payload was published into. */
  targetPath: string;
  container: InspectedPackage["container"];
  archiveSha256: string;
  /** True when identical bytes were already installed and nothing was rewritten. */
  idempotent: boolean;
}

export interface ImportOptions {
  limits?: TarLimits;
  /** Expected whole-archive SHA-256 (64 lowercase hex or `sha256:<hex>`). */
  expectedArchiveSha256?: string;
  /** When supplied, host compatibility is enforced during inspection. */
  profile?: HostProfile;
  managerVersion?: string;
  hostVersion?: string;
  signature?: {algorithm: string; value: string; signer?: string};
  /** Skip the catalog write (inspection-only / dry run). */
  catalog?: boolean;
  /** How long to wait for the per-coordinate install lock (6.2.5). Default 30 s. */
  lockTimeoutMs?: number;
  /** How long to wait for the catalog index lock (6.2.5). Default 30 s. */
  catalogLockTimeoutMs?: number;
}

export interface InstallerOptions {
  /** Absolute install root. One directory per `<id>/<version>/<archive-sha256>`. */
  root: string;
  catalog: PackageCatalog;
  /**
   * Allow the install root itself to be a symlink/junction. Off by default: an install root that
   * redirects elsewhere is a configuration decision, not something a package may trigger.
   */
  followRootLink?: boolean;
}

const DIGEST_PREFIXED = /^sha256:([a-f0-9]{64})$/;
const DIGEST_BARE = /^[a-f0-9]{64}$/;

function parseExpectedDigest(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;
  const prefixed = DIGEST_PREFIXED.exec(value);
  if (prefixed) return prefixed[1]!;
  if (DIGEST_BARE.test(value)) return value;
  throw new InstallError("INTEGRITY_DIGEST_INVALID", `expected digest is not sha256:<64 hex> or 64 hex: ${JSON.stringify(value)}`);
}

function stagingName(): string {
  return `.staging-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

async function writeFileSynced(path: string, data: Uint8Array, mode?: number): Promise<number | undefined> {
  const {open} = await import("node:fs/promises");
  const handle = await open(path, "w", mode === undefined ? undefined : mode & 0o777);
  try {
    await handle.writeFile(data);
    await handle.sync();
  } finally {
    await handle.close();
  }
  // `open(..., mode)` is subject to the process umask and to the platform's permission model;
  // apply the declared bits explicitly and report what the filesystem actually recorded, so the
  // same value can be required again when the installed tree is re-verified.
  if (mode === undefined) return undefined;
  return applyFileMode(path, mode);
}

function sha256Of(data: Uint8Array): string {
  return createHash("sha256").update(data).digest("hex");
}

/** Re-shape a path-guard failure into an install error without losing the stable code. */
function asInstallError(error: unknown, context: string): InstallError {
  if (error instanceof InstallError) return error;
  if (error instanceof PathGuardError) return new InstallError(error.code, error.message, error);
  return new InstallError("SOURCE_READ_FAILED", `${context}: ${error instanceof Error ? error.message : String(error)}`, error);
}

/** Guard-only translation: every other error keeps its identity. */
function rethrowGuard(error: unknown): never {
  if (error instanceof PathGuardError) throw new InstallError(error.code, error.message, error);
  throw error;
}

export class PackageInstaller {
  private readonly catalog: PackageCatalog;
  private readonly root: string;
  private readonly followRootLink: boolean;
  private rootBoundaryPromise: Promise<RootBoundary> | undefined;

  constructor(catalogOrOptions: PackageCatalog | InstallerOptions, root?: string) {
    if (catalogOrOptions instanceof PackageCatalog) {
      this.catalog = catalogOrOptions;
      this.root = root ?? "";
      this.followRootLink = false;
    } else {
      this.catalog = catalogOrOptions.catalog;
      this.root = catalogOrOptions.root;
      this.followRootLink = catalogOrOptions.followRootLink === true;
    }
    if (this.root.length === 0) throw new InstallError("INSTALL_WRITE_FAILED", "install root must be a non-empty absolute path");
  }

  /**
   * The approved install boundary, created on demand. Cached, but a failure is not cached so a
   * transient problem (for example a volume that is not mounted yet) can be retried.
   */
  private rootBoundary(): Promise<RootBoundary> {
    this.rootBoundaryPromise ??= prepareRoot(this.root, this.followRootLink).catch((error: unknown) => {
      this.rootBoundaryPromise = undefined;
      throw error;
    });
    return this.rootBoundaryPromise;
  }

  /**
   * Boundary to use for this call, after proving the configured root still *is* the directory that
   * was approved. Without this, a root replaced by a junction — or moved aside and re-created at
   * the same path — between two calls would silently change where the next package lands.
   */
  private async currentBoundary(): Promise<RootBoundary> {
    const approved = await this.rootBoundary().catch((error: unknown) => rethrowGuard(error));
    const resolved = await resolveRootBoundary(this.root, this.followRootLink).catch((error: unknown) => rethrowGuard(error));
    try {
      assertBoundaryStable(this.root, approved, resolved);
    } catch (error) {
      rethrowGuard(error);
    }
    return approved;
  }

  /** Inspect without writing anything: useful for a UI preview or an admission decision. */
  inspect(archive: Uint8Array, options: ImportOptions = {}): InspectedPackage {
    return inspectPackage(archive, {
      limits: options.limits ?? DEFAULT_TAR_LIMITS,
      ...(options.expectedArchiveSha256 !== undefined ? {expectedArchiveSha256: parseExpectedDigest(options.expectedArchiveSha256)!} : {}),
      ...(options.profile !== undefined ? {profile: options.profile} : {}),
      ...(options.managerVersion !== undefined ? {managerVersion: options.managerVersion} : {}),
      ...(options.hostVersion !== undefined ? {hostVersion: options.hostVersion} : {})
    });
  }

  /**
   * Install a package from an in-memory archive.
   *
   * The archive must be the canonical SkinPackage artifact (manifest at the root) or an official
   * `.dshpack` container declaring exactly one SkinPackage payload. Generic Feature Pack archives
   * are rejected. Nothing is enabled by this call: the package only becomes listable.
   *
   * The whole install runs under a cross-process lock per *coordinate* (`<root>/<id>/<version>.eac-lock`,
   * 6.2.5). Two managers installing the same coordinate used to race: both saw the target absent,
   * both staged, one lost the `rename` with a bare `INSTALL_PUBLISH_FAILED` and — before 6.2.2b —
   * could delete the winner's tree. With the lock the second call observes the published tree and
   * takes the idempotent path, which is the behaviour the earlier rounds could only document as a
   * limitation. Different coordinates keep different locks and still install in parallel.
   */
  async importArchive(archive: Uint8Array, options: ImportOptions = {}): Promise<ImportResult> {
    const limits = options.limits ?? DEFAULT_TAR_LIMITS;
    const inspected = this.inspect(archive, options);
    const {manifest} = inspected;
    const {id, version} = manifest.metadata;
    const coordinate = `${id}@${version}`;
    const coordinateRoot = join(this.root, id, version);
    if (!isInsideRoot(this.root, coordinateRoot)) {
      throw new InstallError("PATH_OUTSIDE_ROOT", `${coordinateRoot} would fall outside the install root ${this.root}`);
    }
    // The root boundary is proved *before* the lock is taken, so an unusable root fails fast rather
    // than after waiting for a lock.
    const boundary = await this.currentBoundary();
    // The lock lives beside the coordinate directory, so that directory has to exist first. Creating
    // it here (through the same link-refusing chain the install uses) keeps the lock inside the
    // approved boundary; a link planted at `<root>/<id>` is refused now rather than after the lock.
    try {
      await ensureDirectoryChain(this.root, coordinateRoot, boundary.rootReal);
    } catch (error) {
      rethrowGuard(error);
    }
    return withFileLock(lockPathFor(coordinateRoot), () => this.#importLocked(archive, inspected, coordinate, limits, options), {
      label: `install of ${coordinate}`, ...(options.lockTimeoutMs !== undefined ? {timeoutMs: options.lockTimeoutMs} : {})
    });
  }

  async #importLocked(archive: Uint8Array, inspected: InspectedPackage, coordinate: string, limits: TarLimits, options: ImportOptions): Promise<ImportResult> {
    const {manifest} = inspected;
    const {id, version} = manifest.metadata;
    const rootReal = (await this.currentBoundary()).rootReal;
    const coordinateRoot = join(this.root, id, version);
    const target = join(coordinateRoot, inspected.archiveSha256);
    if (!isInsideRoot(this.root, target)) {
      throw new InstallError("PATH_OUTSIDE_ROOT", `${target} would fall outside the install root ${this.root}`);
    }
    const previous = this.catalog.get(id, version);

    // ── Already published at this coordinate ────────────────────────────────────────────────
    const existing = await this.#describePath(target);
    if (existing.kind !== "absent") {
      if (existing.kind === "link") throw new InstallError("PATH_LINK_ESCAPE", `${target} is a symlink/junction`);
      if (existing.kind === "not-a-directory") throw new InstallError("INSTALL_STATE_DAMAGED", `${target} exists and is not a directory`);
      if (previous?.archiveSha256 !== undefined && previous.archiveSha256 !== inspected.archiveSha256) {
        throw new InstallError("INSTALL_CONFLICT", `${coordinate} already holds archive ${previous.archiveSha256}`);
      }
      // The directory is only reported as an idempotent hit after the *whole* expected tree matches
      // byte for byte: a damaged, edited or augmented install must never pass as installed.
      await this.#verifyInstalledTree(target, rootReal, inspected, limits);
      const installed = previous ?? this.catalog.install({
        manifest, versionPath: target, digest: `sha256:${inspected.archiveSha256}`, source: "local",
        ...(options.signature ? {signature: options.signature} : {}),
        archiveSha256: inspected.archiveSha256, container: inspected.container,
        manifestPath: inspected.manifestPath, installedAt: new Date().toISOString(), official: false
      });
      if (options.catalog !== false) await this.catalog.persist({...(options.catalogLockTimeoutMs !== undefined ? {timeoutMs: options.catalogLockTimeoutMs} : {})});
      return {installed, official: false, targetPath: target, container: inspected.container, archiveSha256: inspected.archiveSha256, idempotent: true};
    }

    // ── Fresh install ───────────────────────────────────────────────────────────────────────
    // Create the coordinate directories one level at a time, refusing to write through a link
    // planted at `<root>/<id>` or `<root>/<id>/<version>`.
    try {
      await ensureDirectoryChain(this.root, coordinateRoot, rootReal);
    } catch (error) {
      rethrowGuard(error);
    }
    // The heartbeat for a long install is run by `withFileLock` itself, for the whole critical
    // section and with its failures handled: a second manager must never see a large install as an
    // abandoned lock, and a heartbeat that could not be written must not be swallowed here.
    const staging = join(coordinateRoot, stagingName());
    let published = false;
    try {
      await ensureDirectoryChain(this.root, staging, rootReal);
      const manifestName = inspected.manifestPath.includes("/") ? inspected.manifestPath.split("/").pop()! : inspected.manifestPath;
      const installedModes = new Map<string, number>();
      const recordedManifestMode = await writeFileSynced(join(staging, manifestName), new TextEncoder().encode(inspected.manifestText), 0o644);
      if (recordedManifestMode !== undefined) installedModes.set(normalizedKey(manifestName), recordedManifestMode);
      for (const asset of inspected.assets) {
        const destination = join(staging, ...asset.path.split("/"));
        await ensureDirectoryChain(staging, dirname(destination), rootReal);
        const recorded = await writeFileSynced(destination, asset.bytes, asset.mode);
        if (recorded !== undefined) installedModes.set(normalizedKey(asset.path), recorded);
        const written = await readFileBounded(destination, limits.maxEntryBytes);
        if (sha256Of(written) !== asset.sha256) throw new InstallError("INSTALL_WRITE_FAILED", `${asset.path} changed while being written`);
      }
      // Attribution files travel with the payload: they are not part of the digest inventory but
      // the license/notice obligation follows the package.
      for (const metadata of inspected.metadataFiles) {
        const destination = join(staging, ...metadata.path.split("/"));
        const recorded = await writeFileSynced(destination, metadata.bytes, metadata.mode);
        if (recorded !== undefined) installedModes.set(normalizedKey(metadata.path), recorded);
      }
      // Publish: one rename, no window in which a half-installed tree is visible. The parent chain
      // and the target are re-checked immediately before and after the rename.
      await assertNoLinkChain(this.root, coordinateRoot, rootReal);
      await this.#assertTargetVacant(target);
      try {
        await rename(staging, target);
      } catch (error) {
        throw new InstallError("INSTALL_PUBLISH_FAILED", `could not publish ${coordinate}`, error);
      }
      published = true;
      await assertNoLinkChain(this.root, target, rootReal);

      const installed = this.catalog.install({
        manifest, versionPath: target, digest: `sha256:${inspected.archiveSha256}`, source: "local",
        ...(options.signature ? {signature: options.signature} : {}),
        archiveSha256: inspected.archiveSha256, container: inspected.container,
        manifestPath: inspected.manifestPath, installedAt: new Date().toISOString(), official: false
      });
      if (options.catalog !== false) {
        try {
          await this.catalog.persist({...(options.catalogLockTimeoutMs !== undefined ? {timeoutMs: options.catalogLockTimeoutMs} : {})});
        } catch (error) {
          // Roll back both halves, and restore the entry that was committed before this attempt
          // instead of deleting it: a failed import must not erase a working install.
          this.catalog.restore(id, version, previous);
          await rm(target, {recursive: true, force: true}).catch(() => undefined);
          if (error instanceof CatalogPersistError) throw new InstallError("PERSISTENCE_WRITE_FAILED", error.message, error);
          throw error;
        }
      }
      return {installed, official: false, targetPath: target, container: inspected.container, archiveSha256: inspected.archiveSha256, idempotent: false};
    } catch (error) {
      // Fail closed: never leave a staging tree behind, and undo the publish if it happened.
      await rm(staging, {recursive: true, force: true}).catch(() => undefined);
      if (published) {
        await rm(target, {recursive: true, force: true}).catch(() => undefined);
        this.catalog.restore(id, version, previous);
      }
      rethrowGuard(error);
    }
  }

  /** Convenience wrapper: read the archive from disk with a bounded read, then install it. */
  async importPackageFile(sourcePath: string, options: ImportOptions = {}): Promise<ImportResult> {
    const limits = options.limits ?? DEFAULT_TAR_LIMITS;
    let archive: Uint8Array;
    try {
      archive = await readFileBounded(sourcePath, limits.maxArchiveBytes);
    } catch (error) {
      throw asInstallError(error, `could not read ${sourcePath}`);
    }
    return this.importArchive(archive, options);
  }

  /**
   * Compatibility entry point kept for callers of the stage-1 preview.
   *
   * `sourcePath` is genuinely read and processed through the same bounded read as
   * `importPackageFile`, so both entry points enforce one shared ceiling: its bytes must hash to
   * `digest`, and the archive inside must carry the same package coordinate as `manifest`. The old
   * behaviour (validate a digest string, `mkdir`, register) is gone — see REWORK notes in the
   * delivery doc.
   */
  async importManifest(manifest: SkinManifest, sourcePath: string, digest: string, signature?: {algorithm: string; value: string; signer?: string}, limits: TarLimits = DEFAULT_TAR_LIMITS): Promise<ImportResult> {
    const validation = validateSkinManifest(manifest);
    if (!validation.ok) throw new InstallError("MANIFEST_INVALID", validation.issues.map((item) => item.code).join(","));
    const expected = parseExpectedDigest(digest);
    if (expected === undefined) throw new InstallError("INTEGRITY_DIGEST_INVALID", "digest is required");
    let archive: Uint8Array;
    try {
      archive = await readFileBounded(sourcePath, limits.maxArchiveBytes);
    } catch (error) {
      throw asInstallError(error, `could not read ${sourcePath}`);
    }
    const actual = sha256Of(archive);
    if (actual !== expected) throw new InstallError("INTEGRITY_DIGEST_INVALID", `sourcePath bytes hash to ${actual}, expected ${expected}`);
    const inspected = this.inspect(archive, {expectedArchiveSha256: expected, limits});
    const coordinate = (item: SkinManifest): string => `${item.metadata.id}@${item.metadata.version}`;
    if (coordinate(inspected.manifest) !== coordinate(manifest)) {
      throw new InstallError("MANIFEST_COORDINATE_MISMATCH", `archive declares ${coordinate(inspected.manifest)}, caller passed ${coordinate(manifest)}`);
    }
    return this.importArchive(archive, {expectedArchiveSha256: expected, limits, ...(signature ? {signature} : {})});
  }

  static sha256(data: Uint8Array): string { return sha256Of(data); }

  /** Classify an install-path component without following links. */
  async #describePath(path: string): Promise<{kind: "absent" | "link" | "not-a-directory" | "directory"}> {
    let info;
    try { info = await lstat(path); }
    catch { return {kind: "absent"}; }
    if (info.isSymbolicLink()) return {kind: "link"};
    return info.isDirectory() ? {kind: "directory"} : {kind: "not-a-directory"};
  }

  async #assertTargetVacant(target: string): Promise<void> {
    const described = await this.#describePath(target);
    if (described.kind !== "absent") {
      throw new InstallError(
        described.kind === "link" ? "PATH_LINK_ESCAPE" : "INSTALL_PUBLISH_FAILED",
        `${target} appeared while the package was being staged (${described.kind})`
      );
    }
  }

  /**
   * Prove an existing install directory holds exactly the tree the package declares.
   *
   * Re-reading is the point: `stat()` alone cannot tell a complete install from one whose files
   * were truncated, replaced or deleted, and reporting such a directory as an idempotent hit would
   * hand the host a package that does not match the catalog. The check is therefore a full tree
   * comparison, not a coordinate comparison:
   *
   *   * every entry is inspected with `lstat`, so a file-level symlink or junction is refused even
   *     when its target happens to hold the expected bytes;
   *   * the installed manifest must equal the canonical serialization of the validated manifest, so
   *     a truncated or edited manifest (dropped fields, repointed contribution, widened engines) is
   *     damage even when it still parses and still declares the same coordinate;
   *   * every declared asset must exist, be a regular file, carry the declared permission bits, and
   *     hash to the declared digest;
   *   * every attribution file must exist with its archived bytes;
   *   * nothing else may be present — no extra file, no extra directory, no leftover staging tree.
   */
  async #verifyInstalledTree(target: string, rootReal: string, inspected: InspectedPackage, limits: TarLimits): Promise<void> {
    await assertNoLinkChain(this.root, target, rootReal);
    const manifestName = inspected.manifestPath.includes("/") ? inspected.manifestPath.split("/").pop()! : inspected.manifestPath;
    const damaged = (detail: string): InstallError => new InstallError("INSTALL_STATE_DAMAGED", `${target}: ${detail}`);

    const manifestBytes = await this.#readInstalledFile(join(target, manifestName), limits.maxEntryBytes, damaged, `installed manifest ${manifestName}`);
    if (Buffer.from(manifestBytes).toString("utf8") !== inspected.manifestText) {
      throw damaged(`installed manifest ${manifestName} is not the canonical manifest of ${inspected.manifest.metadata.id}@${inspected.manifest.metadata.version}`);
    }

    const expected = new Map<string, {bytes: Uint8Array; mode: number; kind: "file" | "directory"}>();
    expected.set(normalizedKey(manifestName), {bytes: manifestBytes, mode: expectedFileMode(0o644), kind: "file"});
    for (const asset of inspected.assets) {
      expected.set(normalizedKey(asset.path), {bytes: asset.bytes, mode: expectedFileMode(asset.mode), kind: "file"});
      const parts = asset.path.split("/");
      for (let depth = 1; depth < parts.length; depth += 1) {
        const directoryPath = parts.slice(0, depth).join("/");
        expected.set(normalizedKey(directoryPath), {bytes: new Uint8Array(0), mode: 0o755, kind: "directory"});
      }
    }
    for (const metadata of inspected.metadataFiles) expected.set(normalizedKey(metadata.path), {bytes: metadata.bytes, mode: expectedFileMode(metadata.mode), kind: "file"});

    const seen = new Set<string>();
    const visit = async (directory: string, prefix: string): Promise<void> => {
      for (const entry of await readdir(directory, {withFileTypes: true})) {
        const relativePath = prefix.length > 0 ? `${prefix}/${entry.name}` : entry.name;
        const absolute = join(directory, entry.name);
        const key = normalizedKey(relativePath);
        const info = await lstat(absolute);
        if (info.isSymbolicLink()) throw damaged(`${relativePath} is a symlink/junction; the installed tree must contain real files`);
        const record = expected.get(key);
        if (!record) throw damaged(`${relativePath} is present in the installed tree but not part of the package`);
        if (seen.has(key)) throw damaged(`${relativePath} appears twice in the installed tree`);
        seen.add(key);
        if (record.kind === "directory") {
          if (!info.isDirectory()) throw damaged(`${relativePath} must be a directory`);
          await visit(absolute, relativePath);
          continue;
        }
        if (!info.isFile()) throw damaged(`${relativePath} must be a regular file`);
        if (!modeMatches(info.mode, record.mode)) {
          throw damaged(`${relativePath} has mode ${(info.mode & 0o777).toString(8)}, the package declares ${(record.mode & 0o777).toString(8)}`);
        }
        const bytes = await this.#readInstalledFile(absolute, limits.maxEntryBytes, damaged, relativePath);
        if (sha256Of(bytes) !== sha256Of(record.bytes)) throw damaged(`${relativePath} does not match the package bytes`);
      }
    };
    await visit(target, "");

    for (const [key, record] of expected) {
      if (seen.has(key)) continue;
      throw damaged(`${record.kind === "directory" ? "directory" : "file"} ${key} is missing from the installed tree`);
    }
  }

  /** Read an installed file, turning any read failure into install-state damage. */
  async #readInstalledFile(path: string, maxBytes: number, damaged: (detail: string) => InstallError, label: string): Promise<Uint8Array> {
    try {
      const info = await lstat(path);
      if (info.isSymbolicLink()) throw damaged(`${label} is a symlink/junction`);
      if (!info.isFile()) throw damaged(`${label} is not a regular file`);
      return await readFileBounded(path, maxBytes);
    } catch (error) {
      if (error instanceof InstallError) throw error;
      throw damaged(`${label} is missing or unreadable`);
    }
  }
}
