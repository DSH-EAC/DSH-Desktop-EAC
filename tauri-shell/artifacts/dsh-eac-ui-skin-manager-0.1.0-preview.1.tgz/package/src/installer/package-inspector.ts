// Inspection stage of the manager install pipeline: `inspect -> resolve -> verify -> ...`
//
// Everything here works on bytes that were already read from the source archive. No path from
// the archive is ever written to disk in this stage, and no path is used to *locate* a file on
// the host filesystem — members are looked up in the parsed member table only.
import {ContainerError, DEFAULT_TAR_LIMITS, normalizedKey, readTar, sha256Hex, type TarLimits, type TarMember} from "./tar-reader.ts";
import {validateSkinManifest} from "../contracts/validation.ts";
import type {HostProfile, SkinManifest, ValidationIssue} from "../contracts/models.ts";

/** Manifest file names accepted at the payload root (ADR 0001: `manifest.json`; `skin.json` in current artifacts). */
export const MANIFEST_NAMES = ["skin.json", "manifest.json"] as const;
/** Non-asset files allowed next to the manifest without being declared in `assets`. */
export const PAYLOAD_METADATA_FILES = ["LICENSE", "NOTICE", "THIRD-PARTY-NOTICES.md", "provenance.json"] as const;
/** Generic Feature Pack payload roots. Their presence means the input is not a Skin input. */
export const FEATURE_PACK_PAYLOAD_MARKERS = ["payload/presets/", "payload/skills/", "payload/plugins/"] as const;

export type ContainerKind = "canonical" | "dshpack-ui-skin-container";

export type InspectionErrorCode =
  | ContainerError["code"]
  | "CONTAINER_FORMAT_UNSUPPORTED"
  | "CONTAINER_GENERIC_FEATURE_PACK"
  | "CONTAINER_NO_PAYLOAD"
  | "CONTAINER_MULTIPLE_PAYLOADS"
  | "MANIFEST_MISSING"
  | "MANIFEST_INVALID"
  | "MANIFEST_COORDINATE_MISMATCH"
  | "ASSET_MISSING"
  | "ASSET_UNDECLARED"
  | "INTEGRITY_MISMATCH"
  | "TRUST_SELF_DECLARED_OFFICIAL"
  | "COMPATIBILITY_FAILED";

export class InspectionError extends Error {
  readonly code: InspectionErrorCode;
  readonly issues: ValidationIssue[];
  readonly detail?: string;
  constructor(code: InspectionErrorCode, message: string, issues: ValidationIssue[] = [], detail?: string) {
    super(`${code}: ${message}`);
    this.name = "InspectionError";
    this.code = code;
    this.issues = issues;
    if (detail !== undefined) this.detail = detail;
  }
}

export interface InspectedAsset {
  path: string;
  sha256: string;
  bytes: Uint8Array;
  /** Declared USTAR permission bits (0o644 for the reference producers). */
  mode: number;
}

export interface InspectedMetadataFile {
  /** Archive member path. */
  memberPath: string;
  /** Destination path relative to the installed payload root. */
  path: string;
  bytes: Uint8Array;
  /** Declared USTAR permission bits. */
  mode: number;
  /** SHA-256 of the member bytes, so the installed copy can be re-verified later. */
  sha256: string;
}

export interface InspectedPackage {
  manifest: SkinManifest;
  /**
   * Canonical serialization of the validated manifest. This exact text is what the installer
   * writes and what a later install-state check compares against, so a re-serialized or
   * field-stripped manifest on disk is detected as damage rather than accepted as equivalent.
   */
  manifestText: string;
  /** Manifest member path inside the archive. */
  manifestPath: string;
  /** Prefix every declared asset path is relative to; "" for a canonical artifact. */
  payloadRoot: string;
  container: ContainerKind;
  /** SHA-256 over the complete archive bytes. */
  archiveSha256: string;
  /** Digests of the verified payload files, keyed by declared asset path. */
  assets: InspectedAsset[];
  /**
   * Allowed metadata files (LICENSE, NOTICE, THIRD-PARTY-NOTICES.md, provenance.json) that are
   * present in the archive. They carry attribution obligations, so they are installed alongside
   * the payload even though they are not part of the digest inventory.
   */
  metadataFiles: InspectedMetadataFile[];
  provenance?: unknown;
}

export interface InspectOptions {
  limits?: TarLimits;
  expectedArchiveSha256?: string;
  profile?: HostProfile;
  managerVersion?: string;
  hostVersion?: string;
}

/**
 * Canonical manifest text. The installer writes exactly this and the install-state check compares
 * against exactly this, so the on-disk manifest is either the byte-for-byte canonical form of the
 * validated manifest or it is damage.
 */
export function serializeManifest(manifest: SkinManifest): string {
  return `${JSON.stringify(manifest, null, 2)}\n`;
}

const ZIP_MAGIC = [0x50, 0x4b, 0x03, 0x04];

function looksLikeZip(data: Uint8Array): boolean {
  return data.byteLength >= 4 && ZIP_MAGIC.every((byte, index) => data[index] === byte);
}

function memberPath(member: TarMember): string {
  return member.directory ? `${member.path}/` : member.path;
}

/** Reject generic Feature Pack content: plugins/presets/skills payloads are not Skin inputs. */
function assertNotGenericFeaturePack(members: TarMember[], raw: Uint8Array): void {
  if (looksLikeZip(raw)) {
    throw new InspectionError("CONTAINER_FORMAT_UNSUPPORTED", "input is a ZIP Feature Pack container, not a canonical SkinPackage artifact");
  }
  for (const member of members) {
    const path = memberPath(member);
    for (const marker of FEATURE_PACK_PAYLOAD_MARKERS) {
      if (path === marker || path.startsWith(marker)) {
        throw new InspectionError("CONTAINER_GENERIC_FEATURE_PACK", `${path} is generic Feature Pack content, not a Skin payload`);
      }
    }
  }
  const packJson = members.find((member) => member.path === "pack.json" && !member.directory);
  if (packJson) {
    let parsed: unknown;
    try { parsed = JSON.parse(Buffer.from(packJson.bytes).toString("utf8")); } catch { throw new InspectionError("CONTAINER_GENERIC_FEATURE_PACK", "pack.json is not valid JSON"); }
    const record = parsed as Record<string, unknown> | null;
    if (record && typeof record === "object") {
      for (const key of ["plugins", "presets", "skills"]) {
        const value = record[key];
        if (Array.isArray(value) && value.length > 0) {
          throw new InspectionError("CONTAINER_GENERIC_FEATURE_PACK", `pack.json declares ${key}; that is a Feature Pack, not a SkinPackage`);
        }
      }
    }
  }
}

interface ManifestCandidate {
  manifestPath: string;
  payloadRoot: string;
  container: ContainerKind;
}

/**
 * Locate exactly one SkinPackage payload.
 *
 * Canonical layout: the manifest sits at the archive root.
 * Compatibility layout (`dshpack-ui-skin-container@1`): the manifest sits under a single
 * `packages/<id>/` payload root, which is what the default-skins release artifact uses.
 * Anything that resolves to zero or more than one payload is rejected rather than guessed.
 */
export function locatePayload(members: TarMember[]): ManifestCandidate {
  const files = new Set(members.filter((member) => !member.directory).map((member) => member.path));
  const rootCandidates = MANIFEST_NAMES.filter((name) => files.has(name));
  if (rootCandidates.length > 1) {
    throw new InspectionError("CONTAINER_MULTIPLE_PAYLOADS", `archive declares both ${rootCandidates.join(" and ")} at its root`);
  }
  if (rootCandidates.length === 1) return {manifestPath: rootCandidates[0]!, payloadRoot: "", container: "canonical"};

  const nested = members
    .filter((member) => !member.directory && MANIFEST_NAMES.some((name) => member.path === `packages/${member.path.split("/")[1]}/${name}`))
    .map((member) => member.path);
  if (nested.length === 0) throw new InspectionError("CONTAINER_NO_PAYLOAD", "no skin.json/manifest.json at the archive root or under packages/<id>/");
  const roots = new Set(nested.map((path) => path.split("/").slice(0, 2).join("/")));
  if (roots.size > 1) throw new InspectionError("CONTAINER_MULTIPLE_PAYLOADS", `${nested.length} payloads: ${[...roots].join(", ")}`);
  const payloadRoot = [...roots][0]!;
  return {manifestPath: nested[0]!, payloadRoot, container: "dshpack-ui-skin-container"};
}

/** Reject a package that tries to grant itself official status (ADR 0001 §4.1 / §6). */
export function assertNoSelfDeclaredOfficial(manifest: unknown): void {
  if (typeof manifest !== "object" || manifest === null) return;
  const record = manifest as Record<string, unknown>;
  if (record.official === true) throw new InspectionError("TRUST_SELF_DECLARED_OFFICIAL", "manifest declares official: true");
  const provenance = record.provenance;
  if (typeof provenance === "object" && provenance !== null && (provenance as Record<string, unknown>).official === true) {
    throw new InspectionError("TRUST_SELF_DECLARED_OFFICIAL", "provenance declares official: true");
  }
  const signature = record.signature as Record<string, unknown> | null | undefined;
  if (signature && typeof signature === "object" && (signature.signer === "DSH-EAC" || signature.signer === "official")) {
    throw new InspectionError("TRUST_SELF_DECLARED_OFFICIAL", `signature claims signer ${String(signature.signer)}`);
  }
}

/**
 * Full inspection of an in-memory archive. Returns only after every gate below has passed:
 * container integrity, single payload, manifest schema, per-file byte digests, asset inventory
 * completeness, and (when a profile is supplied) host compatibility.
 */
export function inspectPackage(raw: Uint8Array, options: InspectOptions = {}): InspectedPackage {
  const limits = options.limits ?? DEFAULT_TAR_LIMITS;
  // Format sniffing happens before parsing: a ZIP-based Feature Pack is a different container
  // format entirely and must not be reported as a corrupt tar.
  if (looksLikeZip(raw)) {
    throw new InspectionError("CONTAINER_FORMAT_UNSUPPORTED", "input is a ZIP Feature Pack container, not a canonical SkinPackage artifact");
  }
  const {members, archiveSha256} = readTar(raw, limits, options.expectedArchiveSha256);
  assertNotGenericFeaturePack(members, raw);

  const candidate = locatePayload(members);
  const manifestMember = members.find((member) => member.path === candidate.manifestPath && !member.directory)!;
  let parsedManifest: unknown;
  try {
    parsedManifest = JSON.parse(Buffer.from(manifestMember.bytes).toString("utf8"));
  } catch (error) {
    throw new InspectionError("MANIFEST_MISSING", `manifest is not valid JSON (${error instanceof Error ? error.message : String(error)})`);
  }
  assertNoSelfDeclaredOfficial(parsedManifest);

  const validation = validateSkinManifest(parsedManifest, options.profile ? {profile: options.profile} : {});
  if (!validation.ok) {
    const codes = validation.issues.map((issue) => issue.code);
    const code: InspectionErrorCode = codes.some((item) => item.startsWith("COMPATIBILITY_")) ? "COMPATIBILITY_FAILED" : "MANIFEST_INVALID";
    throw new InspectionError(code, `manifest rejected: ${codes.join(",")}`, validation.issues);
  }
  const manifest = validation.value!;

  const byPath = new Map<string, TarMember>();
  for (const member of members) if (!member.directory) byPath.set(member.path, member);

  const assets: InspectedAsset[] = [];
  const declared = new Set<string>();
  for (const record of manifest.assets) {
    const member = byPath.get(candidate.payloadRoot.length > 0 ? `${candidate.payloadRoot}/${record.path}` : record.path);
    if (!member) throw new InspectionError("ASSET_MISSING", `${record.path} is declared but absent from the archive`);
    const digest = sha256Hex(member.bytes);
    if (digest !== record.sha256) throw new InspectionError("INTEGRITY_MISMATCH", `${record.path}: manifest ${record.sha256}, actual ${digest}`);
    if (manifest.integrity[record.path] !== digest) throw new InspectionError("INTEGRITY_MISMATCH", `${record.path}: integrity map disagrees with the payload bytes`);
    declared.add(normalizedKey(candidate.payloadRoot.length > 0 ? `${candidate.payloadRoot}/${record.path}` : record.path));
    assets.push({path: record.path, sha256: digest, bytes: member.bytes, mode: member.mode});
  }

  // Every archived payload file must be either declared or an explicitly allowed metadata file.
  // Metadata files are accepted both inside the payload root and at the archive root: the official
  // default-skins container keeps `LICENSE`/`THIRD-PARTY-NOTICES.md` beside `packages/<id>/`
  // rather than inside it, and ADR 0001 puts them at the root of a canonical artifact.
  const allowed = new Set<string>([normalizedKey(candidate.manifestPath)]);
  for (const name of PAYLOAD_METADATA_FILES) {
    allowed.add(normalizedKey(name));
    if (candidate.payloadRoot.length > 0) allowed.add(normalizedKey(`${candidate.payloadRoot}/${name}`));
  }
  for (const member of members) {
    if (member.directory) continue;
    const key = normalizedKey(member.path);
    if (declared.has(key) || allowed.has(key)) continue;
    throw new InspectionError("ASSET_UNDECLARED", `${member.path} is archived but neither declared in assets nor an allowed metadata file`);
  }

  const metadataFiles: InspectedMetadataFile[] = [];
  for (const name of PAYLOAD_METADATA_FILES) {
    for (const candidatePath of candidate.payloadRoot.length > 0 ? [`${candidate.payloadRoot}/${name}`, name] : [name]) {
      const member = byPath.get(candidatePath);
      if (!member) continue;
      // Install it at the payload root even when the archive kept it beside the payload root.
      metadataFiles.push({memberPath: member.path, path: name, bytes: member.bytes, mode: member.mode, sha256: sha256Hex(member.bytes)});
      break;
    }
  }

  const provenanceMember = byPath.get(candidate.payloadRoot.length > 0 ? `${candidate.payloadRoot}/provenance.json` : "provenance.json");
  const result: InspectedPackage = {
    manifest, manifestText: serializeManifest(manifest), manifestPath: candidate.manifestPath, payloadRoot: candidate.payloadRoot,
    container: candidate.container, archiveSha256, assets, metadataFiles
  };
  if (provenanceMember) {
    try { result.provenance = JSON.parse(Buffer.from(provenanceMember.bytes).toString("utf8")); } catch { /* provenance is informational only */ }
  }
  return result;
}
