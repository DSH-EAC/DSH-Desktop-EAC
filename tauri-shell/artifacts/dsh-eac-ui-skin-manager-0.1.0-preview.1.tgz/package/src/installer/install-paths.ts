// Filesystem guards for the install path.
//
// The container reader protects against hostile *archive member* names. This module protects the
// other half: the host filesystem the installer writes into. Three properties are enforced here.
//
//   * Bounded source reads. The file entry points never call `readFile` on a caller-supplied path.
//     They open the file, ask the open handle for its size, and then read through a bounded loop
//     that aborts as soon as the ceiling is crossed — so a huge, sparse or concurrently growing
//     file cannot be pulled into memory before the size policy is applied.
//
//   * A stable approved boundary. `prepareRoot()` resolves the configured install root once and
//     returns a `RootBoundary` = canonical path *plus* a directory identity (`dev:ino`). Every
//     later check is given that canonical path explicitly instead of re-deriving a boundary from a
//     caller-supplied path, and `PackageInstaller` re-validates both halves before each install.
//     A root that was replaced by a junction, moved aside and re-created, or re-pointed at another
//     directory between two calls is therefore refused (`PATH_LINK_ESCAPE` / `PATH_ROOT_CHANGED`)
//     instead of silently changing where the next package lands. Path comparison alone is not
//     enough: re-creating a directory at the same path yields the same canonical string but a
//     different directory.
//
//   * No link traversal on the write path. Every directory between the install root and the
//     publish target is proven to be a real directory that resolves inside the approved boundary,
//     reachable without traversing a symlink or an NTFS junction. Checks run before *and* after
//     each `mkdir`/`rename`, so a link planted at `<root>/<id>`, `<root>/<id>/<version>` or at the
//     target itself cannot redirect a write outside the root.
//
// Residual risk, recorded in the delivery notes: a process that can create links inside the
// install root *while* an install is running still wins a race against a same-process check, and a
// directory identity can in principle be recycled by the filesystem after deletion. The guarantee
// here is that no link that exists at check time is ever traversed, that the boundary is stable
// across calls, and that a write is rolled back when the post-check finds a link.
import {chmod, lstat, mkdir, open, realpath, stat} from "node:fs/promises";
import {isAbsolute, join, relative, sep} from "node:path";

export type PathGuardErrorCode =
  | "PATH_LINK_ESCAPE"
  | "PATH_OUTSIDE_ROOT"
  | "PATH_NOT_A_DIRECTORY"
  | "PATH_ROOT_CHANGED"
  | "SOURCE_NOT_A_FILE"
  | "SOURCE_TOO_LARGE"
  | "SOURCE_READ_FAILED";

export class PathGuardError extends Error {
  readonly code: PathGuardErrorCode;
  readonly detail?: string;
  constructor(code: PathGuardErrorCode, message: string, detail?: string) {
    super(`${code}: ${message}`);
    this.name = "PathGuardError";
    this.code = code;
    if (detail !== undefined) this.detail = detail;
  }
}

function errorCode(error: unknown): string | undefined {
  return typeof error === "object" && error !== null && "code" in error ? String((error as {code: unknown}).code) : undefined;
}

/** True when `candidate` is `root` itself or sits below it. Case-insensitive on Windows. */
export function isInsideRoot(root: string, candidate: string): boolean {
  const rel = relative(root, candidate);
  return rel === "" || (!rel.startsWith("..") && !isAbsolute(rel));
}

/** Components of `target` below `root`; throws when `target` is not under `root`. */
function relativeComponents(root: string, target: string): string[] {
  const rel = relative(root, target);
  if (rel === "") return [];
  if (rel.startsWith("..") || isAbsolute(rel)) {
    throw new PathGuardError("PATH_OUTSIDE_ROOT", `${target} is not below the install root ${root}`);
  }
  return rel.split(sep).filter((part) => part.length > 0);
}

/**
 * The directory the installer is allowed to write into: its canonical path plus an identity token
 * (`device:inode`) that distinguishes this directory from another one created later at the same
 * path.
 */
export interface RootBoundary {
  rootReal: string;
  identity: string;
}

/** Identity token for a directory. `ino` is populated on Windows too (NTFS file index). */
export async function boundaryIdentity(path: string): Promise<string> {
  const info = await stat(path);
  return `${info.dev}:${info.ino}`;
}

/**
 * Verify a single path component: it must either not exist yet, or be a real directory whose
 * canonical location is still inside `boundaryReal`. A symlink or junction is rejected outright.
 */
export async function assertRealDirectory(boundaryReal: string, path: string): Promise<void> {
  let info;
  try { info = await lstat(path); }
  catch (error) {
    if (errorCode(error) === "ENOENT") return;
    throw new PathGuardError("PATH_NOT_A_DIRECTORY", `could not inspect ${path}`, String(error));
  }
  if (info.isSymbolicLink()) throw new PathGuardError("PATH_LINK_ESCAPE", `${path} is a symlink/junction`);
  if (!info.isDirectory()) throw new PathGuardError("PATH_NOT_A_DIRECTORY", `${path} exists and is not a directory`);
  const resolved = await realpath(path);
  if (!isInsideRoot(boundaryReal, resolved)) {
    throw new PathGuardError("PATH_OUTSIDE_ROOT", `${path} resolves to ${resolved}, outside ${boundaryReal}`);
  }
}

/**
 * Walk from the install root down to `target` and reject any symlink/junction on the way.
 * Components that do not exist yet are accepted: they are about to be created by the caller.
 *
 * `boundaryReal` is the canonical root returned by `prepareRoot()` and is used as the containment
 * boundary as-is; it is never re-derived from the (mutable) configured root.
 */
export async function assertNoLinkChain(root: string, target: string, boundaryReal: string): Promise<void> {
  let current = root;
  for (const part of relativeComponents(root, target)) {
    current = join(current, part);
    await assertRealDirectory(boundaryReal, current);
  }
}

/**
 * Create every missing directory between the install root and `target`, one level at a time,
 * checking the component before and after each `mkdir`. Unlike `mkdir(..., {recursive: true})`
 * this never writes through a link that already exists at an intermediate component.
 */
export async function ensureDirectoryChain(root: string, target: string, boundaryReal: string): Promise<void> {
  let current = root;
  for (const part of relativeComponents(root, target)) {
    current = join(current, part);
    await assertRealDirectory(boundaryReal, current);
    try { await mkdir(current); }
    catch (error) {
      if (errorCode(error) !== "EEXIST") {
        throw new PathGuardError("PATH_NOT_A_DIRECTORY", `could not create ${current}`, String(error));
      }
    }
    await assertRealDirectory(boundaryReal, current);
  }
}

/**
 * Resolve and approve the install root. Creates it on demand.
 *
 * A root that is itself a symlink/junction is refused unless the caller explicitly opted in with
 * `followRootLink`; in that case the link target is approved and becomes the boundary.
 */
export async function prepareRoot(root: string, followRootLink: boolean): Promise<RootBoundary> {
  let info;
  try { info = await lstat(root); }
  catch (error) {
    if (errorCode(error) !== "ENOENT") throw new PathGuardError("PATH_NOT_A_DIRECTORY", `could not inspect install root ${root}`, String(error));
    await mkdir(root, {recursive: true});
    info = await lstat(root);
  }
  if (info.isSymbolicLink()) {
    if (!followRootLink) {
      throw new PathGuardError(
        "PATH_LINK_ESCAPE",
        `install root ${root} is a symlink/junction; pass followRootLink to install through it deliberately`
      );
    }
    const target = await lstat(await realpath(root));
    if (!target.isDirectory()) throw new PathGuardError("PATH_NOT_A_DIRECTORY", `install root ${root} does not resolve to a directory`);
    const rootReal = await realpath(root);
    return {rootReal, identity: await boundaryIdentity(rootReal)};
  }
  if (!info.isDirectory()) throw new PathGuardError("PATH_NOT_A_DIRECTORY", `install root ${root} is not a directory`);
  const rootReal = await realpath(root);
  return {rootReal, identity: await boundaryIdentity(rootReal)};
}

/**
 * Re-resolve the configured install root for a later call, without approving anything new.
 *
 * Runs before every install: a root that became a junction (or was moved aside and re-created) is
 * refused here rather than being silently accepted as the new boundary.
 */
export async function resolveRootBoundary(root: string, followRootLink: boolean): Promise<RootBoundary> {
  let info;
  try { info = await lstat(root); }
  catch (error) {
    throw new PathGuardError("PATH_NOT_A_DIRECTORY", `install root ${root} is no longer readable`, String(error));
  }
  if (info.isSymbolicLink()) {
    if (!followRootLink) throw new PathGuardError("PATH_LINK_ESCAPE", `install root ${root} became a symlink/junction after it was approved`);
    const rootReal = await realpath(root);
    const target = await lstat(rootReal);
    if (!target.isDirectory()) throw new PathGuardError("PATH_NOT_A_DIRECTORY", `install root ${root} does not resolve to a directory`);
    return {rootReal, identity: await boundaryIdentity(rootReal)};
  }
  if (!info.isDirectory()) throw new PathGuardError("PATH_NOT_A_DIRECTORY", `install root ${root} is not a directory`);
  const rootReal = await realpath(root);
  return {rootReal, identity: await boundaryIdentity(rootReal)};
}

/** Both halves of the boundary must match: the canonical path *and* the directory it names. */
export function assertBoundaryStable(root: string, approved: RootBoundary, resolved: RootBoundary): void {
  if (resolved.rootReal !== approved.rootReal) {
    throw new PathGuardError(
      "PATH_ROOT_CHANGED",
      `install root ${root} now resolves to ${resolved.rootReal}, not the approved ${approved.rootReal}`
    );
  }
  if (resolved.identity !== approved.identity) {
    throw new PathGuardError(
      "PATH_ROOT_CHANGED",
      `install root ${root} is no longer the directory that was approved (identity ${resolved.identity}, approved ${approved.identity})`
    );
  }
}

/**
 * Permission bits to expect on an installed regular file, given the bits declared in the archive.
 *
 * The mapping is deliberately platform-aware. A POSIX filesystem keeps exactly the declared bits;
 * NTFS without POSIX semantics cannot represent them at all — every writable file reports `0o666`
 * and the read-only attribute shows up as `0o444`. Reporting a mismatch there would flag every
 * healthy install as damaged, while silently skipping the check would let a real permission change
 * through. Comparing against what the platform is actually able to express keeps the check useful
 * on both: an installed file that became read-only (or, on POSIX, more permissive) is still damage.
 */
export function expectedFileMode(declared: number, platform: NodeJS.Platform = process.platform): number {
  const bits = declared & 0o777;
  if (platform !== "win32") return bits;
  return (bits & 0o200) === 0 ? 0o444 : 0o666;
}

/**
 * True when the bits found on disk are acceptable for the bits the archive declared.
 *
 * On POSIX the comparison is exact. On Windows only the property the filesystem actually models is
 * compared — whether the file is writable — so a file that was made read-only is still damage while
 * a filesystem that reports synthetic bits (for example `0o777` on FAT) is not.
 */
export function modeMatches(onDisk: number, declared: number, platform: NodeJS.Platform = process.platform): boolean {
  const expected = expectedFileMode(declared, platform);
  if (platform !== "win32") return (onDisk & 0o777) === expected;
  return ((onDisk & 0o222) === 0) === ((expected & 0o222) === 0);
}

/** Apply the declared bits, then report the bits the platform actually ended up with. */
export async function applyFileMode(path: string, declared: number): Promise<number> {
  const wanted = expectedFileMode(declared);
  try { await chmod(path, wanted); } catch { /* best effort: verification checks what the platform models */ }
  return (await lstat(path)).mode & 0o777;
}

/**
 * Read at most `maxBytes` from `path`.
 *
 * The open handle's own size is checked first (so an oversized file is refused without being read
 * at all) and the read loop re-checks the running total, so a file that grows while it is read is
 * still refused instead of being buffered to completion.
 */
export async function readFileBounded(path: string, maxBytes: number): Promise<Uint8Array> {
  let handle;
  try { handle = await open(path, "r"); }
  catch (error) {
    throw new PathGuardError("SOURCE_READ_FAILED", `could not open ${path}`, String(error));
  }
  try {
    const info = await handle.stat();
    if (!info.isFile()) throw new PathGuardError("SOURCE_NOT_A_FILE", path);
    if (info.size > maxBytes) throw new PathGuardError("SOURCE_TOO_LARGE", `${path} is ${info.size} bytes (limit ${maxBytes})`);
    const chunks: Uint8Array[] = [];
    let total = 0;
    const buffer = Buffer.allocUnsafe(Math.min(maxBytes + 1, 4 * 1024 * 1024));
    for (;;) {
      const {bytesRead} = await handle.read(buffer, 0, buffer.byteLength, null);
      if (bytesRead === 0) break;
      total += bytesRead;
      if (total > maxBytes) throw new PathGuardError("SOURCE_TOO_LARGE", `${path} exceeds ${maxBytes} bytes while being read`);
      chunks.push(new Uint8Array(buffer.subarray(0, bytesRead)));
    }
    const out = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { out.set(chunk, offset); offset += chunk.length; }
    return out;
  } finally {
    await handle.close();
  }
}
