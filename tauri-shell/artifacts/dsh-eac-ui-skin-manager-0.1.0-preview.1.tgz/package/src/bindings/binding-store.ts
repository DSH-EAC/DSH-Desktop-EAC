// Committed / staged / previous binding state (task 6.2.2, hardened in 6.2.5 for concurrent writers).
//
// This is the durable record of which generation each slot is bound to. Recovery trusts it, the host
// is reconciled against it, and it is written on every publish, so it has to behave correctly when
// two publishes overlap inside one manager process:
//
//   * **`commit` is serialized per store instance.** `commit` is a read-modify-write of three files
//     (`previous-known-good.json`, `previous-generations.json`, `committed.json`). Two interleaved
//     commits could otherwise both read the same "current" generation, both push it into the
//     history, and one of them could land `previous-generations.json` last with a history that does
//     not contain the generation that was committed in between — losing a rollback target. The
//     queue makes each commit observe the previous one's result.
//   * **A failed `unlink` of the staged file is reported, not swallowed.** The old code used
//     `.catch(() => undefined)`; an `EPERM` (the file is read-only or held open by another process
//     on Windows) then looked exactly like success while `pending.json` was still on disk. Recovery
//     would keep reporting a pending generation that had in fact already been committed. A missing
//     file is still fine — that is the normal case.
//   * **`recover` drops a staged generation and reports the dropped generation**, so a caller can
//     see what was discarded instead of only that recovery ran.
//   * **Concurrent `recover` calls for one directory are serialized too** (via the shared queue in
//     `atomic-json-store.ts`), because dropping `pending.json` while another recovery is reading it
//     is the same read-modify-write hazard in a different shape.
import {mkdir, unlink, lstat} from "node:fs/promises";
import {join} from "node:path";
import type {SlotBinding} from "../contracts/models.ts";
import {AtomicJsonStore, withPathLock} from "../persistence/atomic-json-store.ts";

export interface BindingGeneration {generation: number; bindings: Record<string, SlotBinding>}
export interface BindingReadResult {value?: BindingGeneration; backupPath?: string; diagnostic?: string}
export interface QuarantineRecord {packageId: string; slot: string; reason: string; timestamp: string}

/** What `recover()` had to discard, so the caller can report it instead of guessing. */
export interface BindingRecoveryResult {
  value: BindingGeneration;
  /** Generation named by the staged state that was dropped, when there was one. */
  droppedPendingGeneration?: number;
  /** Set when the staged file existed but could not be removed; the staged state is still there. */
  pendingRemovalFailed?: string;
}

export class BindingStore {
  readonly directory: string;
  readonly committedPath: string;
  readonly pendingPath: string;
  readonly draftPath: string;
  readonly previousPath: string;
  /** Serializes this instance's own `commit` calls; see the note at the top of the file. */
  #commits: Promise<unknown> = Promise.resolve();

  constructor(directory: string) {
    this.directory = directory; this.committedPath = join(directory, "committed.json"); this.pendingPath = join(directory, "pending.json"); this.draftPath = join(directory, "selected-draft.json"); this.previousPath = join(directory, "previous-known-good.json");
  }

  async stage(value: BindingGeneration): Promise<void> { await new AtomicJsonStore<BindingGeneration>(this.pendingPath).write(value); }
  async selectDraft(value: BindingGeneration): Promise<void> { await new AtomicJsonStore<BindingGeneration>(this.draftPath).write(value); }

  async quarantine(packageId: string, slot: string, reason: string): Promise<void> {
    // Read-modify-write of one file shared by all slots: serialize it, or two concurrent
    // quarantines can each read the same list and the second write drops the first record.
    //
    // The lock key is deliberately *not* the quarantine file's own path: `AtomicJsonStore.write`
    // already serializes writes to that path, and taking the same key here would deadlock against
    // the write it guards (a non-reentrant queue waiting on itself). A distinct key for the
    // read-modify-write sequence is what is needed.
    const quarantinePath = join(this.directory, "quarantine.json");
    await withPathLock(`${quarantinePath}#sequence`, async () => {
      const result = await new AtomicJsonStore<QuarantineRecord[]>(quarantinePath).read([]);
      const records = (result.value ?? []).filter((item) => !(item.packageId === packageId && item.slot === slot));
      records.push({packageId, slot, reason, timestamp: new Date().toISOString()});
      await new AtomicJsonStore<QuarantineRecord[]>(quarantinePath).write(records);
    });
  }

  async isQuarantined(packageId: string, slot: string): Promise<QuarantineRecord | undefined> {
    const result = await new AtomicJsonStore<QuarantineRecord[]>(join(this.directory, "quarantine.json")).read([]);
    return (result.value ?? []).find((item) => item.packageId === packageId && item.slot === slot);
  }

  async previousGenerations(): Promise<BindingGeneration[]> {
    const result = await new AtomicJsonStore<BindingGeneration[]>(join(this.directory, "previous-generations.json")).read([]);
    return (result.value ?? []).sort((left, right) => right.generation - left.generation).slice(0, 2);
  }

  /**
   * Commit a generation: roll the current one into the retained history, then write the new one.
   *
   * Serialized per instance, so the history a caller reads is the history the previous commit left.
   * A commit whose generation is not newer than the committed one is refused rather than applied:
   * letting an older generation overwrite a newer committed one is the failure that makes a
   * rollback chain point at the wrong tree.
   */
  commit(value: BindingGeneration): Promise<void> {
    const run = this.#commits.then(() => this.#commitNow(value), () => this.#commitNow(value));
    this.#commits = run.then(() => undefined, () => undefined);
    return run;
  }

  async #commitNow(value: BindingGeneration): Promise<void> {
    await mkdir(this.directory, {recursive: true});
    const current = await this.committed();
    if (current.value && value.generation < current.value.generation) {
      throw new RangeError(`refusing to commit generation ${value.generation}: generation ${current.value.generation} is already committed`);
    }
    if (current.value && value.generation === current.value.generation) {
      // Same generation committed twice (a retry after a partial write). The history must not gain a
      // duplicate of the generation that is already current.
      await new AtomicJsonStore<BindingGeneration>(this.committedPath).write(value);
      return;
    }
    if (current.value) {
      await new AtomicJsonStore<BindingGeneration>(this.previousPath).write(current.value);
      const history = await this.previousGenerations();
      const next = [current.value, ...history.filter((item) => item.generation !== current.value!.generation)].slice(0, 2);
      await new AtomicJsonStore<BindingGeneration[]>(join(this.directory, "previous-generations.json")).write(next);
    }
    await new AtomicJsonStore<BindingGeneration>(this.committedPath).write(value);
    await this.#dropPending("after committing");
  }

  async committed(): Promise<BindingReadResult> { return this.#read(this.committedPath); }
  async pending(): Promise<BindingReadResult> { return this.#read(this.pendingPath); }
  async draft(): Promise<BindingReadResult> { return this.#read(this.draftPath); }
  async previous(): Promise<BindingReadResult> { return this.#read(this.previousPath); }

  /**
   * Whether a staged (pending) generation is actually on disk.
   *
   * `pending()` cannot answer this: a missing file and a corrupt file both come back without a
   * value, and recovery must not treat "there was never a pending state" as "a pending state was
   * unreadable" (or the other way round). This asks the filesystem directly.
   */
  async hasPending(): Promise<boolean> {
    try { return (await lstat(this.pendingPath)).isFile(); }
    catch { return false; }
  }

  /**
   * Drop the staged generation and return the state to continue from.
   *
   * Serialized per directory across every store instance: a publish's commit and a start's recovery
   * can both be dropping `pending.json` for the same state directory, and neither may read the
   * other's half-finished removal as "there was no staged state". `commit` deliberately does *not*
   * take this lock for its own drop (it would nest inside the commit queue); the drop it performs is
   * an unlink, which is atomic on its own.
   */
  async recover(): Promise<BindingGeneration> {
    return (await this.recoverDetailed()).value;
  }

  /**
   * Same as `recover`, plus what had to be discarded and whether the staged file could actually be
   * removed. Recovery uses this form: "the state to continue from" is not the whole answer when a
   * staged generation could not be dropped.
   */
  recoverDetailed(): Promise<BindingRecoveryResult> {
    return withPathLock(this.pendingPath, () => this.#recoverNow());
  }

  async #recoverNow(): Promise<BindingRecoveryResult> {
    const committed = await this.committed();
    const staged = (await this.pending()).value;
    const removal = await this.#dropPending("during recovery");
    const result: BindingRecoveryResult = {value: committed.value ?? {generation: 0, bindings: {}}};
    if (staged) result.droppedPendingGeneration = staged.generation;
    if (removal) result.pendingRemovalFailed = removal;
    if (committed.value) return result;
    const previous = await this.previous();
    return {...result, value: previous.value ?? result.value};
  }

  /**
   * Remove the staged file, reporting a real failure.
   *
   * `ENOENT` is the normal case (there was no staged state, or it was already dropped). Anything
   * else — `EPERM` on a read-only file, `EBUSY` while another process holds it open — is returned
   * to the caller: silently ignoring it leaves a staged generation on disk that the next recovery
   * will report again, and the manager would have claimed a state it never reached.
   */
  async #dropPending(context: string): Promise<string | undefined> {
    try { await unlink(this.pendingPath); return undefined; }
    catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      if (code === "ENOENT") return undefined;
      return `could not remove ${this.pendingPath} ${context}: ${error instanceof Error ? error.message : String(error)}`;
    }
  }

  async #read(path: string): Promise<BindingReadResult> {
    const result = await new AtomicJsonStore<BindingGeneration | undefined>(path).read(undefined);
    return {value: result.value, ...(result.backupPath ? {backupPath: result.backupPath} : {}), ...(result.diagnostic ? {diagnostic: result.diagnostic} : {})};
  }
}
