// Manager-side production of the frozen cross-repo document
// `dsh-eac-active-binding-snapshot@1` plus the resolved asset tree the host consumes.
//
// Pipeline position: this is the manager's *export* edge. It runs after install (6.2.2) and after
// a slot transaction has decided which contribution is active for each slot. It owns:
//
//   * the complete binding set: one binding per host-profile slot, so an untouched slot keeps its
//     previous package (normally `system.default`) instead of being silently dropped;
//   * the resolved asset tree: every CSS asset the active contributions declare is copied out of
//     the installed package, digest-verified against the manifest's `integrity` map, and written
//     under a generation directory that no reader can reach until the snapshot names it;
//   * the snapshot document itself: profile version, committed generation, complete bindings,
//     resolved asset digests and a creation timestamp, written with one atomic rename.
//
// Asset addresses are immutable coordinates, never bare package ids: a served asset lives at
// `<id>/<version>/<archive sha256>/<asset path>` inside `gen-<n>/`. Two versions of the same package
// id can therefore be bound to two different slots at the same time without either one silently
// shadowing the other's bytes (the previous id-only scheme collapsed them into one key and one
// destination path).
//
// Failure semantics — the commit point is the snapshot rename, and it is exactly one step:
//
//   staging tree -> rename to `gen-<n>` -> write `snapshot.json`  ← COMMIT POINT -> binding state -> prune
//
//   * a failure *before* the commit point removes the generation this call created and leaves the
//     previous snapshot (and therefore the previous active generation) untouched;
//   * a failure *after* it (binding state, prune enumeration, anything else) leaves the new
//     generation live. The commit point is tracked by an explicit `snapshotCommitted` flag set the
//     instant the snapshot write returns — *not* inferred from an error code — so no post-commit
//     failure of any shape can reclaim the tree the host is already reading. A binding-state failure
//     reports `SNAPSHOT_BINDING_COMMIT_FAILED`; other post-commit failures propagate as they are.
//
// An existing `gen-<n>` directory is *refused*, never deleted: it may be the very generation the
// live snapshot names. Generation numbers only move forward, so an existing directory means a
// concurrent publish or a leftover tree, and neither is this call's to destroy.
//
// What this module deliberately does NOT do: it never enables anything by itself, it never
// invents a second package format, and it never relaxes an install gate. A slot that is not in
// the host profile, a package that is not installed, a contribution the package does not declare,
// an asset outside the contribution's inventory, a missing file or a digest mismatch all abort
// the publish with a stable code before any byte reaches the resolved root.
import {createHash} from "node:crypto";
import {lstat, mkdir, open, readdir, rename, rm} from "node:fs/promises";
import {dirname, isAbsolute, join, relative, sep} from "node:path";
import type {HostProfile, SlotBinding, SlotContribution} from "../contracts/models.ts";
import {validateHostProfile, validateSlotBinding} from "../contracts/validation.ts";
import type {InstalledPackage} from "../catalog/package-catalog.ts";
import {PackageCatalog} from "../catalog/package-catalog.ts";
import {BindingStore, type BindingGeneration} from "./binding-store.ts";
import {AtomicJsonStore} from "../persistence/atomic-json-store.ts";
import {lockPathFor, withFileLock} from "../persistence/file-lock.ts";
import {readFileBounded} from "../installer/install-paths.ts";
import type {TransactionJournal, JournalRecord, TransactionStage} from "../recovery/transaction-journal.ts";

/** Frozen schema tag for the document EAC consumes (see docs/ui-skin-cross-repo-interface-versions.md). */
export const ACTIVE_SNAPSHOT_SCHEMA = "dsh-eac-active-binding-snapshot@1" as const;
export const SNAPSHOT_FILE_NAME = "snapshot.json" as const;
export const GENERATION_DIR_PREFIX = "gen-" as const;
/** Two previous-known-good generations are retained, matching `dsh-eac-skin-state@1`. */
export const RETAINED_GENERATIONS = 2 as const;
/** Upper bound for a single served asset, and for the whole resolved inventory. */
export const MAX_RESOLVED_ASSET_BYTES = 8 * 1024 * 1024;
export const MAX_RESOLVED_TOTAL_BYTES = 64 * 1024 * 1024;
export const MAX_RESOLVED_ASSETS = 512;

export type SnapshotErrorCode =
  | "SNAPSHOT_PROFILE_INVALID"
  | "SNAPSHOT_SLOT_UNKNOWN"
  | "SNAPSHOT_SLOT_INCOMPLETE"
  | "SNAPSHOT_PACKAGE_MISSING"
  | "SNAPSHOT_PACKAGE_DIGEST_MISMATCH"
  | "SNAPSHOT_PACKAGE_ADDRESS_UNRESOLVED"
  | "SNAPSHOT_CONTRIBUTION_MISSING"
  | "SNAPSHOT_ASSET_UNDECLARED"
  | "SNAPSHOT_ASSET_MISSING"
  | "SNAPSHOT_ASSET_DIGEST_MISMATCH"
  | "SNAPSHOT_GENERATION_STALE"
  | "SNAPSHOT_GENERATION_EXISTS"
  | "SNAPSHOT_BINDING_COMMIT_FAILED"
  | "SNAPSHOT_PATH_UNSAFE"
  | "SNAPSHOT_WRITE_FAILED";

export class SnapshotError extends Error {
  readonly code: SnapshotErrorCode;
  readonly cause?: unknown;
  constructor(code: SnapshotErrorCode, message: string, cause?: unknown) {
    super(`${code}: ${message}`);
    this.name = "SnapshotError";
    this.code = code;
    if (cause !== undefined) this.cause = cause;
  }
}

/** One resolved asset, addressed by an immutable package coordinate and digest-bound to the bytes. */
export interface SnapshotAsset {
  /**
   * `<id>/<version>/<archive sha256>/<asset path inside the package>`; unique across packages *and*
   * across versions of the same package, so two versions can never claim one address.
   */
  key: string;
  /** Path relative to the resolved root (always `<gen-N>/<key>`). */
  path: string;
  sha256: string;
}

export interface ActiveBindingSnapshot {
  schema: typeof ACTIVE_SNAPSHOT_SCHEMA;
  profile: {id: string; version: string};
  generation: number;
  createdAt: string;
  bindings: SlotBinding[];
  assets: SnapshotAsset[];
  /** Slot -> ordered asset keys the host may serve for that slot. */
  slotAssets: Record<string, string[]>;
  fault: null;
}

export interface SlotSelection {
  slot: string;
  packageId: string;
  packageVersion: string;
}

export interface PublishRequest {
  /** Directory EAC reads: `<resolvedRoot>/snapshot.json` + `<resolvedRoot>/gen-<n>/...`. */
  resolvedRoot: string;
  profile: HostProfile;
  catalog: PackageCatalog;
  /** Explicit per-slot choice. Slots absent from this list keep the profile fallback coordinate. */
  selection: SlotSelection[];
  generation: number;
  /** Persistent binding state; when given, the committed generation must move forward. */
  bindings?: BindingStore;
  /**
   * Durable transaction journal. When given, a record is written before the first stage and is kept
   * while the pipeline runs, so a process killed between the commit point and the state write is
   * distinguishable on the next start (6.2.5). When absent, nothing is recorded.
   */
  journal?: {journal: TransactionJournal; slot: string; correlationId?: string};
  now?: string;
  retainedGenerations?: number;
  /** How long to wait for the per-root publish lock (6.2.5). Default 30 s. */
  lockTimeoutMs?: number;
  limits?: {maxAssetBytes?: number; maxTotalBytes?: number; maxAssets?: number};
  /**
   * Seams for fault injection. Nothing in production passes these: the defaults are the real
   * implementations. They exist so a failure at a specific point of the pipeline can be provoked
   * deterministically instead of only reasoned about — `writeAsset` covers the pre-commit half
   * (staging), `enumerateGenerations` the post-commit half (prune).
   */
  faults?: {
    /** Replaces the generation enumeration the prune step uses; a throwing impl fails the prune. */
    enumerateGenerations?: (resolvedRoot: string) => Promise<number[]>;
    /** Called for each asset key while the generation tree is staged; a throwing impl fails it. */
    writeAsset?: (assetKey: string, destination: string) => void | Promise<void>;
    /**
     * Called at each stage boundary, right after the journal advanced to `stage`. A throwing impl
     * fails the pipeline *at that stage*, which is how the per-stage "no half-commit" matrix is
     * exercised: prepare, preload, activate, health, commit and persist are each provoked in turn.
     */
    failStage?: (stage: TransactionStage) => void | Promise<void>;
  };
}

export interface PublishResult {
  snapshot: ActiveBindingSnapshot;
  snapshotPath: string;
  generationRoot: string;
  /** Bindings exactly as committed, for callers that also persist state. */
  bindings: BindingGeneration;
  /** Keys written for this generation, in slot order, without duplicates. */
  written: string[];
  /** Correlation id of the durable journal record, when one was written. */
  correlationId?: string;
}

const sha256 = (data: Uint8Array): string => createHash("sha256").update(data).digest("hex");
/** 摘要一律带 `sha256:` 前缀：binding、资源清单和宿主白名单用同一种写法，避免两种编码混用。 */
const digestOf = (data: Uint8Array): string => `sha256:${sha256(data)}`;
const coordinate = (id: string, version: string): string => `${id}@${version}`;
const digestHex = (digest: string): string => digest.replace(/^sha256:/, "");
const HEX64 = /^[a-f0-9]{64}$/;

/**
 * The immutable address of an installed package: `<id>/<version>/<archive sha256>`.
 *
 * The archive digest is the only value that pins *which bytes* a coordinate holds, so it is part of
 * every address this module mints. A package whose archive digest cannot be recomputed has no
 * immutable address and is refused rather than addressed by name alone.
 */
function packageAddress(item: InstalledPackage): string {
  const {id, version} = item.manifest.metadata;
  const hex = item.archiveSha256 ?? digestHex(item.digest);
  if (!HEX64.test(hex)) {
    throw new SnapshotError(
      "SNAPSHOT_PACKAGE_ADDRESS_UNRESOLVED",
      `${coordinate(id, version)} has no recomputed archive digest (recorded digest ${JSON.stringify(item.digest)}); it cannot be addressed immutably`
    );
  }
  return `${id}/${version}/${hex}`;
}

/** `<id>/<version>/<hex>` prefix of an asset key, i.e. the address every asset key must carry. */
function addressOfAssetKey(key: string): string {
  return key.split("/").slice(0, 3).join("/");
}

/** Asset path inside a package must be a normalized relative POSIX path. */
function assertAssetPath(path: string, context: string): void {
  const unsafe =
    path.length === 0 ||
    path.includes("\\") ||
    path.includes("\0") ||
    isAbsolute(path) ||
    /^[A-Za-z]:/.test(path) ||
    path.split("/").some((segment) => segment === "" || segment === "." || segment === "..");
  if (unsafe) throw new SnapshotError("SNAPSHOT_PATH_UNSAFE", `${context} is not a normalized relative path: ${JSON.stringify(path)}`);
}

/**
 * Keys are embedded in `/skin/<key>` URLs and in the resolved path, so they are restricted to a
 * conservative character set. This is a whitelist, not an escape: a package cannot widen it.
 */
function assertKey(key: string, context: string): void {
  if (!/^[A-Za-z0-9._/-]+$/.test(key)) {
    throw new SnapshotError("SNAPSHOT_PATH_UNSAFE", `${context} contains characters outside [A-Za-z0-9._/-]: ${JSON.stringify(key)}`);
  }
}

function contributionFor(manifest: InstalledPackage["manifest"], slot: string): SlotContribution {
  const matches = manifest.contributions.filter((contribution) => contribution.slot === slot);
  if (matches.length === 0) {
    throw new SnapshotError("SNAPSHOT_CONTRIBUTION_MISSING", `${coordinate(manifest.metadata.id, manifest.metadata.version)} declares no contribution for slot ${slot}`);
  }
  if (matches.length > 1) {
    throw new SnapshotError("SNAPSHOT_CONTRIBUTION_MISSING", `${coordinate(manifest.metadata.id, manifest.metadata.version)} declares ${matches.length} contributions for slot ${slot}; a slot binding needs exactly one`);
  }
  return matches[0]!;
}

/** CSS assets a contribution exposes to the host for its slot, in stable order. */
function styleAssetsOf(contribution: SlotContribution): string[] {
  const ordered = [contribution.style?.entry, ...(contribution.style?.assets ?? [])].filter((item): item is string => typeof item === "string");
  const unique = [...new Set(ordered)];
  return unique.filter((asset) => asset.endsWith(".css"));
}

function describePath(path: string): Promise<"absent" | "link" | "not-a-file" | "file" | "other"> {
  return lstat(path).then(
    (info) => (info.isSymbolicLink() ? "link" : info.isFile() ? "file" : "other"),
    () => "absent"
  );
}

async function ensureDir(path: string): Promise<void> {
  await mkdir(path, {recursive: true});
}

/** `gen-<n>` directories currently on disk, newest first. */
async function existingGenerations(resolvedRoot: string): Promise<number[]> {
  let entries: string[];
  try {
    entries = await readdir(resolvedRoot);
  } catch {
    return [];
  }
  return entries
    .filter((name) => name.startsWith(GENERATION_DIR_PREFIX))
    .map((name) => Number.parseInt(name.slice(GENERATION_DIR_PREFIX.length), 10))
    .filter((value) => Number.isSafeInteger(value) && value >= 0)
    .sort((left, right) => right - left);
}

/**
 * Generation named by the snapshot currently on disk, if one is readable.
 *
 * A corrupt or absent snapshot names no generation; that is not a reason to overwrite a directory
 * (`SNAPSHOT_GENERATION_EXISTS` still applies), only a reason not to trust it as a freshness bound.
 */
async function liveGeneration(resolvedRoot: string): Promise<number | undefined> {
  try {
    const source = await readFileBounded(join(resolvedRoot, SNAPSHOT_FILE_NAME), MAX_RESOLVED_ASSET_BYTES);
    const parsed = JSON.parse(new TextDecoder().decode(source)) as {generation?: unknown};
    return Number.isSafeInteger(parsed?.generation) ? (parsed.generation as number) : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Publish one active binding snapshot.
 *
 * Deterministic and restart-safe: the generation tree is built under a staging directory and
 * renamed into place, the snapshot is written with an atomic rename (the commit point), and only
 * then is the binding state advanced. A failure before the commit point removes the generation this
 * call created and leaves the previous snapshot (and therefore the previous active generation)
 * untouched; a failure after it keeps the live generation and reports the split.
 *
 * The publish runs under a cross-process lock per resolved root (6.2.5). Two publishes for one root
 * race in a way the freshness check cannot catch on its own: both read the same live generation
 * before either writes, both stage a tree, and the loser's `rename` into `gen-<n>` fails (or, for
 * *different* generation numbers, both trees exist while only one is named by the snapshot the host
 * is about to read). The lock serializes the read of the live generation with the write of the
 * snapshot, so the second publish sees the first one's generation and is refused as stale rather
 * than silently competing.
 */
export async function publishActiveSnapshot(request: PublishRequest): Promise<PublishResult> {
  const profileValidation = validateHostProfile(request.profile);
  if (!profileValidation.ok) {
    throw new SnapshotError("SNAPSHOT_PROFILE_INVALID", profileValidation.issues.map((item) => `${item.code}@${item.path}`).join(","));
  }
  if (!isAbsolute(request.resolvedRoot)) {
    throw new SnapshotError("SNAPSHOT_PATH_UNSAFE", `resolvedRoot must be an absolute path: ${request.resolvedRoot}`);
  }
  // The lock lives beside the snapshot inside the resolved root, so that root has to exist first. A
  // first publish into a fresh root therefore creates it before taking the lock rather than after.
  await ensureDir(request.resolvedRoot);
  return withFileLock(lockPathFor(join(request.resolvedRoot, SNAPSHOT_FILE_NAME)), () => publishActiveSnapshotLocked(request), {
    label: `snapshot publish for ${request.resolvedRoot}`,
    ...(request.lockTimeoutMs !== undefined ? {timeoutMs: request.lockTimeoutMs} : {})
  });
}

async function publishActiveSnapshotLocked(request: PublishRequest): Promise<PublishResult> {
  const profileValidation = validateHostProfile(request.profile);
  if (!profileValidation.ok) {
    throw new SnapshotError("SNAPSHOT_PROFILE_INVALID", profileValidation.issues.map((item) => `${item.code}@${item.path}`).join(","));
  }
  const profile = profileValidation.value!;
  if (!Number.isSafeInteger(request.generation) || request.generation < 1) {
    throw new SnapshotError("SNAPSHOT_GENERATION_STALE", `generation must be a positive integer, got ${JSON.stringify(request.generation)}`);
  }
  if (!isAbsolute(request.resolvedRoot)) {
    throw new SnapshotError("SNAPSHOT_PATH_UNSAFE", `resolvedRoot must be an absolute path: ${request.resolvedRoot}`);
  }

  const limits = {
    maxAssetBytes: request.limits?.maxAssetBytes ?? MAX_RESOLVED_ASSET_BYTES,
    maxTotalBytes: request.limits?.maxTotalBytes ?? MAX_RESOLVED_TOTAL_BYTES,
    maxAssets: request.limits?.maxAssets ?? MAX_RESOLVED_ASSETS
  };

  // ── Slot coverage ───────────────────────────────────────────────────────────────────────────
  const profileSlots = profile.slots.map((slot) => slot.id);
  const seen = new Set<string>();
  for (const selection of request.selection) {
    if (!profileSlots.includes(selection.slot)) {
      throw new SnapshotError("SNAPSHOT_SLOT_UNKNOWN", `${selection.slot} is not a slot of ${profile.id}@${profile.version}`);
    }
    if (seen.has(selection.slot)) {
      throw new SnapshotError("SNAPSHOT_SLOT_INCOMPLETE", `${selection.slot} is selected more than once`);
    }
    seen.add(selection.slot);
  }

  // ── Resolve one package per slot; unselected slots keep the profile fallback coordinate ──────
  const planned: Array<{slot: string; item: InstalledPackage; contribution: SlotContribution; selected: boolean}> = [];
  for (const slot of profileSlots) {
    const choice = request.selection.find((item) => item.slot === slot);
    const id = choice?.packageId ?? profile.fallbackSkin.id;
    const version = choice?.packageVersion ?? profile.fallbackSkin.version;
    const item = request.catalog.get(id, version);
    if (!item) {
      throw new SnapshotError("SNAPSHOT_PACKAGE_MISSING", `${coordinate(id, version)} is not installed in the catalog (needed for slot ${slot})`);
    }
    const expectedDigest = choice ? undefined : profile.fallbackSkin.digest;
    if (expectedDigest !== undefined && item.digest !== expectedDigest) {
      throw new SnapshotError("SNAPSHOT_PACKAGE_DIGEST_MISMATCH", `${coordinate(id, version)} is installed as ${item.digest}, the profile fallback coordinate is ${expectedDigest}`);
    }
    planned.push({slot, item, contribution: contributionFor(item.manifest, slot), selected: choice !== undefined});
  }

  // ── Collect and verify the resolved inventory ───────────────────────────────────────────────
  // Addresses carry the archive digest, so two versions of one package id are two distinct keys and
  // two distinct destinations: neither can shadow or pre-empt the other's verification.
  const assets = new Map<string, SnapshotAsset>();
  const slotAssets: Record<string, string[]> = {};
  let totalBytes = 0;
  for (const entry of planned) {
    const {manifest, versionPath} = entry.item;
    const integrity = manifest.integrity ?? {};
    const address = packageAddress(entry.item);
    const keys: string[] = [];
    for (const assetPath of styleAssetsOf(entry.contribution)) {
      assertAssetPath(assetPath, `${entry.slot} asset`);
      const assetKey = `${address}/${assetPath}`;
      assertKey(assetKey, `${entry.slot} asset key`);
      if (keys.includes(assetKey)) continue;
      const declared = integrity[assetPath];
      if (typeof declared !== "string") {
        throw new SnapshotError("SNAPSHOT_ASSET_UNDECLARED", `${coordinate(manifest.metadata.id, manifest.metadata.version)} does not declare ${assetPath} in its integrity map`);
      }
      if (!manifest.assets.some((asset) => asset.path === assetPath)) {
        throw new SnapshotError("SNAPSHOT_ASSET_UNDECLARED", `${coordinate(manifest.metadata.id, manifest.metadata.version)} does not declare ${assetPath} in its asset inventory`);
      }
      if (!assets.has(assetKey)) {
        if (assets.size >= limits.maxAssets) {
          throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `resolved inventory exceeds ${limits.maxAssets} assets`);
        }
        const source = join(versionPath, ...assetPath.split("/"));
        const described = await describePath(source);
        if (described !== "file") {
          throw new SnapshotError("SNAPSHOT_ASSET_MISSING", `${assetPath} of ${coordinate(manifest.metadata.id, manifest.metadata.version)} is ${described} at ${source}`);
        }
        const bytes = await readFileBounded(source, limits.maxAssetBytes);
        const actual = digestOf(bytes);
        if (actual !== `sha256:${declared}`) {
          throw new SnapshotError("SNAPSHOT_ASSET_DIGEST_MISMATCH", `${assetPath} of ${coordinate(manifest.metadata.id, manifest.metadata.version)} hashes to ${actual}, the manifest declares ${declared}`);
        }
        totalBytes += bytes.byteLength;
        if (totalBytes > limits.maxTotalBytes) {
          throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `resolved inventory exceeds ${limits.maxTotalBytes} bytes`);
        }
        assets.set(assetKey, {
          key: assetKey,
          path: `${GENERATION_DIR_PREFIX}${request.generation}/${assetKey}`,
          sha256: actual
        });
      }
      keys.push(assetKey);
    }
    if (keys.length === 0) {
      throw new SnapshotError("SNAPSHOT_ASSET_UNDECLARED", `${coordinate(manifest.metadata.id, manifest.metadata.version)} declares no CSS asset for slot ${entry.slot}; the host would have nothing to serve`);
    }
    slotAssets[entry.slot] = keys;
  }

  const bindings: BindingGeneration = {
    generation: request.generation,
    bindings: Object.fromEntries(
      planned.map((entry) => [
        entry.slot,
        {
          slot: entry.slot,
          package: {id: entry.item.manifest.metadata.id, version: entry.item.manifest.metadata.version, digest: entry.item.digest},
          contribution: entry.contribution.id,
          generation: request.generation,
          state: "active"
        } satisfies SlotBinding
      ])
    )
  };
  for (const binding of Object.values(bindings.bindings)) {
    const validation = validateSlotBinding(binding);
    if (!validation.ok) {
      throw new SnapshotError("SNAPSHOT_PROFILE_INVALID", `produced binding for ${binding.slot} is invalid: ${validation.issues.map((item) => item.code).join(",")}`);
    }
  }

  // ── Freshness: never republish a generation the resolved root or the binding state already has ─
  const live = await liveGeneration(request.resolvedRoot);
  if (live !== undefined && request.generation <= live) {
    throw new SnapshotError("SNAPSHOT_GENERATION_STALE", `generation ${request.generation} is not newer than the generation ${live} the live snapshot names`);
  }
  if (request.bindings) {
    const committed = await request.bindings.committed();
    const previous = committed.value?.generation ?? 0;
    if (request.generation <= previous) {
      throw new SnapshotError("SNAPSHOT_GENERATION_STALE", `generation ${request.generation} is not newer than the committed generation ${previous}`);
    }
  }

  const generationRoot = join(request.resolvedRoot, `${GENERATION_DIR_PREFIX}${request.generation}`);
  const staging = join(request.resolvedRoot, `.staging-${process.pid}-${Date.now()}`);
  await ensureDir(request.resolvedRoot);
  // A generation directory is only ever created, never reclaimed: an existing one may be exactly
  // what the live snapshot points at, and deleting it would strand that snapshot.
  const occupied = await describePath(generationRoot);
  if (occupied !== "absent") {
    throw new SnapshotError("SNAPSHOT_GENERATION_EXISTS", `${GENERATION_DIR_PREFIX}${request.generation} already exists (${occupied}) at ${generationRoot}; a generation directory is never overwritten or deleted`);
  }
  await rm(staging, {recursive: true, force: true});
  await ensureDir(staging);

  let generationOwned = false;
  /** Set the instant the snapshot rename returns. From then on the tree is live and untouchable. */
  let snapshotCommitted = false;
  /**
   * Durable record for this publish (6.2.5). Written before the first stage and advanced at each
   * stage boundary, so a process that dies mid-pipeline leaves behind enough evidence for the next
   * start to tell "never reached the commit point" from "committed but state not written".
   */
  let record: JournalRecord | undefined;
  const stage = async (name: TransactionStage): Promise<void> => {
    if (record && request.journal) record = await request.journal.journal.advance(record, name);
    await request.faults?.failStage?.(name);
  };
  const failRecord = async (at: TransactionStage | "begin", cause: unknown): Promise<void> => {
    if (record && request.journal) await request.journal.journal.fail(record, at, cause).catch(() => undefined);
  };
  try {
    if (request.journal) {
      record = await request.journal.journal.begin({
        slot: request.journal.slot,
        generation: request.generation,
        ...(request.journal.correlationId !== undefined ? {correlationId: request.journal.correlationId} : {}),
        ...(request.now !== undefined ? {now: request.now} : {})
      });
    }
    await stage("prepare");
    for (const entry of planned) {
      const {manifest, versionPath} = entry.item;
      const address = packageAddress(entry.item);
      for (const assetPath of styleAssetsOf(entry.contribution)) {
        const assetKey = `${address}/${assetPath}`;
        const resolved = assets.get(assetKey);
        if (!resolved) continue;
        const destination = join(staging, ...assetKey.split("/"));
        await ensureDir(dirname(destination));
        await request.faults?.writeAsset?.(assetKey, destination);
        const bytes = await readFileBounded(join(versionPath, ...assetPath.split("/")), limits.maxAssetBytes);
        const handle = await open(destination, "w");
        try {
          await handle.writeFile(bytes);
          await handle.sync();
        } finally {
          await handle.close();
        }
        const written = await readFileBounded(destination, limits.maxAssetBytes);
        if (digestOf(written) !== resolved.sha256) {
          throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `${assetKey} changed while being resolved`);
        }
      }
    }
    await stage("preload");

    // A generation directory is only reachable through the snapshot, so it is safe to rename it
    // into place before the snapshot names it: nothing can read it yet.
    await rename(staging, generationRoot);
    generationOwned = true;
    await stage("activate");

    const snapshot: ActiveBindingSnapshot = {
      schema: ACTIVE_SNAPSHOT_SCHEMA,
      profile: {id: profile.id, version: profile.version},
      generation: request.generation,
      createdAt: request.now ?? new Date().toISOString(),
      bindings: Object.values(bindings.bindings),
      assets: [...assets.values()].sort((left, right) => left.key.localeCompare(right.key)),
      slotAssets,
      fault: null
    };
    await stage("health");

    // ── Commit point ────────────────────────────────────────────────────────────────────────
    // Atomic rename: readers either see the previous snapshot or this one, never a partial file.
    // From here on the host serves this generation, so nothing below may roll the tree back. The
    // flag is set the moment the write returns; every later failure path checks the flag itself
    // rather than inferring "was it committed?" from an error code, so a post-commit failure of an
    // unexpected shape (prune enumeration, an unlink, anything) can never delete the live tree.
    await new AtomicJsonStore<ActiveBindingSnapshot>(join(request.resolvedRoot, SNAPSHOT_FILE_NAME)).write(snapshot);
    snapshotCommitted = true;
    await stage("commit");

    if (request.bindings) {
      try {
        await request.bindings.commit(bindings);
      } catch (error) {
        // The record stays on disk *open* at stage `commit`: the commit point was reached, so the
        // next start must see a record whose generation equals the live generation and report the
        // split instead of promoting state. Marking it `failed` here would hide exactly the
        // evidence recovery needs.
        throw new SnapshotError(
          "SNAPSHOT_BINDING_COMMIT_FAILED",
          `generation ${request.generation} is live and being served, but the manager's binding state was not committed (it still records generation ${(await request.bindings.committed().catch(() => ({value: undefined}))).value?.generation ?? 0}); the tree is kept so the live snapshot stays readable and the split must be reconciled`,
          error
        );
      }
    }
    await stage("persist");

    // Prune older generations only after the new one is live, and never one that is still a
    // rollback target for the binding state. This step runs after the commit point, so it is
    // housekeeping: if it fails, the publish reports the failure but the live generation stays.
    const keep = request.retainedGenerations ?? RETAINED_GENERATIONS;
    const protectedGenerations = new Set<number>();
    if (request.bindings) {
      for (const generation of await request.bindings.previousGenerations().catch(() => [])) {
        protectedGenerations.add(generation.generation);
      }
    }
    const enumerate = request.faults?.enumerateGenerations ?? existingGenerations;
    const older = (await enumerate(request.resolvedRoot)).filter(
      (generation) => generation < request.generation && !protectedGenerations.has(generation)
    );
    for (const generation of older.slice(keep)) {
      await rm(join(request.resolvedRoot, `${GENERATION_DIR_PREFIX}${generation}`), {recursive: true, force: true}).catch(() => undefined);
    }

    // Fully committed and reconciled: the durable record has served its purpose and is removed so
    // the next start reads a clean run. A record that cannot be removed is *not* swallowed: it
    // propagates to the catch below, which keeps the live tree (the commit point was passed) and
    // leaves the record for recovery to report and retry.
    if (record && request.journal) await request.journal.journal.close(record);

    return {
      snapshot,
      snapshotPath: join(request.resolvedRoot, SNAPSHOT_FILE_NAME),
      generationRoot,
      bindings,
      written: [...new Set(Object.values(slotAssets).flat())],
      ...(record ? {correlationId: record.correlationId} : {})
    };
  } catch (error) {
    await rm(staging, {recursive: true, force: true}).catch(() => undefined);
    // Only the generation this call created is cleaned up, and never after the commit point: once
    // the snapshot names it, removing it would break the document the host is reading. The test is
    // the `snapshotCommitted` flag itself, not the shape of the error: any failure that happens
    // after the snapshot write — a binding-state write, a prune enumeration, an unlink, anything —
    // must leave the live tree alone. Inferring "was it committed?" from an error code silently
    // deletes the live generation for every post-commit failure it does not recognise.
    if (generationOwned && !snapshotCommitted) {
      await rm(generationRoot, {recursive: true, force: true}).catch(() => undefined);
    }
    // Pre-commit failures close their record (the abandoned transaction is over); post-commit
    // failures keep it open, because the record is the only durable evidence of the split.
    if (record && request.journal && !snapshotCommitted) {
      await failRecord(record.stage === "begin" ? "begin" : record.stage, error);
    }
    throw error;
  }
}

/** Read back a published snapshot. Missing file -> undefined; unparsable file -> throws. */
export async function readActiveSnapshot(resolvedRoot: string): Promise<ActiveBindingSnapshot | undefined> {
  const path = join(resolvedRoot, SNAPSHOT_FILE_NAME);
  const described = await describePath(path);
  if (described === "absent") return undefined;
  if (described !== "file") throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `${SNAPSHOT_FILE_NAME} is ${described}`);
  const store = new AtomicJsonStore<ActiveBindingSnapshot | undefined>(path);
  const result = await store.read(undefined);
  if (result.diagnostic) throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `${SNAPSHOT_FILE_NAME} is unreadable: ${result.diagnostic}`);
  if (result.value === undefined) throw new SnapshotError("SNAPSHOT_WRITE_FAILED", `${SNAPSHOT_FILE_NAME} is not a snapshot document`);
  return result.value;
}

/**
 * Independent verification of a snapshot against a resolved root, mirroring what EAC does on the
 * consuming side: complete slot coverage, coordinate-bound asset addresses, key/path safety,
 * declared digests and the bytes on disk. Used by the manager's own tests and by
 * `bin/skin-catalog.mjs verify`.
 */
export async function verifyActiveSnapshot(
  snapshot: ActiveBindingSnapshot,
  resolvedRoot: string,
  profile: HostProfile
): Promise<{ok: true; served: number} | {ok: false; code: string; message: string}> {
  if (snapshot.schema !== ACTIVE_SNAPSHOT_SCHEMA) return {ok: false, code: "SNAPSHOT_PROFILE_INVALID", message: `unexpected schema ${snapshot.schema}`};
  if (snapshot.profile.id !== profile.id || snapshot.profile.version !== profile.version) {
    return {ok: false, code: "SNAPSHOT_PROFILE_INVALID", message: `profile ${snapshot.profile.id}@${snapshot.profile.version} does not match ${profile.id}@${profile.version}`};
  }
  if (!Number.isSafeInteger(snapshot.generation) || snapshot.generation < 1) return {ok: false, code: "SNAPSHOT_GENERATION_STALE", message: `generation ${snapshot.generation}`};
  if (snapshot.fault !== null) return {ok: false, code: "SNAPSHOT_PROFILE_INVALID", message: "snapshot carries a fault"};

  const slots = profile.slots.map((slot) => slot.id);
  const bound = new Set<string>();
  // Addresses named by the bindings: every resolved asset must be addressed under one of them, so a
  // snapshot cannot serve bytes labelled as a package it does not bind.
  const boundAddresses = new Set<string>();
  for (const binding of snapshot.bindings) {
    if (!slots.includes(binding.slot)) return {ok: false, code: "SNAPSHOT_SLOT_UNKNOWN", message: `${binding.slot} is not a slot of ${profile.id}@${profile.version}`};
    if (bound.has(binding.slot)) return {ok: false, code: "SNAPSHOT_SLOT_INCOMPLETE", message: `${binding.slot} is bound twice`};
    bound.add(binding.slot);
    if (binding.generation > snapshot.generation) return {ok: false, code: "SNAPSHOT_GENERATION_STALE", message: `${binding.slot} binding generation ${binding.generation} is newer than the snapshot generation ${snapshot.generation}`};
    if (!HEX64.test(digestHex(binding.package.digest))) {
      return {ok: false, code: "SNAPSHOT_PACKAGE_DIGEST_MISMATCH", message: `${binding.slot} package digest ${binding.package.digest} is not sha256:<64 hex>`};
    }
    boundAddresses.add(`${binding.package.id}/${binding.package.version}/${digestHex(binding.package.digest)}`);
  }
  for (const slot of slots) {
    if (!bound.has(slot)) return {ok: false, code: "SNAPSHOT_SLOT_INCOMPLETE", message: `slot ${slot} has no binding`};
  }

  const inventory = new Map(snapshot.assets.map((asset) => [asset.key, asset]));
  if (inventory.size !== snapshot.assets.length) return {ok: false, code: "SNAPSHOT_PATH_UNSAFE", message: "duplicate asset key"};
  const referenced = new Set<string>();
  for (const [slot, keys] of Object.entries(snapshot.slotAssets)) {
    if (!slots.includes(slot)) return {ok: false, code: "SNAPSHOT_SLOT_UNKNOWN", message: `slotAssets names unknown slot ${slot}`};
    for (const assetKey of keys) {
      const record = inventory.get(assetKey);
      if (!record) return {ok: false, code: "SNAPSHOT_ASSET_UNDECLARED", message: `${assetKey} is referenced by ${slot} but not resolved`};
      referenced.add(assetKey);
    }
  }
  for (const assetKey of inventory.keys()) {
    if (!referenced.has(assetKey)) return {ok: false, code: "SNAPSHOT_ASSET_UNDECLARED", message: `${assetKey} is resolved but no slot may serve it`};
  }

  let served = 0;
  for (const record of inventory.values()) {
    assertKey(record.key, "asset key");
    assertAssetPath(record.path, `${record.key} path`);
    if (!boundAddresses.has(addressOfAssetKey(record.key))) {
      return {ok: false, code: "SNAPSHOT_ASSET_UNDECLARED", message: `${record.key} is addressed under ${addressOfAssetKey(record.key)}, which no binding names`};
    }
    // Coordinate, assets and generation agree: the path is the snapshot generation plus the key.
    const expected = `${GENERATION_DIR_PREFIX}${snapshot.generation}/${record.key}`;
    if (record.path !== expected) {
      return {ok: false, code: "SNAPSHOT_PATH_UNSAFE", message: `${record.key} resolves to ${record.path}, expected ${expected}`};
    }
    const absolute = join(resolvedRoot, ...record.path.split("/"));
    const relativePath = relative(resolvedRoot, absolute);
    if (relativePath.startsWith("..") || relativePath.split(sep).includes("..")) {
      return {ok: false, code: "SNAPSHOT_PATH_UNSAFE", message: `${record.key} resolves outside the resolved root`};
    }
    const described = await describePath(absolute);
    if (described !== "file") return {ok: false, code: "SNAPSHOT_ASSET_MISSING", message: `${record.key} is ${described} at ${record.path}`};
    const bytes = await readFileBounded(absolute, MAX_RESOLVED_ASSET_BYTES);
    if (digestOf(bytes) !== record.sha256) return {ok: false, code: "SNAPSHOT_ASSET_DIGEST_MISMATCH", message: `${record.key} does not match its resolved digest`};
    served += 1;
  }
  return {ok: true, served};
}
