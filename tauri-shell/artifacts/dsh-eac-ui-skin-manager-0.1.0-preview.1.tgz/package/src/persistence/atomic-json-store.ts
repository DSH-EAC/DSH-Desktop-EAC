// Atomic JSON persistence (task 6.2.2, hardened in 6.2.5 for concurrent writers).
//
// A write is: temp file in the same directory -> fsync -> rename over the target. The rename makes
// the document either the old bytes or the new bytes, never a torn file, and it is what every
// durable state file in the manager relies on (catalog index, binding state, journal record,
// pending force-enable record).
//
// What the first version got wrong, and what this one guarantees instead:
//
//   * **Concurrent writes to one path are serialized in-process.** Two callers writing the same
//     path at the same time used to race on a temp name built from `pid` and `Date.now()`; inside
//     one process those two values can be identical, so the loser's `rename` found its temp file
//     already moved away and failed with a bare `ENOENT` (reproduced: 8 concurrent writes to one
//     path -> 5 `ENOENT`). The queue below makes the second write start only after the first has
//     finished, which is also what makes last-writer-wins meaningful: without it, an *older*
//     snapshot of a document could be renamed into place after a newer one.
//   * **Temp names are unique per write**, not per millisecond, so a retry inside the same
//     millisecond cannot reuse a name, and the corrupt-file backup below gets a unique name too.
//   * **A failed write never poisons the queue.** The next write still runs; only its own error is
//     reported to its own caller.
//
// The queue is keyed by the exact path string, so callers that address one file through two
// different spellings (a relative and an absolute path, say) get two queues. Every caller in this
// package builds its paths from one configured root, so that is not a case the manager can hit.
import {copyFile, mkdir, readFile, rename, unlink, writeFile as writeFileRaw} from "node:fs/promises";
import {open} from "node:fs/promises";
import {AsyncLocalStorage} from "node:async_hooks";
import {dirname} from "node:path";

export interface JsonReadResult<T> {
  value: T;
  backupPath?: string;
  diagnostic?: string;
}

/** Monotonic suffix so two writes in one millisecond can never share a temp name. */
let writeCounter = 0;

/** Tail of the write chain per path; keeps concurrent writers of one document strictly ordered. */
const writeQueues = new Map<string, Promise<unknown>>();

/** Keys this async context already holds, so re-entering one is a loud error instead of a hang. */
const heldKeys = new AsyncLocalStorage<ReadonlySet<string>>();

/**
 * Run `operation` with exclusive access to `key`, queued behind whatever else is running for it.
 *
 * Used for read-modify-write sequences that span more than one `AtomicJsonStore.write` (the binding
 * history roll, the quarantine list, recovery's drop-staged step). Per-write atomicity is not enough
 * for those: the *sequence* is the unit that must not interleave.
 *
 * The queue is **not reentrant**. Taking a key you already hold would wait for yourself forever, so
 * it throws instead: a nested acquisition is always a bug (the inner caller should either use the
 * lock the outer one already holds, or a distinct key for a distinct sequence).
 */
export async function withPathLock<T>(key: string, operation: () => Promise<T>): Promise<T> {
  const held = heldKeys.getStore();
  if (held?.has(key)) {
    throw new Error(`withPathLock: ${key} is already held by this operation; the queue is not reentrant`);
  }
  const prior = writeQueues.get(key) ?? Promise.resolve();
  const run = prior.then(operation, operation);
  const tail = run.then(() => undefined, () => undefined);
  writeQueues.set(key, tail);
  try {
    const next = new Set(held ?? []);
    next.add(key);
    return await heldKeys.run(next, () => run);
  } finally {
    if (writeQueues.get(key) === tail) writeQueues.delete(key);
  }
}

export class AtomicJsonStore<T> {
  readonly path: string;
  constructor(path: string) { this.path = path; }

  /**
   * Write `value` atomically.
   *
   * Writes to the same path are serialized in the order they were *requested* — the queue slot is
   * taken synchronously, before the first `await` — so the document on disk is always the most
   * recently requested one, and a caller never sees the temp-file collision that made a concurrent
   * write fail with `ENOENT`.
   */
  async write(value: T): Promise<void> {
    const prior = writeQueues.get(this.path) ?? Promise.resolve();
    // `then(run, run)`: this write runs whether the previous one succeeded or failed. A failed
    // write must not block the next one.
    const run = prior.then(() => this.#writeNow(value), () => this.#writeNow(value));
    const tail = run.then(() => undefined, () => undefined);
    writeQueues.set(this.path, tail);
    try {
      await run;
    } finally {
      // Only drop the queue when nothing newer was requested while this write was running.
      if (writeQueues.get(this.path) === tail) writeQueues.delete(this.path);
    }
  }

  async #writeNow(value: T): Promise<void> {
    await mkdir(dirname(this.path), {recursive: true});
    writeCounter += 1;
    const temporary = `${this.path}.tmp-${process.pid}-${writeCounter.toString(36)}-${Math.random().toString(16).slice(2, 10)}`;
    const data = `${JSON.stringify(value, null, 2)}\n`;
    try {
      const handle = await open(temporary, "w");
      try { await handle.writeFile(data, "utf8"); await handle.sync(); }
      finally { await handle.close(); }
      await rename(temporary, this.path);
    } catch (error) {
      await unlink(temporary).catch(() => undefined);
      throw error;
    }
  }

  /**
   * Read the document. A missing file is not a diagnostic: the fallback is returned silently.
   * A file that exists but cannot be parsed is copied aside and reported, so callers can tell
   * "there is nothing here" from "there is something here and it is damaged".
   */
  async read(fallback: T): Promise<JsonReadResult<T>> {
    let text: string;
    try { text = await readFile(this.path, "utf8"); }
    catch (error) {
      const code = (error as {code?: string} | undefined)?.code;
      // Absent: the caller's fallback, with no diagnostic — this is the normal first-run case.
      if (code === "ENOENT") return {value: fallback};
      // Anything else (a directory where the document should be, a permission problem, a path whose
      // parent is a file) is reported: "there is no document here" and "I could not read the document
      // here" are different states, and callers act on them differently.
      return {value: fallback, diagnostic: `could not read ${this.path}: ${error instanceof Error ? error.message : String(error)}`};
    }
    try { return {value: JSON.parse(text) as T}; }
    catch (error) {
      const backupPath = `${this.path}.corrupt-${process.pid}-${writeCounter.toString(36)}-${Date.now()}`;
      let diagnostic = error instanceof Error ? error.message : String(error);
      try { await copyFile(this.path, backupPath); }
      catch (backupError) { diagnostic += `; backup failed: ${backupError instanceof Error ? backupError.message : String(backupError)}`; }
      return {value: fallback, backupPath, diagnostic};
    }
  }

  /** Write bytes verbatim (used by tests and tooling that need the store's atomicity without JSON). */
  static async writeBytes(path: string, data: Uint8Array | string): Promise<void> {
    writeCounter += 1;
    const temporary = `${path}.tmp-${process.pid}-${writeCounter.toString(36)}-${Math.random().toString(16).slice(2, 10)}`;
    await mkdir(dirname(path), {recursive: true});
    try { await writeFileRaw(temporary, data); await rename(temporary, path); }
    catch (error) { await unlink(temporary).catch(() => undefined); throw error; }
  }
}
