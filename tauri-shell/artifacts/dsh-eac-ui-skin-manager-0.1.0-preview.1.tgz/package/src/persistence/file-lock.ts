// Cross-process advisory lock (task 6.2.5).
//
// Why this exists at all: 6.2.2 and 6.2.3 both handed "concurrent install / concurrent catalog write"
// to this task, and an in-process queue cannot answer it. Two manager processes pointed at one data
// directory (a restarted sidecar whose predecessor is still shutting down, a CLI run beside the
// desktop app, a second instance) each read-modify-write the same files — `catalog.json`,
// `committed.json`, `snapshot.json` — and last-writer-wins silently drops the other's package,
// binding or generation. The queue in `atomic-json-store.ts` fixes the *in-process* half; this file
// fixes the cross-process half.
//
// Mechanism: a lock is a **directory** created with `mkdir`, which is atomic on every platform this
// manager runs on (on Windows it is the only filesystem primitive that is). Holding it means the
// directory exists. Contention is polling with a deadline, not blocking.
//
// The first revision of this file keyed every operation on the *path* alone, and reclaimed a lock
// whenever its timestamp looked old. Both halves of that were wrong, and the audit reproduced the
// consequences on a real filesystem: an owner whose lock had been taken over still deleted the new
// holder's lock in `release` (and in the process-exit hook), and a *live* holder that merely went
// quiet for `staleMs` was displaced while it was still inside its critical section. The rules below
// are the correction. Each one is load-bearing; the comment says what breaks without it.
//
//   * **Every acquisition has an identity.** A `token` (pid + random UUID) is written to
//     `<lock>/owner.json` as part of taking the lock, and *every* mutation — `refresh`, `release`,
//     the exit hook — is checked against the identity that is on disk at that moment. A handle whose
//     token is no longer current touches nothing and reports `LOCK_LOST`. Without this, "release"
//     means "delete whatever is at this path", which is what deleted a live holder's lock.
//   * **A live holder is never displaced.** A lock is reclaimed only when its holder is *provably*
//     gone: the recorded pid is not running (`process.kill(pid, 0)` → ESRCH). Time alone never
//     reclaims. The heartbeat is *not* what protects a holder — a holder that stalls, is swapped out
//     or sits in a long install is still alive, and its pid says so — it is what keeps the record
//     fresh for diagnostics. When liveness cannot be disproved (a pid we may not signal, a lock
//     taken on another host, a record we cannot read) the waiter **times out with `LOCK_TIMEOUT`**,
//     names the holder and says what an operator can do about it. Refusing is the safe direction: a
//     stalled holder delays the manager, a displaced holder corrupts it.
//   * **A record that cannot be read is never reclaimed.** There is exactly one automatic takeover:
//     a recorded pid that is provably gone. An unreadable record (the microseconds between `mkdir`
//     and the record landing, a torn write, a directory this manager did not create) names no pid,
//     so nothing can be probed and no death can be proven — and age is not proof, so such a lock is
//     refused however old it looks. The refusal names the path and the remedy (verify that no
//     manager process is running, then remove it by hand) instead of quietly taking a lock that a
//     live holder may still believe it owns. This is the one case that can need an operator.
//   * **Reclaiming is serialized and identity-checked.** A reclaimer first takes a claim marker
//     (`<lock>.eac-reclaim`, itself an atomic `mkdir`) so two contenders cannot both act on the same
//     dead lock. Under the claim it re-reads the holder, and only then renames the lock aside and
//     checks the *object it actually moved* still carries the identity it judged. `rename` is atomic
//     but "judge, then rename" is not; if the moved object is not the judged one it is put back
//     untouched, never deleted.
//   * **Every attempt ends at the deadline.** The acquisition loop checks its deadline on every path
//     that made no progress — including a reclaim that another live process's marker blocked — and
//     waits between attempts, so a lock that cannot be taken is reported as `LOCK_TIMEOUT` instead of
//     being retried for ever. The first revision of this loop re-entered itself with neither a wait
//     nor a deadline check whenever the reclaim marker was held by a live process: a caller then
//     never returned at all, at whatever rate the filesystem would take the polling.
import {mkdir, readFile, rename, rm, stat, writeFile} from "node:fs/promises";
import {readFileSync, rmSync} from "node:fs";
import {randomUUID} from "node:crypto";
import {hostname} from "node:os";
import {dirname, join} from "node:path";

export const LOCK_DIRECTORY_SUFFIX = ".eac-lock" as const;
/** Marker a reclaimer takes so that only one process reclaims a given dead lock. */
export const RECLAIM_MARKER_SUFFIX = ".eac-reclaim" as const;
export const OWNER_RECORD_NAME = "owner.json" as const;
export const DEFAULT_LOCK_TIMEOUT_MS = 30_000 as const;
export const DEFAULT_LOCK_STALE_MS = 60_000 as const;
const DEFAULT_POLL_MS = 25;
const RESTORE_ATTEMPTS = 20;
const RESTORE_DELAY_MS = 5;

export type FileLockErrorCode = "LOCK_TIMEOUT" | "LOCK_UNUSABLE" | "LOCK_LOST";

export class FileLockError extends Error {
  readonly code: FileLockErrorCode;
  constructor(code: FileLockErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "FileLockError";
    this.code = code;
  }
}

/** What a lock directory records about the process that holds it. */
export interface LockOwnerRecord {
  /** Unique per acquisition: pid plus a random suffix. Empty for a record written by an older build. */
  token: string;
  pid: number;
  /** Host that took the lock; a lock taken elsewhere cannot be probed for liveness from here. */
  host: string;
  startedAt: string;
  heartbeatAt: number;
  label: string;
}

export interface FileLockOptions {
  /** How long to wait for the lock before giving up. */
  timeoutMs?: number;
  /** Sizes the automatic heartbeat (the wait between attempts is `pollMs`). */
  staleMs?: number;
  pollMs?: number;
  /** Automatic heartbeat interval; `0` disables it. Defaults to a third of `staleMs`, capped at 5 s. */
  heartbeatMs?: number;
  now?: () => number;
  /** Test seam: replaces the real sleep. */
  sleep?: (ms: number) => Promise<void>;
  /** Test seam: replaces the pid liveness probe. */
  isAlive?: (pid: number) => boolean;
  /** Test seam: runs after a dead lock has been judged and before it is renamed aside. */
  beforeReclaimRename?: (context: {lockPath: string; judged: string}) => Promise<void>;
}

export interface FileLockHandle {
  readonly path: string;
  readonly token: string;
  readonly label: string;
  /** True once this handle can no longer prove it owns the lock (it was taken over or removed). */
  readonly lost: boolean;
  /** True while the on-disk record still carries this handle's token. */
  owns(): Promise<boolean>;
  /** Rewrite the heartbeat, or fail with `LOCK_LOST` when this handle no longer owns the lock. */
  refresh(): Promise<void>;
  /** Remove the lock — but only while this handle still owns it. Never throws. */
  release(): Promise<void>;
}

/** Locks this process currently holds, so they can be released if the process exits abruptly. */
const held = new Map<string, string>();
let exitHookInstalled = false;

function installExitHook(): void {
  if (exitHookInstalled) return;
  exitHookInstalled = true;
  process.once("exit", () => {
    // Synchronous best effort: `exit` handlers cannot await. The identity check matters more here
    // than anywhere else — this runs while the process is on its way out, and removing a lock that
    // was already taken over would hand the new holder's lock to whoever asks next.
    for (const [path, token] of held) {
      try {
        const record = JSON.parse(readFileSync(join(path, OWNER_RECORD_NAME), "utf8")) as {token?: unknown} | undefined;
        if (record?.token !== token) continue;
        rmSync(path, {recursive: true, force: true});
      } catch { /* nothing useful can be done at exit */ }
    }
    held.clear();
  });
}

function message(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function errorCode(error: unknown): string | undefined {
  return (error as {code?: string} | undefined)?.code;
}

/**
 * True when `pid` is running.
 *
 * `ESRCH` is the only answer that proves a process is gone; anything else — including `EPERM` (the
 * process exists but belongs to another user) or an unexpected error — is reported as alive, so an
 * unprovable case refuses to reclaim rather than stealing a lock.
 */
export function isProcessAlive(pid: number): boolean {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return errorCode(error) !== "ESRCH";
  }
}

/** Heartbeat interval for a stale window: frequent enough that a healthy holder always looks fresh. */
export function heartbeatIntervalFor(staleMs: number): number {
  return Math.max(250, Math.min(5_000, Math.floor(staleMs / 3)));
}

/** The lock directory's owner record, or `undefined` when there is no readable one. */
export async function lockOwner(path: string): Promise<LockOwnerRecord | undefined> {
  return await readOwnerRecord(path);
}

async function readOwnerRecord(path: string): Promise<LockOwnerRecord | undefined> {
  try {
    const parsed = JSON.parse(await readFile(join(path, OWNER_RECORD_NAME), "utf8")) as Partial<LockOwnerRecord> | undefined;
    if (parsed === undefined || parsed === null || typeof parsed !== "object") return undefined;
    if (typeof parsed.pid !== "number" || !Number.isInteger(parsed.pid)) return undefined;
    return {
      token: typeof parsed.token === "string" ? parsed.token : "",
      pid: parsed.pid,
      host: typeof parsed.host === "string" ? parsed.host : "",
      startedAt: typeof parsed.startedAt === "string" ? parsed.startedAt : "unknown",
      heartbeatAt: typeof parsed.heartbeatAt === "number" ? parsed.heartbeatAt : 0,
      label: typeof parsed.label === "string" ? parsed.label : path
    };
  } catch {
    return undefined;
  }
}

/**
 * Write the owner record so a reader never sees half of it: a temporary file in the same directory,
 * then an atomic replace. A filesystem that refuses the replace still gets the direct write — a torn
 * record reads as "unreadable", which is the safe direction (such a lock is never reclaimed young).
 */
async function writeOwnerRecord(path: string, record: LockOwnerRecord): Promise<void> {
  const destination = join(path, OWNER_RECORD_NAME);
  const text = `${JSON.stringify(record, null, 2)}\n`;
  const temporary = join(path, `${OWNER_RECORD_NAME}.${record.token.replace(/[^A-Za-z0-9_.-]/g, "_")}.tmp`);
  try {
    await writeFile(temporary, text, "utf8");
    await rename(temporary, destination);
  } catch {
    await writeFile(destination, text, "utf8");
  }
}

/**
 * Age of the lock's evidence: the owner record's timestamp, or the directory's when the record is
 * missing (the microsecond window between `mkdir` and the record being written).
 */
async function evidenceAge(path: string, now: number): Promise<number> {
  for (const candidate of [join(path, OWNER_RECORD_NAME), path]) {
    try {
      const info = await stat(candidate);
      return Math.max(0, now - info.mtimeMs);
    } catch { /* fall through to the directory itself */ }
  }
  return Number.POSITIVE_INFINITY;
}

function identityOf(record: LockOwnerRecord): string {
  return record.token !== "" ? record.token : `${record.pid}@${record.startedAt}`;
}

interface HolderVerdict {
  record?: LockOwnerRecord;
  identity: string;
  ageMs: number;
  reclaimable: boolean;
  reason: string;
  /** True when the verdict rests on a record that could not be read: nothing can be probed. */
  unreadable?: boolean;
  /** What an operator can do about a holder that cannot be reclaimed automatically. */
  remedy?: string;
}

interface LockContext {
  staleMs: number;
  pollMs: number;
  now: () => number;
  sleep: (ms: number) => Promise<void>;
  isAlive: (pid: number) => boolean;
  deadline: number;
  label: string;
  localHost: string;
  counter: {value: number};
  options: FileLockOptions;
}

/**
 * Decide what is at `path` and whether it may be reclaimed.
 *
 * Reclaiming is a claim about the *holder*, not about the clock: a lock is only reclaimable when its
 * holder is provably not running any more. Everything else is refused, and the caller waits out its
 * deadline and reports who holds it:
 *
 *   * a live pid — the holder is running, whatever its heartbeat says;
 *   * a pid we may not signal (`EPERM`) or a lock taken on another host — liveness cannot be checked;
 *   * a record that cannot be read — no pid is named, so there is nothing to probe. Age is not
 *     evidence, so this is refused however old the directory looks, and the report carries the
 *     remedy. The one automatic takeover is a pid that is provably gone; anything that cannot be
 *     probed is left alone and reported.
 */
async function inspectHolder(path: string, context: LockContext): Promise<HolderVerdict> {
  const now = context.now();
  const ageMs = await evidenceAge(path, now);
  const record = await readOwnerRecord(path);
  if (record === undefined) {
    return {
      identity: "unreadable",
      ageMs,
      reclaimable: false,
      unreadable: true,
      reason: `its owner record is missing or unreadable and it is ${Math.round(ageMs)}ms old, so no holder can be identified and no liveness can be probed`,
      remedy: `verify that no manager process is running and then remove ${path} by hand`
    };
  }
  const identity = identityOf(record);
  if (record.host !== "" && record.host !== context.localHost) {
    return {
      record, identity, ageMs, reclaimable: false,
      reason: `pid ${record.pid} took it on host ${record.host}, where liveness cannot be checked from here`,
      remedy: `if ${record.host} is gone, remove ${path} by hand`
    };
  }
  if (context.isAlive(record.pid)) {
    return {
      record, identity, ageMs, reclaimable: false,
      reason: `pid ${record.pid} is still running (heartbeat ${Math.round(ageMs)}ms old)`,
      remedy: `wait for pid ${record.pid} to finish, or stop it`
    };
  }
  return {record, identity, ageMs, reclaimable: true, reason: `pid ${record.pid} is gone (heartbeat ${Math.round(ageMs)}ms old)`};
}

/** How a refusal names the holder it is about. */
function describeHolder(path: string, verdict: HolderVerdict): string {
  const record = verdict.record;
  if (record === undefined) return "an unidentified holder";
  return record.label === path ? `pid ${record.pid}` : `pid ${record.pid} of ${record.label}`;
}

function withRemedy(verdict: HolderVerdict): string {
  return verdict.remedy === undefined ? "" : `; ${verdict.remedy}`;
}

function timeoutError(path: string, label: string, timeoutMs: number, verdict: HolderVerdict): FileLockError {
  return new FileLockError(
    "LOCK_TIMEOUT",
    `${label} is held by ${describeHolder(path, verdict)} and was not released within ${timeoutMs}ms — ${verdict.reason}${withRemedy(verdict)}`
  );
}

/**
 * The refusal for a lock that *is* reclaimable but could not be taken over in time: either another
 * live process holds the reclaim marker for it, or the takeover kept losing the judge/act race. Both
 * are reported with the marker named, because a stuck marker is the one thing an operator can act on.
 */
function reclaimBlockedError(
  path: string, label: string, timeoutMs: number, verdict: HolderVerdict,
  markerPath: string, blockedBy: HolderVerdict | undefined
): FileLockError {
  if (blockedBy === undefined) {
    return new FileLockError(
      "LOCK_TIMEOUT",
      `${label} is held by ${describeHolder(path, verdict)} and was not reclaimed within ${timeoutMs}ms — ${verdict.reason}; ` +
      `the takeover of ${path} did not complete within the deadline, so another process is competing for it`
    );
  }
  const holder = blockedBy.record === undefined
    ? `an unidentified process (its record is unreadable)`
    : `pid ${blockedBy.record.pid} of ${blockedBy.record.label}`;
  return new FileLockError(
    "LOCK_TIMEOUT",
    `${label} is held by ${describeHolder(path, verdict)} and could not be reclaimed within ${timeoutMs}ms — ` +
    `the reclaim marker ${markerPath} is held by ${holder} (${blockedBy.reason})${withRemedy(blockedBy)}`
  );
}

/**
 * Move the judged object aside, verify that what was moved is what was judged, and only then remove
 * it. Returns true when a dead holder's lock was removed.
 *
 * The verification is the point: `rename` is atomic, but "decide the lock is dead, then rename it
 * away" is two steps, and between them the path can hold a different object. If it does, the object
 * is put back and nothing is deleted.
 */
async function displace(path: string, verdict: HolderVerdict, context: LockContext, token: string): Promise<boolean> {
  context.counter.value += 1;
  const tombstone = `${path}.stale-${process.pid}-${context.counter.value}-${token.slice(-8)}`;
  await context.options.beforeReclaimRename?.({lockPath: path, judged: verdict.identity});
  try {
    await rename(path, tombstone);
  } catch {
    return false; // Someone else moved or removed it first; the caller re-reads and retries.
  }
  const moved = await readOwnerRecord(tombstone);
  const movedIdentity = moved === undefined ? "unreadable" : identityOf(moved);
  if (movedIdentity !== verdict.identity) {
    await restore(tombstone, path, context);
    return false;
  }
  await rm(tombstone, {recursive: true, force: true});
  return true;
}

/** Put a moved object back where it was. Never deletes it: deleting would destroy a holder's identity. */
async function restore(tombstone: string, path: string, context: LockContext): Promise<boolean> {
  for (let attempt = 0; attempt < RESTORE_ATTEMPTS; attempt += 1) {
    try {
      await rename(tombstone, path);
      return true;
    } catch {
      await context.sleep(RESTORE_DELAY_MS);
    }
  }
  // Left in place deliberately: the holder that was displaced finds its record gone and reports
  // `LOCK_LOST` instead of writing as though it still held the lock, and a diagnostic names the path.
  return false;
}

/** What a reclaim attempt achieved. `blockedBy` is set when another process's marker stopped it. */
interface ReclaimClaim {
  claimed: boolean;
  markerPath: string;
  blockedBy?: HolderVerdict;
}

/**
 * Take the reclaim marker for `path`, reclaiming a marker left behind by a dead reclaimer.
 *
 * Returns `claimed: false` when the marker is held by another process — a live reclaimer (the caller
 * keeps polling the lock itself, which is what serializes two contenders that both judged the same
 * dead lock) or a marker that cannot be probed — and when the deadline runs out. The caller must
 * treat both of those as "no progress" and wait rather than retry immediately.
 */
async function claimReclaim(claimPath: string, context: LockContext, token: string): Promise<ReclaimClaim> {
  for (;;) {
    if (context.now() >= context.deadline) {
      // The deadline ran out between the outer loop's judgement and here. Still say *who* holds the
      // marker if anyone does — that is the one diagnosis the caller cannot get elsewhere.
      const verdict = await inspectHolder(claimPath, context).catch(() => undefined);
      return verdict !== undefined && !verdict.reclaimable
        ? {claimed: false, markerPath: claimPath, blockedBy: verdict}
        : {claimed: false, markerPath: claimPath};
    }
    try {
      await mkdir(claimPath, {recursive: false});
    } catch (error) {
      if (errorCode(error) !== "EEXIST") {
        throw new FileLockError("LOCK_UNUSABLE", `could not create the reclaim marker ${claimPath}: ${message(error)}`);
      }
      const verdict = await inspectHolder(claimPath, context);
      if (!verdict.reclaimable) return {claimed: false, markerPath: claimPath, blockedBy: verdict};
      await displace(claimPath, verdict, context, token);
      continue;
    }
    try {
      await writeOwnerRecord(claimPath, {
        token,
        pid: process.pid,
        host: context.localHost,
        startedAt: new Date(context.now()).toISOString(),
        heartbeatAt: context.now(),
        label: `${context.label} reclaim marker`
      });
    } catch (error) {
      await rm(claimPath, {recursive: true, force: true}).catch(() => undefined);
      throw new FileLockError("LOCK_UNUSABLE", `could not record the reclaim marker ${claimPath}: ${message(error)}`);
    }
    return {claimed: true, markerPath: claimPath};
  }
}

/**
 * How long to wait before looking again: the poll interval, never past the deadline. Every path out
 * of the acquisition loop that made no progress waits this long, so a lock that cannot be taken
 * costs a poll per interval and not a spin per filesystem round trip.
 */
function waitBeforeRetry(context: LockContext): number {
  return Math.min(context.pollMs, Math.max(1, context.deadline - context.now()));
}

/**
 * Acquire `path` as an exclusive lock, waiting up to `timeoutMs`.
 *
 * Throws `FileLockError("LOCK_TIMEOUT")` when the deadline passes with a holder that cannot be
 * proven gone, or `LOCK_UNUSABLE` when the lock path cannot be created for a reason that will not
 * improve (the parent is a file, permissions).
 */
export async function acquireFileLock(path: string, options: FileLockOptions & {label?: string} = {}): Promise<FileLockHandle> {
  const timeoutMs = options.timeoutMs ?? DEFAULT_LOCK_TIMEOUT_MS;
  const staleMs = options.staleMs ?? DEFAULT_LOCK_STALE_MS;
  const pollMs = options.pollMs ?? DEFAULT_POLL_MS;
  const heartbeatMs = options.heartbeatMs ?? heartbeatIntervalFor(staleMs);
  const now = options.now ?? Date.now;
  const sleep = options.sleep ?? ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));
  const isAlive = options.isAlive ?? isProcessAlive;
  const label = options.label ?? path;
  const token = `${process.pid}-${randomUUID()}`;
  const context: LockContext = {
    staleMs, pollMs, now, sleep, isAlive,
    deadline: now() + timeoutMs,
    label,
    localHost: hostname(),
    counter: {value: 0},
    options
  };
  const record: LockOwnerRecord = {
    token, pid: process.pid, host: context.localHost,
    startedAt: new Date(now()).toISOString(), heartbeatAt: now(), label
  };
  // The most recent reclaim-marker blocker, so the timeout report can name who stopped the takeover
  // even on the iteration where the deadline ran out.
  let lastBlockedBy: HolderVerdict | undefined;
  let lastClaimPath = `${path}${RECLAIM_MARKER_SUFFIX}`;

  for (;;) {
    try {
      // The lock's parent directory must already exist: this primitive deliberately does not create
      // any part of the tree it protects (callers do that behind their own path guards), so a missing
      // parent is a configuration error rather than something to paper over.
      await mkdir(path, {recursive: false});
    } catch (error) {
      if (errorCode(error) !== "EEXIST") {
        throw new FileLockError("LOCK_UNUSABLE", `could not create the lock ${path}: ${message(error)}`);
      }
      const verdict = await inspectHolder(path, context);
      if (verdict.reclaimable) {
        const claim = await claimReclaim(`${path}${RECLAIM_MARKER_SUFFIX}`, context, token);
        let reclaimed = false;
        if (claim.claimed) {
          try {
            // Re-read under the marker: what was judged before the marker was taken is not what the
            // rename has to act on.
            const current = await inspectHolder(path, context);
            if (current.reclaimable && current.identity === verdict.identity) {
              reclaimed = await displace(path, current, context, token);
            }
          } finally {
            await rm(claim.markerPath, {recursive: true, force: true}).catch(() => undefined);
          }
        }
        // Only a removal that actually happened earns an immediate retry. Everything else — the
        // marker held by another process, the judged lock changed under us, the deadline reached
        // inside the claim — is no progress at all, so it waits like every other waiter and gives up
        // at the deadline. Without the wait and the check this branch re-entered the loop for ever.
        // The blocker identity survives across iterations: whoever holds the marker on the *last*
        // failed attempt is who the timeout names.
        if (reclaimed) continue;
        lastBlockedBy = claim.blockedBy;
        lastClaimPath = claim.markerPath;
        if (now() >= context.deadline) {
          throw reclaimBlockedError(path, label, timeoutMs, verdict, lastClaimPath, lastBlockedBy);
        }
        await sleep(waitBeforeRetry(context));
        continue;
      }
      if (now() >= context.deadline) throw timeoutError(path, label, timeoutMs, verdict);
      await sleep(waitBeforeRetry(context));
      continue;
    }

    // The directory is ours. Record who we are before anyone can judge it: a lock whose record is
    // missing is deliberately not reclaimable while it is young, so this window is safe — and if the
    // record cannot be written at all the lock is given back rather than held unidentifiably.
    try {
      await writeOwnerRecord(path, record);
    } catch (error) {
      await rm(path, {recursive: true, force: true}).catch(() => undefined);
      throw new FileLockError("LOCK_UNUSABLE", `could not record the owner of ${path}: ${message(error)}`);
    }
    held.set(path, token);
    installExitHook();

    let lost = false;
    let timer: ReturnType<typeof setInterval> | undefined;
    const owns = async (): Promise<boolean> => {
      const current = await readOwnerRecord(path);
      if (current?.token === token) return true;
      lost = true;
      return false;
    };
    const refresh = async (): Promise<void> => {
      if (lost) throw new FileLockError("LOCK_LOST", `${label} no longer holds ${path}`);
      const current = await readOwnerRecord(path);
      if (current?.token !== token) {
        lost = true;
        throw new FileLockError("LOCK_LOST", `${label} no longer holds ${path}: the record is now ${current === undefined ? "gone" : `token ${current.token} (pid ${current.pid})`}`);
      }
      try {
        await writeOwnerRecord(path, {...record, heartbeatAt: now()});
      } catch (error) {
        lost = true;
        throw new FileLockError("LOCK_LOST", `${label} could not refresh its heartbeat for ${path} and can no longer defend the lock: ${message(error)}`);
      }
    };
    const release = async (): Promise<void> => {
      if (timer !== undefined) {
        clearInterval(timer);
        timer = undefined;
      }
      held.delete(path);
      // Only ever remove a lock this handle still owns: an owner whose lock was taken over (or that
      // was already released) must leave the current holder's lock alone.
      const current = await readOwnerRecord(path);
      if (current?.token !== token) return;
      await rm(path, {recursive: true, force: true}).catch(() => undefined);
    };

    if (heartbeatMs > 0) {
      timer = setInterval(() => { void refresh().catch(() => undefined); }, heartbeatMs);
      timer.unref?.();
    }
    return {
      path,
      token,
      label,
      get lost(): boolean { return lost; },
      owns,
      refresh,
      release
    };
  }
}

/**
 * Run `operation` while holding `path`. The lock is released on every path out of `operation`,
 * including a throw, so a failed install cannot leave the manager unable to install again.
 *
 * A heartbeat runs for the whole critical section, so a long install cannot be mistaken for an
 * abandoned lock. If the lock was lost anyway, that is reported as `LOCK_LOST` rather than passed off
 * as a successful exclusive write.
 */
export async function withFileLock<T>(
  path: string,
  operation: (handle: FileLockHandle) => Promise<T>,
  options: FileLockOptions & {label?: string} = {}
): Promise<T> {
  const handle = await acquireFileLock(path, options);
  let result: T | undefined;
  let failure: unknown;
  let failed = false;
  try {
    result = await operation(handle);
  } catch (error) {
    failed = true;
    failure = error;
  }
  const owned = await handle.owns();
  await handle.release();
  if (failed) throw failure;
  if (!owned) throw new FileLockError("LOCK_LOST", `${handle.label} lost ${handle.path} while it was being written`);
  return result as T;
}

/** Lock path for a data file or directory: `<target>.eac-lock`, beside what it protects. */
export function lockPathFor(target: string): string {
  return `${target}${LOCK_DIRECTORY_SUFFIX}`;
}

/** True when the lock directory exists (someone holds it, or a crashed holder left it behind). */
export async function isLocked(path: string): Promise<boolean> {
  try { await stat(path); return true; }
  catch { return false; }
}

/** Parent directory of a lock, for diagnostics. */
export function lockParent(path: string): string {
  return dirname(path);
}
