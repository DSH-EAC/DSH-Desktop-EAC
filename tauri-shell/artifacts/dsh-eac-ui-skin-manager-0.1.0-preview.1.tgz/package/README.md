# dsh-ui-skin-manager

DSH-Desktop-EAC-specific UI Skin package loader and manager.

## Status

Stage 1 provides the `dsh-ui-skin-manager@1` contract/conformance preview. It includes TypeScript data models, versioned JSON Schemas, package/profile/path/integrity validation, a minimal staged per-slot lifecycle, an idempotent effect ledger, fault-isolation helpers, fixtures, and CI.

Task 6.2.2 adds the first real installer stage on top of that preview: `src/installer/` reads the source archive bytes, enforces the container and payload gates, publishes into an atomic staging directory, and records the result in a persistent catalog. It is still not the runtime adapter, the EAC integration, or the settings UI.

Run the dependency-free checks with a supported Node version:

```text
npm test
npm run format:check
npm run conformance -- test/fixtures/valid/minimal-skin.json
npm run fixture:check
node --experimental-strip-types tools/hostile-fixtures.mjs "$TMPDIR/hostile"
```

### Secure import and install (task 6.2.2)

```text
npm run test:install
node --experimental-strip-types bin/skin-catalog.mjs inspect <archive> [--digest sha256:<hex>]
node --experimental-strip-types bin/skin-catalog.mjs install <archive> --root <state-dir> [--digest sha256:<hex>]
node --experimental-strip-types bin/skin-catalog.mjs list --root <state-dir>
node --experimental-strip-types bin/skin-catalog.mjs uninstall <id> <version> --root <state-dir>
```

`install` never enables a package: it only makes it listable. `list` re-opens the catalog index from disk, which is what happens after a manager restart. The committed conformance fixture is built by `npm run fixture:build` and its artifact is reproducible byte-for-byte from a fresh checkout.

What the installer now enforces before anything is written:

| Gate | Rejection |
| --- | --- |
| Archive format | ZIP/other container, empty archive, header checksum or octal overflow, missing end-of-archive marker, trailing data, truncation |
| Entry types | symlink, hardlink, device, FIFO, GNU long name/long link, PAX extended header |
| Entry paths | absolute, Windows drive, `..` traversal, backslash, empty segment, NFC/lowercase duplicate, file nested under file |
| Limits | entry count, per-entry bytes, declared payload bytes, raw archive bytes |
| Payload | zero or more than one SkinPackage payload, generic Feature Pack content (`pack.json` with plugins/presets/skills, `payload/presets|skills|plugins`) |
| Manifest | schema/identity/version failures, invalid SemVer range, unknown slot, missing capability, incompatible host profile |
| Bytes | per-file digest mismatch, integrity-map disagreement, missing declared asset, undeclared payload file |
| Trust | self-declared `official` in the manifest, provenance or signature |
| Install path | a symlink or NTFS junction anywhere between the install root and the publish target (or a root that is itself a link), a coordinate path that resolves outside the root, and a target that is not a directory |
| Install boundary | an install root that is no longer the directory that was approved — replaced by a junction, or moved aside and re-created (`PATH_LINK_ESCAPE` / `PATH_ROOT_CHANGED`) |
| Re-import | a coordinate whose installed directory does not hold *exactly* the package (`INSTALL_STATE_DAMAGED`): a manifest that is not the canonical manifest (truncated, edited, repointed contribution, widened engines), a missing or replaced asset, a missing or rewritten attribution file, an extra file or directory, a file-level symlink, or changed permission bits |
| Source read | an archive larger than the byte ceiling, refused before the file is buffered; a directory or an unreadable path |

Installation is content-addressed by the whole-archive SHA-256 and published with a single rename. A failure removes the staging directory, undoes the publish and restores the catalog entry that was committed before the attempt — a failed second import can no longer erase a package that was already installed. Nothing ever touches an existing binding or active slot. Both file entry points (`importPackageFile`, `importManifest`) read the source through the same bounded reader, verify its bytes against the declared digest, and require the archive to declare the same package coordinate as the caller's manifest.

A re-import of the same bytes is reported as idempotent only after the installed tree has been re-read and compared in full against the package: the canonical manifest bytes, every declared asset (bytes, regular-file type and permission bits), every attribution file, and the absence of anything extra. Permission bits are compared against what the platform can express — exact bits on POSIX, the read-only property on NTFS, which reports `0o666` for every writable file.

Known residual risk: the link checks are point-in-time. A process able to create a junction inside the install root *while* an install is running could still race the check, and a directory identity could in principle be recycled by the filesystem after deletion. What is guaranteed is that no link existing at check time is traversed, that the approved boundary is re-validated before every install, and that a publish is rolled back when the post-check finds one. See `docs/ui-skin-container-layout.md`.

Normative decisions:

- `docs/adr/0001-skin-package-format.md`
- `docs/adr/0002-slot-lifecycle-fault-isolation.md`
- `docs/adr/0003-host-capability-boundary.md`
- `docs/ui-skin-cross-repo-interface-versions.md`

The current contract is `dsh.eac.ui-skin/v1` / `SkinPackage`, manager API `dsh-ui-skin-manager@1`, and EAC host profile `dsh-desktop-eac-ui-skin-profile@^0.3.0`.

## Boundary

This repository owns package/schema validation, discovery, install index, per-slot selection and binding, lifecycle, fault isolation, effect-ledger cleanup, atomic persistence, diagnostics structure, and rollback. It is not a general application plugin manager and does not own Tauri privileges, EAC window/process/session behavior, or host slot topology.

There is no monolithic shell skin. Every replaceable visual element is represented by a host-owned slot; one Skin artifact may contribute arbitrary component logic and local styles to any set of slots, and each contribution is enabled, switched, failed, and disposed independently.

`DSH-EAC/dsh-desktop-eac-default-skins` is the only canonical source for official `system.default` content. This repository consumes a versioned, digest-locked release artifact and does not bundle editable default or AIO source. Third-party package artifacts are not copied into this repository.

## Superseded placeholder decisions

The original placeholder README intentionally blocked implementation on four open questions. Stage 0 closes them as follows:

1. Skin packages use an independent EAC-private envelope. The official EAC `.dshpack` structure is accepted only as a compatibility container when it declares exactly one `SkinPackage` payload; generic Feature Pack contents are not skin packages, and the manager still owns inner validation and lifecycle.
2. Package coordinates are `dsh.eac.ui-skin/v1` / `SkinPackage` plus immutable ID, SemVer, and SHA-256 digest.
3. EAC slots map to public dsh APIs through explicit versioned adapters; CSS-module hashes, private DOM/classes, source paths, and HMR internals are not ABI.
4. Official default source is released from the separate default-skins repository; manager releases consume artifacts and never become a second source.

The former statement that manager would bundle all EAC/AIO skins as built-in examples is superseded because it conflicts with canonical-source ownership and the explicit exclusion of AIO from this migration. No test or SKILL existed in this repository at stage 0. Future deletion of a conflicting test, SKILL, or specification must record the obsolete assertion, deletion reason, owning ADR, and replacement gate in the same reviewed change; safety and regression gates may not be weakened merely to make CI pass.

## Related repositories

- `DSH-EAC/DSH-Desktop-EAC`: host profile, stable slot mounts, Tauri/WebView/resource capabilities, build locks, and embedded recovery fallback.
- `DSH-EAC/dsh-desktop-eac-default-skins`: official default content and reproducible release artifact.

The current preview implements the frozen contract models, the conformance gates, and (from task 6.2.2) the secure import / atomic install / persistent catalog stage. Runtime adapters, hot switching, EAC integration, release workflows, and AIO migration remain staged follow-up work. The container layout the installer accepts, and the open questions around it, are recorded in `docs/ui-skin-container-layout.md`.
