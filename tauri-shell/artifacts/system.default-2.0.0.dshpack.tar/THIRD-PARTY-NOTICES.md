# Third-party notices

No third-party code, fonts, images, or other separately licensed material is included in the initial `system.default@2.0.0` artifact.
