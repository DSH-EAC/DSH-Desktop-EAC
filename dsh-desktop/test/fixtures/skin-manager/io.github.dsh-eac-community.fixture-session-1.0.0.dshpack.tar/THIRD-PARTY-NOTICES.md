# Third-party notices — community-session fixture

This fixture exists only to exercise the manager's secure import path (task 6.2.2).
It is **not** an official DSH-EAC skin and is not affiliated with, endorsed by, or
supported by any upstream theme project.

## Reused material

None. Every file in this fixture — the manifest, the slot entry, the stylesheet, and
this notice — was authored for task 6.2.2. No upstream code, palette, artwork, or
binary asset was copied.

## Compliance notes

- The fixture is deliberately marked third-party (`provenance.official: false`).
- It must never be able to declare itself `official`; the installer rejects that outright.
- The fixture is test-only and is never installed into a running EAC application.
