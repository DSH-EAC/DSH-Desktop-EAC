// Conformance fixture entry point for the `session` slot.
// Authored for task 6.2.2. No upstream code is copied or adapted here.
export function mount(context) {
  const element = document.createElement("div");
  element.className = "community-fixture-session";
  element.textContent = "community fixture";
  context.mount(element);
  return () => element.remove();
}

export function health() {
  return true;
}

export function unmount() {
  return undefined;
}
